-- Rise Marketing HQ Core MVP | 2026-09-11 | Review version 1.1 (approved additions A-E)
-- Design artifact only: NOT applied to a database.
-- Supabase PostgreSQL and auth.users; no new extension/dependency required.
-- Application-generated UUIDs/hashes and JSON validation are part of the contract.

begin;

create table public.core_bundles (
  id text primary key check (id ~ '^[0-9a-f]{64}$'),
  manifest jsonb not null check (jsonb_typeof(manifest) = 'object'),
  -- Includes full KB text/version/hash, config, price sources, effective stopwords,
  -- ruler data/hash and code/package/model manifest. Canonical JSON hash = id.
  created_at timestamptz not null default now()
);

create table public.core_runs (
  id uuid primary key,
  owner_id uuid not null references auth.users(id),
  bundle_id text not null references public.core_bundles(id),
  idempotency_key text not null,
  input_sha256 text not null check (input_sha256 ~ '^[0-9a-f]{64}$'),
  query text not null check (length(btrim(query)) > 0),
  target_country text not null check (target_country ~ '^[A-Z]{2}$'),
  language_code text not null,
  device text not null default 'desktop' check (device in ('desktop','mobile')),
  vertical text,
  client_url text,
  client_domain text,
  other_client_urls jsonb not null default '[]'::jsonb
    check (jsonb_typeof(other_client_urls) = 'array'),
  cluster_queries jsonb not null default '[]'::jsonb
    check (jsonb_typeof(cluster_queries) = 'array'),
  detected_page_mode text check (detected_page_mode in ('NEW','IMPROVE','REWRITE')),
  effective_page_mode text check (effective_page_mode in ('NEW','IMPROVE','REWRITE')),
  -- NULL means pending/MISSING; scope mode in routing_context remains a separate concept.
  requested_location jsonb not null check (
    jsonb_typeof(requested_location) = 'object' and
    ((requested_location ? 'location_code') <> (requested_location ? 'location_name'))
  ),
  -- Server also validates selector value/type, catalogue membership and country.
  serp_scope jsonb not null,
  labs_scope jsonb not null,
  routing_context jsonb not null, -- MVP: mode:null, one location, core URLs:null
  state text not null default 'queued' check (state in
    ('queued','running','complete','partial','failed','interrupted')),
  stage text not null default 'serp',
  failure jsonb,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (owner_id, idempotency_key)
);

create table public.core_pages (
  id uuid primary key,
  run_id uuid not null references public.core_runs(id),
  role text not null check (role in ('competitor','client','client_comparison')),
  selection_order smallint check (selection_order between 1 and 10),
  selected_url text not null,
  url_key text not null check (url_key ~ '^[0-9a-f]{64}$'),
  -- Hash of the explicitly normalized URL; normalization version is in bundle.
  host_key text not null,
  serp_raw_id uuid,
  serp_item_pointer text,
  redirect_observations jsonb not null default '[]'::jsonb,
  accepted_attempt smallint check (accepted_attempt in (0,1)),
  body_state text not null default 'pending' check (body_state in
    ('pending','ok','failed','missing')),
  measures_state text not null default 'pending' check (measures_state in
    ('pending','ok','partial','failed','missing')),
  selected_cp_raw_id uuid,
  selected_ip_raw_id uuid,
  reasons jsonb not null default '[]'::jsonb,
  unique (run_id, id),
  unique (run_id, selection_order),
  unique (run_id, url_key),
  check ((role = 'competitor' and selection_order is not null and
          serp_raw_id is not null and serp_item_pointer is not null) or
         (role <> 'competitor' and selection_order is null))
);

create unique index core_single_client on public.core_pages(run_id) where role = 'client';

create table public.core_calls (
  id uuid primary key,
  run_id uuid not null references public.core_runs(id),
  page_id uuid,
  logical_key text not null, -- e.g. serp, page:<uuid>:cp:base, page:<uuid>:ip:js
  endpoint text not null check (endpoint in (
    '/v3/serp/google/organic/live/advanced',
    '/v3/on_page/content_parsing/live',
    '/v3/on_page/instant_pages',
    '/v3/dataforseo_labs/google/keyword_overview/live',
    '/v3/dataforseo_labs/google/search_intent/live',
    '/v3/dataforseo_labs/google/ranked_keywords/live'
  )),
  host_key text,
  attempt smallint not null default 0 check (attempt in (0,1)),
  enable_javascript boolean not null default false,
  retry_reason jsonb, -- baseline count/ref, threshold/ref and predicate version
  request_json jsonb not null check (
    jsonb_typeof(request_json) = 'array' and jsonb_array_length(request_json) = 1
  ),
  request_sha256 text not null check (request_sha256 ~ '^[0-9a-f]{64}$'),
  -- Exact canonical JSON UTF-8 bytes are sent. Basic auth is never stored here.
  state text not null default 'queued' check (state in
    ('queued','started','received','failed','unknown_outcome')),
  claimed_at timestamptz,
  finished_at timestamptz,
  error jsonb,
  created_at timestamptz not null default now(),
  unique (run_id, id),
  unique (run_id, logical_key),
  foreign key (run_id, page_id) references public.core_pages(run_id, id),
  check (
    (endpoint in ('/v3/on_page/content_parsing/live','/v3/on_page/instant_pages')
      and page_id is not null and host_key is not null)
    or
    (endpoint = '/v3/dataforseo_labs/google/ranked_keywords/live'
      and attempt = 0 and not enable_javascript)
    or
    (endpoint not in ('/v3/on_page/content_parsing/live','/v3/on_page/instant_pages',
                     '/v3/dataforseo_labs/google/ranked_keywords/live')
      and page_id is null and attempt = 0 and not enable_javascript)
  ),
  check (
    (attempt = 0 and not enable_javascript and retry_reason is null) or
    (attempt = 1 and enable_javascript and retry_reason is not null)
  )
);

create unique index core_one_page_attempt on public.core_calls(page_id, endpoint, attempt)
  where endpoint in ('/v3/on_page/content_parsing/live','/v3/on_page/instant_pages');
-- Ranked Keywords pagination uses unique logical_key, e.g. ranked:client:<id>:offset:1000.

create table public.core_raw_responses (
  id uuid primary key,
  run_id uuid not null,
  call_id uuid not null unique,
  received_at timestamptz not null default now(),
  http_status integer not null check (http_status between 100 and 599),
  body_base64 text not null,
  body_sha256 text not null check (body_sha256 ~ '^[0-9a-f]{64}$'),
  parsed_json jsonb, -- Null for malformed/non-JSON response; original bytes retained.
  provider_task_id text,
  unique (run_id, id),
  foreign key (run_id, call_id) references public.core_calls(run_id, id)
);

alter table public.core_pages
  add foreign key (run_id, serp_raw_id) references public.core_raw_responses(run_id, id),
  add foreign key (run_id, selected_cp_raw_id) references public.core_raw_responses(run_id, id),
  add foreign key (run_id, selected_ip_raw_id) references public.core_raw_responses(run_id, id);

create table public.core_artifacts (
  id uuid primary key,
  run_id uuid not null references public.core_runs(id),
  kind text not null check (kind in
    ('analysis','brief','generation_response','draft','coverage','export','mode_decision',
     'preserve','current_facts','entity_attributes','questions','edit_list','selection')),
  version integer not null check (version > 0),
  parent_artifact_ids uuid[] not null default '{}'::uuid[],
  -- Server validates all parent IDs and measurement refs belong to this run.
  content jsonb not null check (jsonb_typeof(content) = 'object'),
  evidence jsonb not null check (jsonb_typeof(evidence) = 'object'),
  content_sha256 text not null check (content_sha256 ~ '^[0-9a-f]{64}$'),
  created_at timestamptz not null default now(),
  unique (run_id, kind, version),
  unique (run_id, id)
);

create table public.core_mode_overrides (
  id uuid primary key,
  run_id uuid not null references public.core_runs(id),
  decision_artifact_id uuid not null,
  actor_id uuid not null references auth.users(id),
  detected_mode text check (detected_mode in ('NEW','IMPROVE','REWRITE')),
  previous_effective_mode text check (previous_effective_mode in ('NEW','IMPROVE','REWRITE')),
  effective_mode text not null check (effective_mode in ('NEW','IMPROVE','REWRITE')),
  reason text not null check (length(btrim(reason)) > 0),
  created_at timestamptz not null default now(),
  foreign key (run_id, decision_artifact_id) references public.core_artifacts(run_id, id)
);

create table public.core_jobs (
  id uuid primary key,
  run_id uuid not null references public.core_runs(id),
  logical_key text not null,
  kind text not null check (kind in ('pipeline','draft')),
  state text not null default 'queued' check (state in
    ('queued','running','waiting','complete','failed','interrupted')),
  stage text not null,
  input_artifact_ids uuid[] not null default '{}'::uuid[],
  checkpoint jsonb not null default '{}'::jsonb,
  available_at timestamptz not null default now(),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (run_id, logical_key)
);

create table public.core_worker_leases (
  name text primary key check (name = 'core_acquisition'),
  owner_token uuid not null,
  generation bigint not null check (generation > 0),
  expires_at timestamptz not null,
  active_call_id uuid references public.core_calls(id),
  updated_at timestamptz not null default now()
);
-- Technical lease/fencing metadata; not a monetary reservation.
-- A replacement worker must reconcile active_call_id before dispatching another call.

create index core_runs_owner_created on public.core_runs(owner_id, created_at desc);
create index core_calls_queue on public.core_calls(state, created_at);
create index core_calls_run_page on public.core_calls(run_id, page_id);
create index core_raw_run on public.core_raw_responses(run_id);
create index core_job_queue on public.core_jobs(state, available_at);

alter table public.core_bundles enable row level security;
alter table public.core_runs enable row level security;
alter table public.core_pages enable row level security;
alter table public.core_calls enable row level security;
alter table public.core_raw_responses enable row level security;
alter table public.core_artifacts enable row level security;
alter table public.core_mode_overrides enable row level security;
alter table public.core_jobs enable row level security;
alter table public.core_worker_leases enable row level security;

create policy core_run_read on public.core_runs for select to authenticated
  using (owner_id = (select auth.uid()));
create policy core_bundle_read on public.core_bundles for select to authenticated
  using (exists (select 1 from public.core_runs r
    where r.bundle_id = core_bundles.id and r.owner_id = (select auth.uid())));
create policy core_page_read on public.core_pages for select to authenticated
  using (exists (select 1 from public.core_runs r
    where r.id = core_pages.run_id and r.owner_id = (select auth.uid())));
create policy core_call_read on public.core_calls for select to authenticated
  using (exists (select 1 from public.core_runs r
    where r.id = core_calls.run_id and r.owner_id = (select auth.uid())));
create policy core_raw_read on public.core_raw_responses for select to authenticated
  using (exists (select 1 from public.core_runs r
    where r.id = core_raw_responses.run_id and r.owner_id = (select auth.uid())));
create policy core_artifact_read on public.core_artifacts for select to authenticated
  using (exists (select 1 from public.core_runs r
    where r.id = core_artifacts.run_id and r.owner_id = (select auth.uid())));
create policy core_override_read on public.core_mode_overrides for select to authenticated
  using (exists (select 1 from public.core_runs r
    where r.id = core_mode_overrides.run_id and r.owner_id = (select auth.uid())));
create policy core_job_read on public.core_jobs for select to authenticated
  using (exists (select 1 from public.core_runs r
    where r.id = core_jobs.run_id and r.owner_id = (select auth.uid())));

-- Explicit ACLs override broad defaults for these new tables only.
revoke all on public.core_bundles, public.core_runs, public.core_pages,
  public.core_calls, public.core_raw_responses, public.core_artifacts,
  public.core_mode_overrides, public.core_jobs, public.core_worker_leases
  from anon, authenticated, service_role;
grant select on public.core_bundles, public.core_runs, public.core_pages,
  public.core_calls, public.core_raw_responses, public.core_artifacts,
  public.core_mode_overrides, public.core_jobs to authenticated;
grant select, insert on public.core_bundles, public.core_runs, public.core_pages,
  public.core_calls, public.core_raw_responses, public.core_artifacts,
  public.core_mode_overrides, public.core_jobs, public.core_worker_leases to service_role;
grant update on public.core_runs, public.core_pages, public.core_calls,
  public.core_jobs, public.core_worker_leases to service_role;
-- Raw responses, bundles and artifacts have no application UPDATE/DELETE privilege.

commit;

-- Application transaction/validation contracts (acquisition integration step):
-- 1. Claim with UPDATE core_calls SET state='started', claimed_at=now()
--    WHERE id=:id AND state='queued' RETURNING id. Send only when one row returns.
-- 2. Save raw response before marking received. Reconcile raw rows if a crash
--    occurs between those operations; never repeat an uncertain paid request.
-- 3. Freeze query/scopes/bundle/routing/request payload after scheduling;
--    service-role updates may change lifecycle fields only.
-- 4. Hash/check source bytes and canonical JSON in code. Validate JSON Pointer
--    resolution, typed Measurement values, same-run refs and formula versions.
-- 5. Artifact version insertion is optimistic: conflict returns 409; stale edits
--    cannot overwrite a previous version. Numeric results live in evidence JSON
--    with provenance, not in writable browser-supplied metric columns.
-- 6. No budget reservations, approval tables, multi-location joins or vector store.
-- 7. Acquire/renew the named worker lease atomically using DB time and a fencing
--    generation. All job/call-dispatch changes verify the current generation.
--    Netlify's queued->started claim also verifies active_call_id + generation.
--    Expiry does not clear an active call. Reconcile received/unknown calls first.
--    Implement as service-role-only transactional RPCs before enabling paid calls.
-- 8. Client pages have role=client even when present in the first-ten SERP audit;
--    retain that observed item in the selection artifact and do not backfill an
--    eleventh URL. Client and comparison roles never enter competitor statistics.
-- 9. An override inserts an immutable event and updates effective_page_mode in
--    one transaction, with expected decision/version and owner checks. It cannot
--    bypass the exact-URL complete preservation lookup required before REWRITE.
-- 10. Validate page role on each Ranked Keywords call: domain lookup page_id=NULL,
--     exact client URL lookup references role=client. Preserve all pagination.
