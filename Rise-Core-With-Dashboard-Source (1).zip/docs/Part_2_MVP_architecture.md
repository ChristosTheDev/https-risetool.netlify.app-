# Part 2 — Core MVP architecture

Rise Marketing HQ · 2026-09-11 · Implementation contract v1.1 · approved additions A–E

**Status:** the first deterministic core slice and executable fixtures are now in `rise-core-app/`. Acquisition, model integration, UI and live writing follow in build order. No migration, deployment or paid API call was executed. This contract incorporates the approved additions A–E; full later modules remain deferred. Module 0 and KB-12 remain parked and unchanged.

Companions: `MVP_schema.sql`, `MVP_three_page_fixture.md`, `roofing_terms_v1.json`, and updated `KB-01_dataforseo_api.md` v1.2 and `KB-03_nlp_methods.md` v1.1. The code package contains configs, tests and a reproducible fixture report.

## 1. Runtime and file structure

React/Vite/Tailwind provides the form, progress, evidence tables, brief/draft editor and exports. Render hosts a FastAPI web service and a separate background worker. The web service saves jobs; the worker polls Supabase, acquires evidence and runs analysis. Netlify Functions makes every DataForSEO request; credentials stay in its environment. Supabase holds auth, immutable evidence and versioned results.

```mermaid
flowchart TD
  UI["React interface"] --> API["Render FastAPI"]
  API --> DB["Supabase jobs and evidence"]
  WORKER["Render background worker"] -->|"Claim job; save results"| DB
  WORKER -->|"Call ID and generation"| FN["Netlify background function"]
  FN -->|"Save DataForSEO response"| DB
```

Use one acquisition worker and one outstanding DataForSEO request across the MVP. This serializes hosts, including across runs. Each background invocation performs one saved task, then stores its result; it does not run the whole pipeline. Netlify background functions accommodate long calls and return an immediate acknowledgement. They can retry failed invocations, so an atomic `queued → started` claim on the saved call is mandatory before any paid request. Only that claim's winner sends it. A repeated invocation never resends a started call. [A-01]

The worker waits for a terminal saved result before dispatching another call. On restart it reconciles stored responses; an unresolved in-flight call becomes `UNKNOWN_OUTCOME` and stops acquisition until reconciled. It is never silently retried. This is dispatch deduplication, **not a spend reservation or approval workflow**. Render rolling deploys can overlap workers. A Supabase singleton lease with a monotonically increasing fencing generation enforces the acquisition constraint across processes. Every dispatch verifies the current generation; lease expiry never clears an in-flight call. Transactional RPCs must implement these checks before paid acquisition is enabled. This uses the existing database, without Redis/Celery. [A-05–A-07]

| Proposed path | Responsibility |
|---|---|
| `web/src/App.jsx`, `api.js` | Routes, authenticated requests, polling |
| `web/src/components/{RunForm,EvidenceTable,BriefEditor,DraftEditor,CoveragePanel}.jsx` | Small product views; MISSING states and denominators visible |
| `netlify/functions/dataforseo-background.js` | Background entrypoint; signature check, atomic claim, allowlisted endpoint, native `fetch`, raw response persistence |
| `engine/app/{api,worker,storage,acquisition}.py` (next step) | Render web/worker entrypoints, durable stage progression, Supabase REST access |
| `engine/rise_core/{contracts,terms,coverage,page_modes,ranked_keywords,attributes,facts,questions,edits,generation}.py` | Implemented foundation; pure calculations, parsers and provider-profile contracts |
| `engine/app/{nlp,headings,brief,draft,export}.py` (later steps) | Brief assembly, writing adapter, deterministic checker, JSON/Markdown/CSV export |
| `engine/tests/test_core.py`, `fixture_support.py`, `engine/fixture_demo.py` | Executable standard-library tests and synthetic report; no model accuracy claim |
| `config/roofing_terms_v1.json`, `config/*.json` | Versioned rules, settings, prices, source manifests |
| `supabase/migrations/001_core.sql` | Approved successor of the review-only companion schema |
| `kb/KB-01_dataforseo_api.md`, `KB-02_google_ranking_systems.md`, `KB-03_nlp_methods.md` | Claim and method sources; parked files are read-only references |

Use the approved stack, `en_core_web_sm==3.8.0`, compatible spaCy 3.8.x and scikit-learn 1.8.x, with exact patch versions locked during implementation. EntityRuler is built into spaCy. Use native JS HTTP/crypto and Python standard-library HTTP/JSON/testing; no new SDK, queue, database driver or NLP dependency is adopted. Claude uses a declarative HTTP-JSON provider profile, with provider/model in config (`claude-sonnet-5` is the current initial model setting). No SDK is required. An ASGI runner remains unconfigured: Render's FastAPI example uses Uvicorn, which is outside the approved package list and requires permission before installation. [A-08–A-10] English is the initial NLP profile; unsupported languages fail preflight explicitly, before paid calls, rather than silently using English.

## 2. Acquisition contract

Input: query, target country, language, exactly one `location_code` or exact catalogue `location_name`, one device (`desktop` default, `mobile` selectable). Optional `client_url`, `client_domain`, `other_client_urls[]` and supplied `cluster_queries[]` feed the approved page modes. Optional `vertical` selects a reviewed EntityRuler list; omitted means generic NER, not an assumed roofing vertical. Resolve the SERP selector against its catalogue and validate its country. Resolve a separate country/language pair against the Labs catalogue. Preserve both catalogue versions and selected records.

1. Pull Organic Live Advanced once. From returned `type="organic"` items, preserve provider order and take the first ten distinct usable HTTP(S) URLs. Do not assume `items_count` is an organic count. Normalize only host/scheme case, default ports and fragments; retain path case, trailing slash and query parameters. Do not merge HTTP/HTTPS, `www`, canonicals or domains. Record duplicate/rejected items and their raw pointers. Fewer than ten distinct URLs is an explicit short sample; no extra SERP call. If the client URL is among those ten, record its original SERP position but assign role=client, exclude it from the competitor denominator and do not backfill an eleventh URL.
2. For each competitor, the client URL if present, and explicitly supplied comparison URLs, call Content Parsing and Instant Pages sequentially, with JavaScript off. Content Parsing alone supplies analyzed body blocks. Instant Pages supplies heading arrays and the requested raw page counts. Preserve redirect destinations; do not silently change the selected URL denominator.
3. **Retry predicate:** successful provider/page status and a completed crawl, but Content Parsing's selected body has fewer than `near_empty_words` word tokens. Proposed CONFIG default: 50. Zero is empty; positive values below the threshold are near-empty. This is an extraction guard, not a content-length recommendation. A failed task, blocked page, timeout, malformed body or partial crawl is not this predicate.
4. If the predicate holds, retry that page **once as a pair**: one Content Parsing call and one Instant Pages call with `enable_javascript=true`. Record trigger, baseline count, threshold, both request bodies and each response cost. This is one page retry round, containing two API calls. Use that round's accepted body/measurements; retain the baseline as evidence but do not mix attempts into a synthetic page. If the retry remains short or fails, body analysis is MISSING. A baseline-successful body is not retried solely because Instant Pages failed or an optional field is absent.
5. Calculate candidates, then send one Keyword Overview request for the query plus at most 50 candidate surface phrases. Select candidates by df descending, mean normalized TF-IDF descending, then lexical key; use each candidate's most frequent observed surface form, with lexical tie-break. Normalize case/whitespace for request deduplication, without lemma-merging keyword metrics. Validate provider input limits. An invalid metric keyword is marked MISSING, not truncated. Call Search Intent for the query only.

After acquisition, the runner saves analysis and assembles the deterministic brief skeleton. With a client URL, measure coverage and determine page mode before preparing outputs. REWRITE enriches the frozen brief with the completed preservation lookup; IMPROVE produces edits. The writer fills its allowed copy slots and parity draft sections; code validates and saves the completed brief and draft, then runs coverage. This produces the initial outputs automatically. Later API calls edit or regenerate them. A failed writer leaves usable analysis and the brief skeleton, with unresolved copy/draft fields explicitly MISSING. Copy completion cannot change the skeleton's measured requirements, section tags or numeric fields.

`N_text` counts pages with accepted Content Parsing text and successful term preprocessing. Tiers use that denominator. Other stages report their own accepted page IDs and N; benchmark populations are subsets of the accepted text sample. An Instant Pages failure can leave text usable, while headings/counts on that page are MISSING. NER failure excludes the page only from NER measurements. No body failure becomes a zero.

`N_text < 5`: raw df only, `tier=null`, reason `INSUFFICIENT_SAMPLE`; still show explicitly requested descriptive measurements with the small-sample label. `5 ≤ N_text < 7`: proportional tiers with a low-sample warning. Otherwise normal proportional tiers. Compare exact fractions: Required `df/N ≥ 0.7`; Recommended `0.4 ≤ df/N < 0.7`; Differentiators `0 < df/N < 0.4`. At N=0, text analysis and a SERP-based brief/draft are MISSING.

## 3. DataForSEO wire shapes

All requests below are POSTs to `https://api.dataforseo.com`, Basic auth, one JSON task in an outer array. The shapes show the MVP subset; KB-01 DF-01–DF-08 and DF-26 retain the complete inventories and real documentation examples. Variables below are bindings, not literal strings to send.

| Endpoint | Task object inside `[task]` | Fields read from response |
|---|---|---|
| `/v3/serp/google/organic/live/advanced` | `{keyword:q, location_code:serp_code, language_code:lang, device:device, depth:10, people_also_ask_click_depth:0, load_async_ai_overview:false, calculate_rectangles:false}` | `R.keyword`, `location_code`, `language_code`, `datetime`, `item_types`; `I.type`, `rank_group`, `rank_absolute`, `url`, `domain`, `title`, `description`; PAA `I.items[].title`; AIO `references[]` and nested `items/components/expanded_element/references` with source pointers |
| `/v3/on_page/content_parsing/live` | `{url:u, accept_language:lang, enable_javascript:js, enable_browser_rendering:false, enable_xhr:false, browser_preset:device, markdown_view:false, store_raw_html:false}` | `R.crawl_progress`, `crawl_status`; `I.type`, `status_code`, `fetch_time`, `page_content` |
| `/v3/on_page/instant_pages` | `{url:u, accept_language:lang, enable_javascript:js, enable_browser_rendering:false, enable_xhr:false, browser_preset:device, load_resources:false, return_despite_timeout:false, validate_micromarkup:false, store_raw_html:false}` | `R.crawl_progress`, `crawl_status`; `I.resource_type`, `status_code`, `url`, `fetch_time`, `resource_errors`; `I.meta.htags.h1`…`h6`, `.content.plain_text_word_count`, `.images_count` |
| `/v3/dataforseo_labs/google/keyword_overview/live` | `{keywords:query_and_candidates, location_code:labs_country_code, language_code:lang, include_serp_info:false, include_clickstream_data:false}` | `R.location_code`, `language_code`; `I.keyword`, `keyword_info.{search_volume,monthly_searches,cpc,last_updated_time}`, `keyword_properties.keyword_difficulty` |
| `/v3/dataforseo_labs/google/search_intent/live` | `{keywords:[q], language_code:lang}` | `R.language_code`; `I.keyword`, `keyword_intent.{label,probability}`, `secondary_keyword_intents[]` |
| `/v3/dataforseo_labs/google/ranked_keywords/live` | `{target:domain_or_exact_https_url,location_code:country,language_code:lang,item_types:["organic"],historical_serp_mode:"live",include_clickstream_data:false,ignore_synonyms:false,load_rank_absolute:false,limit:1000,offset:offset,order_by:["keyword_data.keyword,asc"]}` | `R.target,location_code,language_code,total_count,items_count`; `I.keyword_data.keyword`; `I.ranked_serp_element.serp_item.{type,url,relative_url,rank_group,rank_absolute}`, `.last_updated_time` |

For exact-URL REWRITE preservation, add `filters:[["ranked_serp_element.serp_item.rank_group",">=",1],"and",["ranked_serp_element.serp_item.rank_group","<=",20]]`. Parse every returned page; validate exact URL identity and organic `rank_group`. Use reported totals, contiguous offsets and stable counts; changed totals, duplicates, unexpected URLs/ranks or missing pages make preservation MISSING. Domain NEW matching must scan the full returned inventory for lemma matches, not just its first page. Explicit complete zero is distinct from missing data.

`R=tasks[i].result[j]`, `I=R.items[k]`; iterate returned arrays and match URL/keyword/context rather than blindly taking index zero. The shared envelope is `{status_code,status_message,cost,tasks:[{id,status_code,status_message,cost,data,result:[]}]}`. Save its exact bytes and parsed JSON before adapting. Validate transport, envelope, task, crawl and page status separately. Native nulls and absent fields map to MISSING with their paths/reason; genuine zero stays zero. `browser_preset` only affects rendered fetches; a desktop/mobile SERP does not make the unrendered crawl device-specific. [KB-01 DF-01–DF-05]

For Content Parsing, retained paths under `page_content` are `main_topic[]` and `secondary_topic[]`: each topic's `h_title`, `primary_content[].text`, `secondary_content[].text`, and table row/cell text. Exclude `header`, `footer`, `main_title` aliases and duplicated Markdown/anchor representations. Store a selection ledger. Details and formulas remain in KB-03.

The other researched Labs endpoints have these contracts but **no MVP call sites**: Overview already returns KD, and corpus terms supply MVP candidates.

| Reference-only path | Request task | Response item shape |
|---|---|---|
| `/v3/dataforseo_labs/google/related_keywords/live` | `{keyword:q,location_code:country,language_code:lang,depth:1,limit:100,include_seed_keyword:false}` | `{keyword_data:{keyword,keyword_info,keyword_properties},depth,related_keywords}` |
| `/v3/dataforseo_labs/google/keyword_suggestions/live` | `{keyword:q,location_code:country,language_code:lang,limit:100,include_seed_keyword:false}` | `{keyword,keyword_info,keyword_properties}`; result pagination fields per KB-01; inspect all result objects |
| `/v3/dataforseo_labs/google/bulk_keyword_difficulty/live` | `{keywords:terms,location_code:country,language_code:lang}` | `{keyword,keyword_difficulty}` |

Google Ads sub-country volume is research-only in KB-01 v1.2. Microdata, grids, Maps, backlink and tracking endpoints are absent from the dispatcher allowlist.

## 4. Supabase storage and provenance

The executable-shaped schema for review is in `MVP_schema.sql`; it has not been applied.

| Table | Stored grain and important fields |
|---|---|
| `core_bundles` | Immutable content-hash bundle: KB files/full text/versions/hashes, effective settings, price sources, stopwords, ruler data/hash, package/model/code manifest |
| `core_runs` | One input and owner; local SERP scope, country Labs scope, device, vertical, bundle ID, stage/state, future routing context, idempotency key |
| `core_pages` | One URL/run with role competitor/client/client_comparison; source SERP pointer, selection order, redirect observations, accepted attempt and stage status |
| `core_calls` | One planned provider request/attempt; endpoint, host, exact request JSON, retry reason, state and timestamps; unique logical key prevents duplicate scheduling |
| `core_raw_responses` | One received response/call; exact bytes as base64, SHA-256, HTTP status and nullable parsed JSON; append-only |
| `core_artifacts` | Immutable analysis, selection, mode, preserve, fact, matrix, question, edit, brief, writing response, draft, coverage or export; content hash, parent artifact IDs, measurement/evidence graph |
| `core_mode_overrides` | Append-only event: actor, reason, detected/previous/effective mode, exact decision artifact |
| `core_jobs` | Durable pipeline/draft job, stage, checkpoint, availability and state |
| `core_worker_leases` | Service-only singleton acquisition owner, generation, expiry and active call; reconciled across Render deploys |

Authenticated users may read their own runs and descendants through RLS. All writes go through authenticated FastAPI or the signed internal function; service credentials never reach the browser. The function accepts a saved call ID, not an arbitrary endpoint/URL. Server validation checks run ownership and that all referenced pages/artifacts/raw responses belong to the run. [A-02; internal design]

Domain measurement shape:

```text
Measurement<T> = {
  status: OK | MISSING, value: T | null, unit: string,
  provenance_class: RAW | DERIVED | CONFIG | DOCUMENTATION,
  input_refs: [{kind: raw | artifact | bundle | documentation, id, json_pointer}],
  method_id: string | null, population_page_ids: string[],
  denominator_ref: string | null, reason: string | null
}
```

RAW metrics point to exact saved response fields. DERIVED metrics point to source blocks/counts and formula/configuration versions, or the exact draft artifact. CONFIG covers editorial cutoffs/caps. DOCUMENTATION covers quoted rates and documented model performance, never measured client results. DataForSEO estimates retain RAW provenance without being described as ground truth. Technical IDs/timestamps/version metadata are machine-created. MISSING has a null value and reason; no numeric placeholder is inserted.

## 5. Product API contracts

FastAPI accepts Supabase-authenticated requests. Use a run idempotency key for `POST /api/runs`; replaying the same key/input returns the existing run, and changed input returns a conflict. This does not reserve money.

```json
{
  "query": "roof repair",
  "target_country": "US",
  "language_code": "en",
  "location": {"location_name": "New York,New York,United States"},
  "device": "desktop",
  "vertical": "roofing",
  "client_url": null,
  "client_domain": null,
  "other_client_urls": [],
  "cluster_queries": []
}
```

| Route | Request | Response |
|---|---|---|
| `POST /api/estimate` | Run input | Resolved scopes, bundle ID, code-calculated base/retry scenario estimates and assumptions; no paid calls |
| `POST /api/runs` | Run input + idempotency header | `202 {run_id,state:"queued",resolved_scopes,bundle_id,estimate}` |
| `GET /api/runs/{id}` | — | `{state,stage,sample:{requested,selected,analyzed,failed},pages,page_mode,preserve_status,cost,artifact_ids,missing,warnings}`; counts are measurement references |
| `GET /api/runs/{id}/artifacts/{artifact_id}` | — | Immutable `{id,kind,version,content_sha256,content,evidence}` |
| `POST /api/runs/{id}/brief` | `{base_artifact_id,edits}` | New brief artifact; editor choices become CONFIG and are validated |
| `POST /api/runs/{id}/draft` | `{brief_artifact_id}` | `202` writing state; stored draft artifact on completion, or explicit generation failure |
| `POST /api/runs/{id}/coverage` | `{brief_artifact_id,draft:{sections:[...]}}` | Saves draft version; returns coverage artifact and that draft ID |
| `POST /api/runs/{id}/page-mode` | `{base_decision_artifact_id,effective_mode,reason}` | Effective mode and appended override event; stale decision = 409 |
| `GET /api/runs/{id}/comparison` | — | Current-page versus frozen-brief coverage, proposed-after coverage, preserve checks, triggers, facts and edit/matrix artifacts |
| `GET /api/runs/{id}/export?artifact_id=…&format=md|json|csv` | — | Download; CSV is the term table, Markdown/JSON preserve brief/draft provenance and SME labels |
| Netlify internal `POST /.netlify/functions/dataforseo-background` | Signed `{call_id,dispatch_generation}` | Background `202` acknowledgement; actual result is written to Supabase |

Common failure: `{error:{code,message,field},status:"MISSING"}` for unavailable data; validation errors use 422, ownership failures 403/404, stale edit bases 409. No automatic rerun of paid acquisition when editing/checking a draft.

## 6. Analysis interfaces and output decisions

All analysis interfaces below are pure functions over immutable inputs. Acquisition, storage and text generation are separate side effects. No analysis function calls an LLM.

```python
select_urls(serp: RawRef, policy: Settings) -> SerpSelection
extract_body(cp: RawRef, policy: TextPolicy) -> BodyView  # blocks + inclusion ledger
read_page_measures(ip: RawRef) -> PageMeasures
preprocess(body: BodyView, nlp: PinnedPipeline) -> TokenDocument
measure_terms(docs: list[TokenDocument], settings: Settings) -> TermAnalysis
measure_entities(docs: list[TokenDocument], ruler: RuleManifest) -> EntityAnalysis
cluster_headings(pages: list[PageMeasures], settings: Settings) -> HeadingAnalysis
collect_questions(serp: SerpSelection, headings: HeadingAnalysis) -> QuestionAnalysis
build_benchmarks(texts, page_measures, settings) -> Benchmarks
assemble_brief(analysis: Analysis, choices: EditorialConfig, kb: KBBundle) -> Brief
check_coverage(brief: Brief, draft: Draft, pipeline: PinnedPipeline) -> Coverage
parse_page(payload: dict, raw_id: str, lookup: Lookup, offset: int) -> RankedPage
finish_lookup(pages: list[RankedPage], lookup: Lookup) -> RankedInventory
decide_mode(client, baseline_coverage, competitors, profiles, comparisons, config) -> ModeDecision
measure_attributes(pages: list[TokenDocument], policy: AttributePolicy) -> EntityAttributeMatrix
salvage_facts(current_page: BodyView, rules: FactRules) -> SMESlots
order_edits(gaps: list[Gap], policy: GapPolicy | None) -> EditList
```

Shared DTO fields: `BodyView={page_id,raw_id,attempt,blocks:[{pointer,text}],excluded,status}`; `TokenDocument` adds tokens/lemmas, source offsets, captured entity mentions and independent stage states. `Analysis={sample,serp,terms,entities,headings,questions,intent,benchmarks,evidence}`. A term row holds its key, surface variants, n, per-page counts, df, prevalence, tier, TF range, TF-IDF values and Labs metrics as measurements. An entity mention holds source, canonical ID, label, block pointer and offsets. `Draft={brief_id,h1,sections:[{id,tag,heading_level,heading,paragraphs,evidence_refs}]}`; the H1 slot also carries its parity/SME tag. `Coverage={brief_id,draft_id,checks,score,assessed,expected,pending_sme}`. Catch an NER-stage failure separately so completed term preprocessing remains usable.

| Output | Fixed MVP method |
|---|---|
| Terms | KB-03 word/lemma/stopword rules and contiguous 1–3 grams; df and exact prevalence; observed min/max TF per 1,000 analyzed words includes valid zeroes. Smooth IDF `1 + ln((1+N)/(1+df))`, natural TF, L2-normalized document vectors. Freeze vocabulary/IDF for draft comparison. |
| Entities | Original text, ruler then model; canonical entity keys and unique page counts, with ruler/model populations and mentions separate. A mention is not evidence that the client uses a product or holds a certification. |
| Heading clusters | Normalize and vectorize unique heading texts using KB-03; cosine distance, complete linkage, threshold 0.35 CONFIG; stable input ordering and medoid/tie-break labels. Count page presence, retaining every raw H2/H3 occurrence and level. |
| Questions | PAA titles plus headings ending in `?` or beginning with a versioned English interrogative pattern; normalized exact deduplication, original text and all sources retained. Question-like headings are a heuristic, not verified FAQ schema. |
| Intent | Show Search Intent's label/probability as vendor prediction plus observed SERP item types. Never turn features into an invented second label/probability. |
| Benchmarks | Clean-body word range and separate Instant Pages raw word range; H2+H3 counts; FAQ-heading usage from an explicit phrase list; question-heading usage; image count/presence. Every aggregate shows its usable population. Schema and video inventory remain MISSING. |

An explicit empty heading array means zero for that level; a missing/null field is MISSING. Counting H2+H3 requires both levels to be known. Instant Pages groups headings by level, so it cannot establish their original parent-child hierarchy. The brief's hierarchy is editorial: H2 clusters are roots; an H3 cluster attaches to the closest H2 medoid meeting the configured cosine threshold, with lexical tie-break, otherwise becomes a root. Label this basis in the brief, never claim it reconstructs the page DOM.

### EntityRuler contract

Load `roofing_terms_v1.json` only when `vertical="roofing"`; pass its `patterns` to an `EntityRuler` with `phrase_matcher_attr="LOWER"`, `validate=true`, `overwrite_ents=false`, installed **before `ner`**. Reject conflicting identical normalized patterns during configuration validation. The ruler favors longer overlapping matches; the later NER respects existing entities. [A-03, A-04]

Capture ruler spans immediately before NER as `(block_ref,start_char,end_char,label,ent_id)`. Preserve those identities in final output with `source="ruler"`; remaining model spans have `source="model"`. Never infer source merely from the entity label. Ruler IDs supply explicit canonicalization; model entities use normalized surface plus model label. Aliases merge only through a versioned mapping. Store individual mentions, then count each canonical entity once/page overall and once/page/source. Cross-source unions must not double-count a page.

The companion roofing list is a deliberately small evaluation fixture spanning brands, materials, products and certifications. It is not a complete roofing ontology or proof of classifier accuracy. Evaluate exact span+label precision/recall separately by source on reviewed gold text; report MISSING where no labeled evaluation exists. Model output with the ruler enabled is conditional on those ruler spans; benchmark standalone model behavior separately if needed. [A-03, A-04; internal evaluation policy]

### Brief, draft and checker

`Brief` stores title/meta/H1 text slots, ordered H2/H3 sections, selected terms and observed ranges, entities, questions, target length, source refs and editing history. Default target length is the clean-body sample's min/max range, explicitly an editorial starting range, not a ranking requirement. Keep the vendor word count as a separately labeled benchmark. At N<5, no automatic “Required” language appears. Human edits select/omit candidates and become CONFIG without rewriting measured evidence.

Every section has a server-owned `SERP parity` or `NEEDS SME INPUT` tag. The latter gets a placeholder and a concrete question for experience, credentials, pricing, testimonials, local specifics or unsupported claims. A minimal mandatory SME section asks for client-specific evidence; this does not implement Module B. Parity sections reference retained competitor evidence; SEO guidance references approved KB claims. Competitor text is untrusted source material, never a control instruction or a source of client credentials.

`TextGenerator.write(ParityWritingInput) -> ParityWritingOutput` may fill only allowed title/meta/heading/body text slots. It cannot return metrics, tags, scores or analysis decisions. Mask numeric source strings behind alphabetic reference tokens before generation. Reject generated digits, detected number words/numeric entities and unauthorized reference tokens in code; only code may resolve approved tokens from stored evidence. Client numbers/claims lacking approved client evidence stay placeholders. Persist prompt/template/provider/model and writing response; the exact stored draft is an analysis input because fresh LLM prose is not deterministic. An unconfigured/failed writer yields MISSING, never a fabricated draft.

Coverage compares the saved draft to the saved brief using the same text policy. Each selected check is PASS, FAIL or MISSING: term presence and rate range, entity presence, heading-cluster match, normalized question-heading presence and clean-body target length. Count the parity H1, section headings and paragraphs once; exclude SEO title/meta and SME placeholders. Each selected requirement contributes one equal-weight check; a term passes only if its presence and configured range pass. `score = 100 × PASS / (PASS + FAIL)`; if no checks are assessable, score is MISSING. Report assessed/expected checks and pending SME sections beside it. Missing checks and SME placeholders never count as passes. This is brief coverage, not ranking probability or factual verification. Exports retain MISSING/SME labels and a needs-review state; no publication action exists.

### Approved page-mode routing and additions

| Condition/output | Contract |
|---|---|
| NEW: no client URL | Full brief + parity draft. If `client_domain` exists, scan country Labs Ranked Keywords; exact query, ordered lemma match or supplied cluster-query match produces “Possible existing page — check before building.” Keep rank, URL, freshness and match evidence. An incomplete scan cannot assert no existing page. |
| REWRITE: any true rule | Coverage <40%; opposite page-type count ≥7; five-shingle Jaccard ≥0.75 OR containment ≥0.85 against supplied client pages; or clean-body length <competitor P25 AND coverage <60%. Thresholds are CONFIG and shown beside the triggering measurements. KB-03 defines profiles, quantile and similarity. |
| IMPROVE | No rewrite rule is true and required inputs are known. Return edits for missing placements/terms, sections, questions, entities and attribute gaps; preserve the current URL. Missing required evidence yields mode MISSING, not a guessed IMPROVE. |
| Override | Store detected and effective mode separately; append actor, reason and decision reference. An override never silently removes preservation checks or verifies SME facts. |
| REWRITE drafting | Keep the exact URL. Complete the exact-URL Ranked Keywords lookup before drafting. Every reported organic keyword in positions 1–20 becomes a preserve check, irrespective of volume. Current-page facts go only to SME slots marked “FOUND ON CURRENT PAGE — VERIFY.” |
| Before/after | Mode selection uses the frozen baseline competitor brief. REWRITE then freezes an enriched brief with preserve checks; both before/after scores use that same enriched brief. Never compare scores based on different check sets. |

The page-profile quorum is seven observed opposing pages, not a proportional rescaling on a short sample. Keep observed SERP item types, lexical-profile matches, unknown labels and failed pages visible. A profile that matches both/neither category is UNKNOWN. These are uncalibrated internal profiles, not Google intent facts or LLM judgments.

The matrix is the top ten entities × top fifteen attributes (CONFIG). Attribute candidates combine the roofing list with NOUN/ADJ lemmas co-occurring with an entity in a sentence on at least two competitor pages. Rank by distinct-page count with stable ties; count each cell once/page. Cells with one or two pages are gap inputs. Keep source=ruler/model and the eligible NLP sample explicit. Co-mention does not prove an answered attribute question.

B collection is enabled: PAA + observed heading questions, with AIO reference URLs/raw pointers retained separately. The earlier unanswered-label and priority formula was not available in this context. Those outputs remain MISSING; the code does not substitute lexical absence or an LLM score. Until supplied, IMPROVE's queue is explicitly unscored rather than labeled “highest priority first.” No AIO reference crawl or new question-expansion endpoint is added implicitly.

The Render worker calls Claude through the selected HTTP-JSON profile using standard-library HTTP. `writer.provider_profile`, `writer.model`, auth env/header, request bindings, response text paths and completion states are configuration. A synthetic alternate response/request protocol tests swapping providers without editing the adapter. Persist original request/response and usage; log numerical usage as RAW separately from deterministic analysis. The pure adapter is implemented; live transport is a later step. Reject generated numerals, number words/numeric entities, unapproved fields and SME content; numerical-source binding and the pinned-language detector must be integrated before live generation.

## 7. Cost and later hooks

Estimate from the versioned KB-01 price snapshot and planned task counts using decimal arithmetic. Show a baseline plus the additional all-pages-JS-retry scenario; update planned costs when selected URLs/candidates are known. Current default scenario—ten pages, fifty distinct candidates plus query, one Search Intent keyword, no paid SERP extras—calculates to **$0.03524 baseline**, with **$0.03000 additional** if all pages receive the paired retry. These are DOCUMENTATION+CONFIG-derived estimates, not actual charges; U-05's Search Intent pricing inconsistency stays visible. Query operators/unsupported price conditions produce an explicitly incomplete estimate, not a false exact quote. [KB-01 pricing register]

Additional costs: each client/comparison page adds its own Content Parsing + Instant Pages pair and possible paired JS retry. Ranked Keywords adds $0.012/task + $0.00012/returned item; pagination is charged per task. A domain inventory size is unknown before acquisition, so show a known first-task minimum plus an explicitly unknown remaining amount, then update from returned totals. Do not present the ten-competitor baseline as the complete client/domain cost. [KB-01 DF-26/pricing]

Actual DataForSEO cost uses saved response `cost`, once per call; task costs reconcile it and are not added again. Include failed/retry calls. Timeout without a response means unknown cost: display the observed subtotal plus the count of unknown-cost calls; total is MISSING. Display DataForSEO cost separately from any configured writing-provider usage. No threshold confirmation, reservation or budget approval feature is built.

Later integration is a typed seam, not current behavior:

```text
PipelineSeed = {mode: string|null, location_set: Location[],
                core_competitor_urls: SourcedURL[]|null, source_run_ref: string|null}
```

MVP constructs a single-location seed with `mode=null` and acquires its URLs. Later Module 0 can supply the sourced URLs and bypass `select_urls` without changing analysis interfaces. Analysis is per location, not pooled. Store the seed with the run. Modules A–E receive versioned analysis/brief IDs through later orchestrator steps; no empty implementations or speculative tables are needed now.

## Source register for architecture additions

All accessed 2026-09-11. These are T2 technical contracts, not SEO ranking evidence. Internal defaults are CONFIG. SEO claims and NLP formulas retain KB-02/KB-03 source IDs.

| ID | Source | Date used |
|---|---|---|
| A-01 | [Netlify Background Functions](https://docs.netlify.com/build/functions/background-functions/) | Updated 2026-06-03 |
| A-02 | [Supabase Row Level Security](https://supabase.com/docs/guides/database/postgres/row-level-security) | Rolling documentation |
| A-03 | [spaCy EntityRuler API](https://spacy.io/api/entityruler) | Rolling documentation |
| A-04 | [spaCy rule-based matching](https://spacy.io/usage/rule-based-matching/) | Rolling documentation |
| A-05 | [Render background workers](https://render.com/docs/background-workers) | Accessed 2026-09-11 |
| A-06 | [Render web services](https://render.com/docs/web-services) | Accessed 2026-09-11 |
| A-07 | [Render deploys](https://render.com/docs/deploys) | Accessed 2026-09-11 |
| A-08 | [Render FastAPI deployment](https://render.com/docs/deploy-fastapi) | Accessed 2026-09-11 |
| A-09 | [Claude Messages API](https://platform.claude.com/docs/en/api/messages/create) | Accessed 2026-09-11 |
| A-10 | [Claude model IDs](https://platform.claude.com/docs/en/models/overview) | Accessed 2026-09-11 |

**Build order:** (1) deterministic contracts and fixtures — implemented in this package; (2) Supabase/Render/Netlify acquisition and retry integration; (3) pinned spaCy EntityRuler/NER plus heading/benchmark integration; (4) brief/edit/rewrite orchestration and Claude transport; (5) React evidence views, coverage editor and exports. Live extraction, model accuracy, DB/RLS integration and paid billing remain untested. The missing prior B policy and additional ASGI-runner dependency must be resolved before their respective integration steps.
