# MVP hand-calculated three-page fixture

Rise Marketing HQ · 2026-09-11 · Fixture plan v1.1 + executable foundation cases

**Synthetic test data, not a real SERP or measured keyword demand.** All fixture inputs are CONFIG test values. When loaded into mock raw-response records, preserve `fixture_only=true` in the test manifest. No paid API call or spaCy model evaluation was performed. The arithmetic and addition cases now run in `rise-core-app/engine/tests/test_core.py`. Gold lemmas/POS/NER are supplied test inputs; provider acquisition and statistical model integration are not claimed tested.

## 1. Frozen inputs and expected sample

Fake query: `roof repair`; country US; city New York; English; desktop; roofing.v1. Three organic items point in order to `https://a.example/roof`, `https://b.example/roof`, `https://c.example/roof`, with `rank_group` 1, 2, 3. Add one `people_also_ask` item with question `How is a roof repaired?` and one `video` item. Thus the SERP has five items but only three organic URLs. Selected/analyzed = 3/3; requested = 10. Report **“3 of 3 selected pages analyzed; 10 requested.”**

Each mock On-Page response uses successful envelope/task status, a finished crawl and page status 200. Use the real KB-01 field names. The retained Content Parsing topic lives at `/tasks/0/result/0/items/0/page_content/main_topic/0`:

| Page | `h_title` | `primary_content[0].text` | Frozen lemma blocks |
|---|---|---|---|
| A | Roof repair | GAF Timberline shingles. | `[roof,repair]`; `[gaf,timberline,shingle]` |
| B | Roof repair | GAF metal roof. | `[roof,repair]`; `[gaf,metal,roof]` |
| C | Roof inspection | Milwaukee roof inspection. | `[roof,inspection]`; `[milwaukee,roof,inspection]` |

Add `header.primary_content[0].text="Menu Menu"` and matching `main_title` aliases. Neither contributes to the body. No secondary/table text in this base fixture. Each selected body has **W=5**. The calculation fixture supplies these frozen tokens/lemmas; the later model integration test must check actual preprocessing separately instead of assuming its output.

Instant Pages deliberately measures a different text view: the retained body plus an additional one-word H3. Its fields under `/tasks/0/result/0/items/0/meta` are:

| Page | `htags.h2` | `htags.h3` | `content.plain_text_word_count` | `images_count` |
|---|---|---|---:|---:|
| A | `["Roof repair"]` | `["Shingles"]` | 6 | 2 |
| B | `["Roof repair"]` | `["Metal"]` | 6 | 0 |
| C | `["Roof inspection"]` | `["Leaks?"]` | 6 | 1 |

Other heading levels are explicit empty arrays. The difference between W=5 and the raw count 6 verifies that the TF denominator never uses the vendor count. Set fixture `near_empty_words=3` so these deliberately short pages are accepted. Production's proposed default remains 50.

**N=3 means no tiers for any term**, including terms on every page. Emit `tier=null`, `INSUFFICIENT_SAMPLE`, raw df and the low-sample explanation. Do not generate Required/Recommended/Differentiator labels from this fixture.

## 2. Complete term matrix

Build contiguous 1–3 grams within each block; punctuation/blocks break windows. There are 18 distinct terms. Let `a=1+ln(4/3)` and `b=1+ln(2)`. Count triples below are `(A,B,C)`.

| Term | Counts | df | TF/1,000 (A,B,C) | Observed range | IDF |
|---|---|---:|---|---|---|
| roof | 1,2,2 | 3 | 200,400,400 | 200–400 | 1 |
| repair | 1,1,0 | 2 | 200,200,0 | 0–200 | a |
| gaf | 1,1,0 | 2 | 200,200,0 | 0–200 | a |
| roof repair | 1,1,0 | 2 | 200,200,0 | 0–200 | a |
| timberline | 1,0,0 | 1 | 200,0,0 | 0–200 | b |
| shingle | 1,0,0 | 1 | 200,0,0 | 0–200 | b |
| gaf timberline | 1,0,0 | 1 | 200,0,0 | 0–200 | b |
| timberline shingle | 1,0,0 | 1 | 200,0,0 | 0–200 | b |
| gaf timberline shingle | 1,0,0 | 1 | 200,0,0 | 0–200 | b |
| metal | 0,1,0 | 1 | 0,200,0 | 0–200 | b |
| gaf metal | 0,1,0 | 1 | 0,200,0 | 0–200 | b |
| metal roof | 0,1,0 | 1 | 0,200,0 | 0–200 | b |
| gaf metal roof | 0,1,0 | 1 | 0,200,0 | 0–200 | b |
| inspection | 0,0,2 | 1 | 0,0,400 | 0–400 | b |
| milwaukee | 0,0,1 | 1 | 0,0,200 | 0–200 | b |
| roof inspection | 0,0,2 | 1 | 0,0,400 | 0–400 | b |
| milwaukee roof | 0,0,1 | 1 | 0,0,200 | 0–200 | b |
| milwaukee roof inspection | 0,0,1 | 1 | 0,0,200 | 0–200 | b |

TF/1,000 is `1000 × count/5`. IDF uses N=3 and the entire table's df. Natural TF gives unnormalized weight `count × IDF`. L2 normalization across **all 18 features** gives:

\[
L_A=\sqrt{1+3a^2+5b^2}=4.506452289144045
\]
\[
L_B=\sqrt{4+3a^2+4b^2}=4.521212764214211,
\quad L_C=\sqrt{4+11b^2}=5.961058725211404.
\]

Every normalized entry is recoverable by dividing the table's `count × IDF` by its page's L. Spot checks: roof = `(0.221904,0.442359,0.335511)`; gaf = `(0.285742,0.284809,0)`; inspection = `(0,0,0.568069)`. Mean normalized roof weight = `0.333258` (display rounding only). These equations, rather than duplicated implementation logic, are the test oracle. Float comparisons use an explicit tolerance; integer counts and rational rates are exact.

## 3. Entities, headings, questions and benchmarks

Ruler spans in the body paragraphs use original character offsets: A `GAF[0:3]`, `Timberline[4:14]`; B `GAF[0:3]`, `metal[4:9]`. Expected unique page counts: GAF 2, Timberline 1, metal 1, all source `ruler`. Supply a **mock model span**, C `Milwaukee[0:9]`/GPE, source `model`, page count 1. This tests source preservation/aggregation, not actual statistical NER accuracy. Certification counts are observed zero when the stage succeeds; they do not become claims about the client.

Headings normalize to five unique strings: roof repair, roof inspection, shingle, metal, leak. Fit heading TF-IDF on these unique strings, using their 1–3 grams. Roof repair versus roof inspection has cosine similarity

\[
\frac{(1+\ln 2)^2}{(1+\ln 2)^2+2(1+\ln 3)^2}=0.2455438272.
\]

Their distance exceeds 0.35, so they stay separate; all other distinct heading pairs are orthogonal. Output five clusters: roof repair occurs on pages A/B, the others on one page each. The duplicate roof repair headings share a cluster. H2+H3 count is 2 on each page. No H3 meets the H2 attachment threshold; those clusters become editorial roots.

Questions: the PAA question and `Leaks?`, each retaining its source. Clean-body length range = 5–5; separate vendor word range = 6–6. Image count range = 0–2; image presence = 2/3 pages. FAQ-heading usage = 0/3 under the exact `FAQ`/`Frequently asked questions` phrase list; question-heading usage = 1/3. Schema and page video inventory = MISSING, even though a video SERP feature is present.

## 4. Labs, cost and coverage

Mock Keyword Overview returns `roof repair` with volume 120 and KD 20; `roof` with volume 0 and KD null; omit requested `roof inspection`. Expect raw 120/20, genuine volume zero, MISSING KD and an explicitly MISSING omitted keyword. All metrics are country-scoped. Mock Search Intent returns commercial/probability 0.8 for the query; keep it separate from the city/device SERP evidence. These values are intentionally invented fixture inputs, not market claims.

For the isolated billing fixture, request these three keywords and return two. Set both envelope and task cost to the same value for each response: SERP 0.002; each of six base On-Page calls 0.00015; Overview 0.01224; Intent 0.01212. Expected sum is `0.002 + 6×0.00015 + 0.01224 + 0.01212 = $0.02726`, **not twice that amount**. One paired JS retry adds two received costs of 0.0015 each. A call with no response makes total cost MISSING while retaining the known subtotal.

Use a manually selected fixture brief (CONFIG; no tiers) with five checks: roof rate 200–400, GAF presence, roof-repair H2, the PAA question as a heading, and clean-body length 5–5. Draft:

- H1: `Roof repair` — SERP parity.
- H2: `Roof repair`; paragraph: `GAF Timberline shingles.` — SERP parity.
- A separate NEEDS SME INPUT placeholder asking for a verified project example.

Count H1 and parity H2/paragraph text once; exclude metadata and the SME placeholder. W=7, roof count=2, rate=`2000/7=285.714285…`. Roof, GAF and H2 checks pass; question and length checks fail. Coverage = **3/5 = 60%**, pending SME sections = 1. The score is a mechanical brief check, not an assessment of useful prose or ranking likelihood.

## 5. Small boundary cases for the coding step

| Case | Hand-checkable expectation |
|---|---|
| N=4, df=4 | Tier null despite prevalence 1 |
| N=5 | Required df≥4; Recommended df=2–3; Differentiators df=1; low-sample warning |
| N=6 | Required df≥5; Recommended df=3–4; Differentiators df=1–2; low-sample warning |
| N=7 | Required df≥5; Recommended df=3–4; Differentiators df=1–2; no low-sample warning |
| N=10 | Original cutoffs: Required ≥7; Recommended 4–6; Differentiators 1–3 |
| Duplicate A URL with another fragment; paid item with another URL | A selected once; paid URL excluded; original organic rank pointers preserved |
| C body fails; A/B succeed | N_text=2; roof df=2; exclude C from term/benchmark denominator, retain failure record |
| B Instant Pages fails only | N_text remains 3; applicable Instant Pages benchmark N=2; no JS retry |
| Missing `htags.h3` versus `htags.h3=[]` | Missing section count versus known zero H3 count; never conflate |
| Body word count 0 or threshold−1, successful completed fetch | One paired JS retry; log both costs and baseline evidence |
| Count exactly threshold; or 403/timeout/partial crawl | No empty-text JS retry; last three are explicit failures |
| Duplicate function invocation or uncertain paid request | Only the queued-call claim winner sends; unknown request is not automatically resent |
| `Timberline HDZ`; `GAF Master Elite` | Longer ruler span wins; preserve product/certification ID and ruler source |
| Repeated GAF and aliased Master Elite mentions | One page per canonical entity; retain every mention |
| Ruler toy gold: `GAF roofing` has BRAND; `Heavy metal music` has no material | One TP, one FP, zero FN: ruler precision 1/2, recall 1, F1 2/3; model evaluation stays separate/MISSING |
| Draft adds unobserved term | Frozen competitor IDF/vocabulary unchanged; no new fitted feature |
| Draft/schema missing, SME-only draft, or zero assessable checks | Affected checks/score MISSING; placeholders never earn points |
| Generated numeric text or an invented credential | Reject generated slot; leave MISSING/SME placeholder; no guessed replacement |
| Same bytes/config/model/code and fixed draft | Same analysis artifact content/hash; timestamps excluded from analysis hash |

Later tests must also validate source-pointer resolution, blocked/malformed extraction, table-cell retention, stopwords/negation, n-gram boundaries, ownership and immutable evidence. Fixtures verify the real failure boundaries; there is no claim of live-provider or representative roofing accuracy yet.

## 6. Approved addition cases: IMPROVE, REWRITE and preservation

The original competitor sample and five-check brief stay unchanged. The client page never enters its denominator, TF-IDF fit or P25=5 benchmark.

| Case | Hand inputs and expected result |
|---|---|
| NEW | No client URL → NEW. Mock domain inventory matches `roofs repairs` to `roof repair` through the injected fixture lemma map; supplied `roof inspection` is a cluster-query match. Both carry the existing-page warning and source URL. |
| IMPROVE | Treat the original W=7, 3/5-pass draft as the current page. Coverage=60%; it is not shorter than P25=5; no opposite-page quorum/comparison exists → IMPROVE. |
| Coverage-only REWRITE | Current H1 `Roof inspection`; body `GAF roof inspection materials service guide detail useful context projects.`; extra sentence `In business since 2004.`. Gold W=16, roof count=2, TF=125. Only GAF passes → 1/5=20%. Length is above P25; no other rule triggers. |
| Preserve inventory | Mock exact URL `https://client.example/roof`: `roof inspection` organic `rank_group=17`, `rank_absolute=23`, volume=0; `roof repair` organic `rank_group=3`, `rank_absolute=7`, volume=120. Preserve both, including the zero-volume keyword. Current stored ranks are country-scoped. |
| Before enriched brief | The old page passes GAF and preserved `roof inspection`: 2/7=200/7%. Keep baseline mode-selection 20% separate. |
| After enriched brief | Same URL. Parity text: H1 `Roof repair`; H2 `Roof repair`; `GAF`; question heading `How is a roof repaired?`; heading `Roof inspection`. Gold W=12, roof count=4, TF=1000/3. Core term/entity/section/question and both preserve checks pass; length 5–5 fails → 6/7=600/7%. Do not claim 100% or change the target to make the fixture pass. |
| Salvaged fact | Exact copied excerpt `In business since 2004.` → one NEEDS SME INPUT slot, “FOUND ON CURRENT PAGE — VERIFY,” verified=false, allowed_in_parity=false. It is not inserted in the after parity text. |

The exact mocked Ranked Keywords JSON is in `fixtures/ranked_keywords_two_preserve.json`. `engine/fixture_demo.py` produces `fixtures/fixture_report.json`, including source records and raw pointers. All inputs are explicitly synthetic. Field names follow KB-01; the model's actual tokenization remains a separate integration gate.

## 7. Attribute matrix and additional boundaries

Use a separate gold sentence set on the same three competitor identities: A `GAF warranty installation durable`; B `GAF warranty durable`; C `GAF cost`. GAF is a ruler BRAND; durable is ADJ; warranty/installation/cost are NOUN.

GAF page count=3. Warranty=2 pages, durable=2, installation=1, cost=1. All four cells are attribute gaps under the approved 1–2 rule. Durable qualifies through the corpus floor and enters the capped union; with fifteen seed attributes plus durable, the zero-count final seed `color` falls outside the top fifteen under the declared ties. Other retained absent seed cells have observed zero, not MISSING. Client-page `GAF hail` must not change the matrix. A repeated/aliased entity on one page still counts once, with ruler/model source counts retained separately.

Executable boundaries also check: coverage exactly 40%; coverage exactly 60%; client length exactly P25; P25 interpolation for 10/20/30 gives 15; seven-versus-six opposing profiles; partial coverage does not silently classify IMPROVE; five-shingle Jaccard exactly 3/4; containment exactly 17/20; short comparisons MISSING; missing and duplicate pagination; exact URL versus trailing slash; organic position versus absolute rank; provider-profile swapping; source pointers; generated numeric rejection.

B's unavailable unanswered/priority policy stays MISSING even when PAA, heading questions and AIO references are present. These tests do not treat missing headings as proof that nobody answers a question.
