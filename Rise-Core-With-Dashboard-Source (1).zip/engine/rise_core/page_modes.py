from dataclasses import dataclass
from fractions import Fraction

from .contracts import Ref, all_refs, competitors, measured, missing, normalized, url_key


@dataclass(frozen=True)
class ModePolicy:
    coverage_rewrite: Fraction = Fraction(40)
    short_coverage: Fraction = Fraction(60)
    length_quantile: Fraction = Fraction(1, 4)
    opposite_page_count: int = 7
    jaccard: Fraction = Fraction(3, 4)
    containment: Fraction = Fraction(17, 20)
    shingle_size: int = 5
    ref: Ref = Ref("page_modes.v1", "", "bundle")

    def __post_init__(self):
        if not 0 <= self.coverage_rewrite <= self.short_coverage <= 100:
            raise ValueError("Invalid coverage cutoffs")
        if not 0 <= self.length_quantile <= 1 or self.opposite_page_count < 1:
            raise ValueError("Invalid sample/quantile configuration")
        if not 0 <= self.jaccard <= 1 or not 0 <= self.containment <= 1 or self.shingle_size < 1:
            raise ValueError("Invalid duplicate configuration")


def percentile(values, q):
    """Linear interpolation at (N-1)*q, with exact rational intermediates."""
    if not values:
        return None
    values = sorted(values)
    rank = (len(values)-1)*q
    lo = rank.numerator // rank.denominator
    frac = rank-lo
    return Fraction(values[lo]) if not frac else values[lo]+frac*(values[lo+1]-values[lo])


def shingle_similarity(left, right, policy=ModePolicy()):
    # Inputs are normalized surface-word tokens; optional masks are applied before this call.
    k = policy.shingle_size
    if len(left) < k or len(right) < k:
        return None
    a = {tuple(left[i:i+k]) for i in range(len(left)-k+1)}
    b = {tuple(right[i:i+k]) for i in range(len(right)-k+1)}
    return {"jaccard": Fraction(len(a & b), len(a | b)),
            "containment": Fraction(len(a & b), min(len(a), len(b))),
            "shared_shingles": tuple(sorted(a & b)),
            "left_shingles": len(a), "right_shingles": len(b)}


def compare_client_pages(client, other_pages, policy=ModePolicy(), masked_tokens=None):
    """Only explicitly supplied comparison pages. No domain crawling.

    masked_tokens, when supplied, must have a versioned, complete page-ID mapping.
    Module 0 remains read-only. See its normal + geo-masked method contract.
    """
    if any(p.role != "client_comparison" for p in other_pages):
        raise ValueError("Comparison inputs must have the client_comparison role")
    results = []
    def tokens(page):
        return tuple(normalized(t.text) for s in page.sentences or () for t in s.tokens if t.word)
    for other in sorted(other_pages, key=lambda p: p.id):
        if url_key(other.url) == url_key(client.url):
            raise ValueError("Compare another client URL, not the client page itself")
        variants = {"normal": shingle_similarity(tokens(client), tokens(other), policy)
                    if client.text_ok and other.text_ok else None}
        if masked_tokens is not None:
            a, b = masked_tokens.get(client.id), masked_tokens.get(other.id)
            variants["geo_masked"] = shingle_similarity(a, b, policy) if a and b else None
        refs = client.refs+other.refs+(policy.ref,)
        results.append({"url": other.url, "variants": variants, "refs": refs})
    return tuple(results)


def profile_page(page, config):
    """Transparent lexical heuristic; not DataForSEO/Google page-type ground truth."""
    if not page.text_ok or page.headings is None:
        return {"label": None, "status": "MISSING", "reason": "PAGE_PROFILE_INPUT_MISSING",
                "refs": page.refs}
    headings = "\n".join(normalized(h.text) for h in page.headings if h.level in (1, 2, 3))
    body = "\n".join(normalized(s.text) for s in page.sentences)
    # Phrase matching uses word boundaries without claiming semantic entailment.
    def hits(phrases, text):
        import re
        return tuple(p for p in phrases if re.search(r"(?<!\w)"+re.escape(p)+r"(?!\w)", text))
    signals = {"service_headings": hits(config["service_heading_phrases"], headings),
               "actions": hits(config["action_phrases"], body),
               "information_headings": hits(config["information_heading_phrases"], headings),
               "explanations": hits(config["explanation_phrases"], body)}
    commercial = bool(signals["service_headings"] and signals["actions"])
    informational = bool(signals["information_headings"] and signals["explanations"])
    label = ("UNKNOWN" if commercial == informational else
             "SERVICE_COMMERCIAL" if commercial else "INFORMATIONAL")
    return {"label": label, "status": "OK", "signals": signals,
            "observed_serp_item_type": page.serp_item_type,
            "refs": page.refs+(Ref(config["version"], "", "bundle"),),
            "limitation": "Uncalibrated lexical profile; organic SERP type is not page purpose"}


def decide_mode(client_url, coverage=None, client=None, competitor_pages=(),
                client_profile=None, profiles=None, comparisons=(), policy=ModePolicy()):
    if not client_url:
        return {"status": "OK", "detected": "NEW", "effective": "NEW", "rules": ()}
    if client is None or client.role != "client" or url_key(client.url) != url_key(client_url):
        raise ValueError("A separate matching client page is required")
    profiles = profiles or {}
    refs = client.refs + all_refs(competitor_pages) + (policy.ref,)
    complete = coverage and coverage["complete"] and coverage["score"].status == "OK"
    score = coverage["score"].value if complete else None
    sample = competitors(competitor_pages)
    q25 = percentile([p.word_count for p in sample], policy.length_quantile)
    rules = []
    def rule(name, trigger, measurements, thresholds):
        rules.append({"rule": name, "state": "MISSING" if trigger is None else
                      "TRIGGERED" if trigger else "NOT_TRIGGERED",
                      "measurements": measured(measurements, refs, "page_modes.v1"),
                      "thresholds": measured(thresholds, (policy.ref,), "page_mode_thresholds.v1",
                                             provenance="CONFIG"),
                      "refs": refs})
    rule("LOW_COVERAGE", None if score is None else score < policy.coverage_rewrite,
         {"coverage": coverage["score"] if coverage else missing("COVERAGE_MISSING", refs, "coverage.v1"),
          "complete_coverage": bool(complete)}, {"below_percent": policy.coverage_rewrite})

    opposing = {"INFORMATIONAL": "SERVICE_COMMERCIAL", "SERVICE_COMMERCIAL": "INFORMATIONAL"}
    label = (client_profile or {}).get("label")
    cp_missing = not client_profile or client_profile.get("status") != "OK"
    opp = opposing.get(label)
    all_comp = [p for p in competitor_pages if p.role == "competitor"]
    count = sum(profiles.get(p.id, {}).get("label") == opp and
                profiles.get(p.id, {}).get("status") == "OK" for p in all_comp) if opp else 0
    unknown = sum(profiles.get(p.id, {}).get("status") != "OK" for p in all_comp)
    mismatch = (None if cp_missing else False if not opp else
                True if count >= policy.opposite_page_count else
                None if count+unknown >= policy.opposite_page_count else False)
    rule("PAGE_TYPE_MISMATCH", mismatch,
         {"client_profile": client_profile, "opposing_pages": count,
          "unmeasured_profiles": unknown, "selected_competitors": len(all_comp),
          "profile_evidence": profiles}, {"minimum_opposing_pages": policy.opposite_page_count})

    similarities = [v for c in comparisons for v in c["variants"].values()]
    duplicate = any(v and (v["jaccard"] >= policy.jaccard or
                          v["containment"] >= policy.containment) for v in similarities)
    rule("NEAR_DUPLICATE", True if duplicate else None if any(v is None for v in similarities) else False,
         {"comparisons": comparisons, "applicable": bool(comparisons)},
         {"jaccard_at_least": policy.jaccard, "containment_at_least": policy.containment})

    short = None if not client.text_ok or q25 is None else client.word_count < q25
    weak = None if score is None else score < policy.short_coverage
    combined = False if short is False or weak is False else None if short is None or weak is None else True
    rule("SHORT_AND_LOW_COVERAGE", combined,
         {"client_clean_words": client.word_count,
          "competitor_quantile": measured(q25, refs, "percentile_linear.v1", "words",
                                           [p.id for p in sample]) if q25 is not None else
                                  missing("NO_COMPETITOR_LENGTHS", refs, "percentile_linear.v1"),
          "coverage": coverage["score"] if coverage else None},
         {"length_quantile": policy.length_quantile, "coverage_below_percent": policy.short_coverage})
    detected = ("REWRITE" if any(r["state"] == "TRIGGERED" for r in rules) else
                None if any(r["state"] == "MISSING" for r in rules) else "IMPROVE")
    return {"status": "OK" if detected else "MISSING", "detected": detected,
            "effective": detected, "target_url": client_url, "rules": tuple(rules),
            "reason": None if detected else "MODE_INPUTS_MISSING"}


def override_mode(decision, effective, actor_id, reason, timestamp, input_ref):
    allowed = {"NEW"} if decision.get("detected") == "NEW" else {"IMPROVE", "REWRITE"}
    if effective not in allowed or not all((actor_id, reason.strip(), timestamp)):
        raise ValueError("Valid mode, actor, timestamp and a reason are required")
    event = {"actor_id": actor_id, "reason": reason, "created_at": timestamp,
             "detected": decision["detected"], "previous_effective": decision["effective"],
             "effective": effective, "decision_ref": input_ref}
    return {**decision, "effective": effective}, event
