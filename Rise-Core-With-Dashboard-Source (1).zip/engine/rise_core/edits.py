from .contracts import Ref, measured, missing


def order_edits(gaps, weights=None, config_ref=Ref("gaps.unconfigured", "", "bundle")):
    """Accept reviewed additive weights; do not invent the missing B formula.

    Each gap is {id, kind, features: {name: Measurement}, refs}. The function
    returns an explicitly unscored queue until a policy is supplied.
    """
    result = []
    for gap in gaps:
        refs = tuple(gap["refs"])+(config_ref,)
        available = weights is not None and all(
            name in gap["features"] and gap["features"][name].status == "OK" for name in weights)
        score = (measured(sum(weight*gap["features"][name].value for name, weight in weights.items()),
                          refs+tuple(r for m in gap["features"].values() for r in m.input_refs),
                          "configured_additive_gap_priority.v1") if available else
                 missing("GAP_PRIORITY_POLICY_MISSING" if weights is None else "GAP_FEATURE_MISSING",
                         refs, "configured_additive_gap_priority.v1"))
        result.append({**gap, "priority": score})
    result.sort(key=lambda e: (e["priority"].status != "OK",
                               -e["priority"].value if e["priority"].status == "OK" else 0, e["id"]))
    return {"status": "OK" if all(e["priority"].status == "OK" for e in result) and weights is not None else "MISSING",
            "ordering": "PRIORITY_DESCENDING" if weights is not None else "STABLE_UNSCORED_IDS",
            "edits": tuple(result)}
