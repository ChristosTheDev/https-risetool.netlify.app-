"""DataForSEO Ranked Keywords contracts. This module never sends a request."""
from dataclasses import dataclass
from decimal import Decimal
from typing import Callable

from .contracts import Ref, content_hash, measured, missing, normalized, url_key
from .coverage import Check

ENDPOINT = "/v3/dataforseo_labs/google/ranked_keywords/live"
CONTRACT = Ref("KB-01.v1.2", "/DF-26", "documentation")


@dataclass(frozen=True)
class Lookup:
    target: str
    kind: str  # domain | url
    location_code: int
    language_code: str
    limit: int = 1000

    def __post_init__(self):
        if self.kind not in {"domain", "url"}:
            raise ValueError("Unknown Ranked Keywords target kind")
        if type(self.limit) is not int or not 1 <= self.limit <= 1000 or type(self.location_code) is not int:
            raise ValueError("Invalid limit or country catalogue code")
        if not self.language_code:
            raise ValueError("Explicit language is required")
        if self.kind == "domain":
            if any(c in self.target for c in "/:?#@") or self.target.startswith("www."):
                raise ValueError("Domain target must omit scheme, www and path")
            if not self.target or self.target != self.target.lower():
                raise ValueError("Use a validated lower-case domain")
        elif not self.target.startswith("https://"):
            raise ValueError("HTTP-only URL targeting is UNVERIFIED in KB-01 U-13")
        else:
            url_key(self.target)

    def request(self, offset=0):
        if type(offset) is not int or offset < 0:
            raise ValueError("Offset must be a nonnegative integer")
        task = {"target": self.target, "location_code": self.location_code,
                "language_code": self.language_code, "item_types": ["organic"],
                "historical_serp_mode": "live", "include_clickstream_data": False,
                "ignore_synonyms": False, "load_rank_absolute": False,
                "limit": self.limit, "offset": offset,
                "order_by": ["keyword_data.keyword,asc"]}
        if self.kind == "url":
            task["filters"] = [["ranked_serp_element.serp_item.rank_group", ">=", 1],
                               "and", ["ranked_serp_element.serp_item.rank_group", "<=", 20]]
        return [task]


@dataclass(frozen=True)
class Ranking:
    keyword: str
    url: str
    rank: object
    keyword_ref: Ref
    url_ref: Ref
    last_updated_time: str | None


@dataclass(frozen=True)
class RankedPage:
    raw_id: str
    offset: int
    total: int | None
    item_count: int | None
    records: tuple[Ranking, ...]
    issues: tuple[str, ...]
    exclusions: tuple[dict, ...]
    cost: object


def parse_page(payload, raw_id, lookup, offset):
    refs = (Ref(raw_id, ""), CONTRACT)
    cost_value = payload.get("cost") if isinstance(payload, dict) else None
    valid_cost = (type(cost_value) in (int, float) and cost_value >= 0)
    cost = (measured(Decimal(str(cost_value)), (Ref(raw_id, "/cost"),),
                     "provider.cost", "USD", provenance="RAW") if valid_cost else
            missing("COST_NOT_RECEIVED", refs, "provider.cost", "USD"))
    issues, records, exclusions = [], [], []
    total = count = None
    try:
        if payload["status_code"] != 20000 or len(payload["tasks"]) != 1:
            raise ValueError("ENVELOPE_OR_TASK_COUNT")
        task = payload["tasks"][0]
        if task["status_code"] != 20000 or len(task["result"]) != 1:
            raise ValueError("TASK_OR_RESULT_COUNT")
        result = task["result"][0]
        if (result["target"] != lookup.target or result["location_code"] != lookup.location_code
                or result["language_code"] != lookup.language_code):
            raise ValueError("RESULT_SCOPE_MISMATCH")
        total, count = result["total_count"], result["items_count"]
        if any(type(v) is not int or v < 0 for v in (total, count)):
            raise ValueError("INVALID_COUNTS")
        items = result["items"]
        if items is None and count == 0:
            items = []
        if not isinstance(items, list) or len(items) != count or count > lookup.limit:
            raise ValueError("ITEM_COUNT_MISMATCH")
        for i, item in enumerate(items):
            base = f"/tasks/0/result/0/items/{i}"
            try:
                keyword = item["keyword_data"]["keyword"]
                ranked = item["ranked_serp_element"]
                serp = ranked["serp_item"]
                rank, url = serp["rank_group"], serp["url"]
                if not isinstance(keyword, str) or not keyword.strip():
                    raise ValueError("INVALID_KEYWORD")
                key = url_key(url)
                if serp["type"] != "organic" or type(rank) is not int or rank < 1:
                    raise ValueError("INVALID_ORGANIC_RANK")
                if ranked.get("is_lost") is True:
                    raise ValueError("LOST_RESULT_IN_LIVE_LOOKUP")
                if lookup.kind == "url" and (key != url_key(lookup.target) or rank > 20):
                    exclusions.append({"ref": Ref(raw_id, base),
                                       "reason": "OUTSIDE_EXACT_URL_OR_POSITION_SCOPE"})
                    continue
                records.append(Ranking(keyword, url,
                    measured(rank, (Ref(raw_id, base+"/ranked_serp_element/serp_item/rank_group"),),
                             "provider.rank_group", "organic position", provenance="RAW"),
                    Ref(raw_id, base+"/keyword_data/keyword"),
                    Ref(raw_id, base+"/ranked_serp_element/serp_item/url"),
                    ranked.get("last_updated_time")))
            except (KeyError, TypeError, ValueError) as error:
                issues.append(f"INVALID_ITEM:{i}:{error}")
    except (KeyError, TypeError, ValueError) as error:
        issues.append(f"INVALID_RESPONSE:{error}")
    return RankedPage(raw_id, offset, total, count, tuple(records), tuple(issues),
                      tuple(exclusions), cost)


def finish_lookup(pages, lookup):
    """Require a complete, contiguous, stable-count set, including explicit zero."""
    issues, records, seen = [], [], set()
    expected, total = 0, None
    pages = sorted(pages, key=lambda p: (p.offset, p.raw_id))
    if not pages:
        issues.append("NO_RESPONSES")
    if len({p.raw_id for p in pages}) != len(pages):
        issues.append("DUPLICATE_RESPONSE_ID")
    for page in pages:
        issues.extend(page.issues)
        if page.offset != expected:
            issues.append("NONCONTIGUOUS_PAGINATION")
        if total is None:
            total = page.total
        elif page.total != total:
            issues.append("TOTAL_CHANGED_DURING_PAGINATION")
        expected += page.item_count or 0
        if total is not None and page.item_count is not None:
            if page.item_count < lookup.limit and expected < total:
                issues.append("SHORT_NONFINAL_PAGE")
        for record in page.records:
            identity = (normalized(record.keyword), url_key(record.url))
            if identity in seen:
                issues.append("DUPLICATE_RECORD_ACROSS_PAGES")
            seen.add(identity)
            records.append(record)
    if total is None or expected != total:
        issues.append("INCOMPLETE_PAGINATION")
    if lookup.kind == "url" and any(p.exclusions for p in pages):
        issues.append("UNEXPECTED_URL_OR_POSITION_SCOPE")
    return {"complete": not issues, "issues": tuple(sorted(set(issues))),
            "records": tuple(sorted(records, key=lambda r: (normalized(r.keyword), url_key(r.url)))),
            "raw_ids": tuple(p.raw_id for p in pages),
            "exclusions": tuple(e for p in pages for e in p.exclusions),
            "target": lookup.target, "target_kind": lookup.kind,
            "scope": {"level": "country", "location_code": lookup.location_code,
                      "language_code": lookup.language_code, "device": None},
            "freshness": "Stored provider database; not a live Google ranking census"}


def preserve_items(result, lemmatize: Callable[[str], tuple[str, ...]]):
    """No truncation, minimum volume or LLM selection. Caller must block draft on MISSING."""
    if result.get("target_kind") != "url":
        raise ValueError("Preserve items require an exact client URL lookup")
    if not result["complete"]:
        return {"status": "MISSING", "reason": "INCOMPLETE_PRESERVE_LOOKUP", "items": ()}
    by_key = {}
    for record in result["records"]:
        # Defense in depth: a preserve caller must use a URL-scoped lookup.
        if not 1 <= record.rank.value <= 20:
            continue
        key = normalized(record.keyword)
        lemmas = tuple(lemmatize(record.keyword))
        if not lemmas:
            return {"status": "MISSING", "reason": "KEYWORD_PREPROCESSING_MISSING", "items": ()}
        item = by_key.setdefault(key, {"keyword": record.keyword, "rankings": [],
            "check": Check("preserve_"+content_hash(key)[:16], "preserve", lemmas,
                           ref=record.keyword_ref)})
        item["rankings"].append(record)
    return {"status": "OK", "reason": None, "items": tuple(by_key[k] for k in sorted(by_key))}


def existing_page_warnings(result, query, cluster_queries, lemmatize):
    exact = normalized(query)
    query_lemmas = tuple(lemmatize(query))
    clusters = {normalized(q) for q in cluster_queries}
    warnings = []
    for record in result["records"]:
        key = normalized(record.keyword)
        kind = ("EXACT_QUERY" if key == exact else
                "LEMMA_MATCH" if query_lemmas and tuple(lemmatize(record.keyword)) == query_lemmas else
                "CLUSTER_QUERY" if key in clusters else None)
        if kind:
            warnings.append({"message": "Possible existing page — check before building.",
                             "match": kind, "ranking": record})
    return {"warnings": tuple(warnings),
            "complete": result["complete"] and bool(query_lemmas),
            "reason": None if result["complete"] and query_lemmas else "MATCH_COVERAGE_MISSING"}


def estimate(items, tasks, price_ref=Ref("KB-01.v1.2", "/pricing/Ranked_Keywords", "documentation")):
    if type(items) is not int or type(tasks) is not int or items < 0 or tasks < 0:
        raise ValueError("Use known nonnegative counts; unknown counts are MISSING upstream")
    return measured(Decimal("0.012")*tasks+Decimal("0.00012")*items,
                    (price_ref, Ref("call_plan", "/ranked_keywords", "artifact")),
                    "ranked_price.v1", "USD")
