"""Rise Core deterministic foundation. No network or storage side effects."""

__version__ = "0.1.0"
