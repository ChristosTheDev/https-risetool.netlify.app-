from .contracts import Ref, normalized, url_key


def collect_questions(serp, raw_id, pages, config):
    """Observed universe only. Unanswered/promotion rules require the prior B policy."""
    questions, references = {}, {}
    def question(text, ref, source):
        if not isinstance(text, str) or not text.strip():
            return
        key = normalized(text).rstrip("?").strip()
        item = questions.setdefault(key, {"text": text, "sources": []})
        item["sources"].append({"source": source, "ref": ref})
    def aio_walk(node, pointer):
        if isinstance(node, list):
            for i, child in enumerate(node):
                aio_walk(child, pointer+f"/{i}")
        elif isinstance(node, dict):
            if node.get("type") == "ai_overview_reference" and isinstance(node.get("url"), str):
                try:
                    key = url_key(node["url"])
                except ValueError:
                    return
                entry = references.setdefault(key, {"url": node["url"], "refs": []})
                entry["refs"].append(Ref(raw_id, pointer))
            for key in ("items", "components", "expanded_element", "references"):
                if key in node:
                    aio_walk(node[key], pointer+"/"+key)
    serp_ok = isinstance(serp, dict) and serp.get("status_code") == 20000
    aio_seen = False
    if serp_ok:
        tasks = serp.get("tasks")
        serp_ok = isinstance(tasks, list) and bool(tasks)
        for t, task in enumerate(tasks or []):
            if task.get("status_code") != 20000 or not isinstance(task.get("result"), list):
                serp_ok = False
                continue
            for r, result in enumerate(task["result"]):
                if not isinstance(result.get("items"), list):
                    serp_ok = False
                    continue
                for i, item in enumerate(result["items"]):
                    base = f"/tasks/{t}/result/{r}/items/{i}"
                    if item.get("type") == "people_also_ask":
                        for j, child in enumerate(item.get("items") or []):
                            question(child.get("title"), Ref(raw_id, base+f"/items/{j}/title"), "PAA")
                    if item.get("type") == "ai_overview":
                        aio_seen = True
                        aio_walk(item, base)
    for page in sorted(pages, key=lambda p: p.id):
        if page.role != "competitor" or not page.text_ok or page.headings is None:
            continue
        for heading in page.headings:
            text = normalized(heading.text)
            if text.endswith("?") or any(text.startswith(prefix+" ") for prefix in config["question_prefixes"]):
                question(heading.text, heading.ref, "HEADING")
    for item in questions.values():
        item["answer_status"] = "MISSING"
        item["reason"] = "UNANSWERED_POLICY_MISSING"
        item["sources"].sort(key=lambda s: (s["source"], s["ref"]))
    return {"enabled": True, "status": "PARTIAL", "questions": tuple(questions[k] for k in sorted(questions)),
            "serp_collection_status": "OK" if serp_ok else "MISSING",
            "aio_status": "OBSERVED" if aio_seen else "NOT_RETURNED" if serp_ok else "MISSING",
            "aio_references": tuple(references[k] for k in sorted(references)),
            "reference_policy": "References retained; no extra crawl or competitor-denominator expansion",
            "scope": "Observed PAA and competitor heading questions; not every question users ask",
            "reason": "UNANSWERED_AND_GAP_PRIORITY_POLICIES_MISSING"}
