from collections import Counter
from dataclasses import dataclass
from fractions import Fraction
from math import log, sqrt

from .contracts import Ref, all_refs, competitors, measured, missing, normalized


@dataclass(frozen=True)
class TermPolicy:
    required: Fraction = Fraction(7, 10)
    recommended: Fraction = Fraction(2, 5)
    min_tiers: int = 5
    warn_below: int = 7
    max_n: int = 3
    ref: Ref = Ref("core.v1", "/terms", "bundle")

    def __post_init__(self):
        if not 0 < self.recommended < self.required <= 1:
            raise ValueError("Invalid prevalence cutoffs")
        if not 1 <= self.max_n <= 3 or not 1 <= self.min_tiers <= self.warn_below:
            raise ValueError("Invalid sample/window configuration")


def term_counts(page, max_n=3):
    counts = Counter()
    if not page.text_ok:
        return counts
    for sentence in page.sentences:
        tokens = sentence.tokens
        for start in range(len(tokens)):
            for n in range(1, max_n + 1):
                window = tokens[start:start+n]
                if len(window) != n:
                    break
                if not all(t.word and t.lemma for t in window):
                    break
                if not any(t.eligible for t in window):
                    continue
                counts[tuple(normalized(t.lemma) for t in window)] += 1
    return counts


def tier(df, n, policy=TermPolicy()):
    if not 0 <= df <= n:
        raise ValueError("DF must be between zero and the sample size")
    if n < policy.min_tiers or df == 0:
        return None
    p = Fraction(df, n)
    return ("Required" if p >= policy.required else
            "Recommended" if p >= policy.recommended else "Differentiators")


def measure_terms(pages, policy=TermPolicy()):
    sample = competitors(pages)
    refs = all_refs(pages) + (policy.ref,)
    ids = tuple(p.id for p in sample)
    n = len(sample)
    counts = {p.id: term_counts(p, policy.max_n) for p in sample}
    vocab = sorted({term for c in counts.values() for term in c})
    dfs = {t: sum(c[t] > 0 for c in counts.values()) for t in vocab}
    idfs = {t: 1 + log((1+n)/(1+dfs[t])) for t in vocab}
    norms = {p.id: sqrt(sum((counts[p.id][t]*idfs[t])**2 for t in vocab))
             for p in sample}
    rows = []
    for term in vocab:
        rates = {p.id: Fraction(1000*counts[p.id][term], p.word_count) for p in sample}
        weights = {p.id: counts[p.id][term]*idfs[term]/norms[p.id]
                   if norms[p.id] else 0.0 for p in sample}
        make = lambda value, unit="": measured(value, refs, "terms.v1", unit, ids)
        rows.append({
            "term": term,
            "counts": make({p.id: counts[p.id][term] for p in sample}, "occurrences"),
            "df": make(dfs[term], "pages"),
            "prevalence": make(Fraction(dfs[term], n), "fraction"),
            "tier": tier(dfs[term], n, policy),
            "tier_reason": "INSUFFICIENT_SAMPLE" if n < policy.min_tiers else None,
            "tf_per_1000": make(rates, "occurrences per 1000 clean words"),
            "range": make((min(rates.values()), max(rates.values())), "per 1000"),
            "idf": make(idfs[term]), "tfidf": make(weights),
            "mean_tfidf": make(sum(weights.values())/n)
        })
    return {"sample": measured(n, refs, "terms.v1", "pages", ids),
            "status": "OK" if vocab else "MISSING",
            "reason": None if vocab else "EMPTY_VOCABULARY",
            "warning": "LOW_SAMPLE" if n < policy.warn_below else None,
            "vocabulary": vocab, "rows": rows,
            "norms": measured(norms, refs, "terms.v1", population=ids) if sample else
                     missing("NO_ACCEPTED_TEXT", refs, "terms.v1")}
