"""Copies possible client facts into unverified SME slots. No truth inference."""
import re

from .contracts import Ref, content_hash


def salvage_facts(client, config):
    if client.role != "client":
        raise ValueError("Salvage is restricted to the current client page")
    if not client.text_ok:
        return {"status": "MISSING", "reason": "CURRENT_PAGE_TEXT_MISSING", "slots": ()}
    slots = []
    seen = set()
    for sentence in client.sentences:
        for category, expressions in config["patterns"].items():
            if not any(re.search(expression, sentence.text, re.I) for expression in expressions):
                continue
            key = (category, sentence.ref, sentence.text)
            if key in seen:
                continue
            seen.add(key)
            slots.append({
                "id": "sme_"+content_hash((category, sentence.ref, sentence.text))[:16],
                "tag": "NEEDS SME INPUT", "category": category,
                "status": "FOUND ON CURRENT PAGE — VERIFY", "verified": False,
                "excerpt": sentence.text, "source_url": client.url, "source_ref": sentence.ref,
                "rule_ref": Ref(config["version"], "/patterns/"+category, "bundle"),
                "prompt": "Confirm this current-page statement and supply supporting client evidence.",
                "allowed_in_parity": False})
    return {"status": "OK", "slots": tuple(slots),
            "limitation": "Pattern matches are candidates; no match does not establish that a fact is absent"}
