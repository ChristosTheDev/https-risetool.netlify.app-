from dataclasses import dataclass
from fractions import Fraction

from .contracts import Ref, measured, missing, normalized
from .terms import term_counts


@dataclass(frozen=True)
class Check:
    id: str
    kind: str
    key: tuple[str, ...] = ()
    low: Fraction | None = None
    high: Fraction | None = None
    level: int | None = None
    ref: Ref = Ref("brief", "/checks", "artifact")

    def __post_init__(self):
        if self.kind not in {"term", "entity", "heading", "question", "length", "preserve"}:
            raise ValueError("Unsupported check kind")
        if self.low is not None and self.high is not None and self.low > self.high:
            raise ValueError("Invalid check range")


def contains(sequence, needle):
    return bool(needle) and any(tuple(sequence[i:i+len(needle)]) == tuple(needle)
                               for i in range(len(sequence)-len(needle)+1))


def score_checks(checks, ref=Ref("coverage.v1", "/equal_weight", "bundle")):
    ids = [c["id"] for c in checks]
    if len(set(ids)) != len(ids):
        raise ValueError("Duplicate check IDs")
    if any(c["status"] not in {"PASS", "FAIL", "MISSING"} for c in checks):
        raise ValueError("Unknown coverage state")
    refs = tuple(r for c in checks for r in c["refs"]) + (ref,)
    passed = sum(c["status"] == "PASS" for c in checks)
    assessed = sum(c["status"] != "MISSING" for c in checks)
    return {"checks": tuple(checks), "complete": assessed == len(checks) and assessed > 0,
            "score": measured(Fraction(100*passed, assessed), refs, "coverage.v1", "%")
                     if assessed else missing("NO_ASSESSABLE_CHECKS", refs, "coverage.v1", "%"),
            "assessed": measured(assessed, refs, "coverage.v1", "checks"),
            "expected": measured(len(checks), refs, "coverage.v1", "checks")}


def check_coverage(checks, page):
    """Page is the measured parity-only draft view, or the accepted current page.

    Do not include SME placeholders, metadata, or refit competitor TF-IDF here.
    These foundation checks use exact normalized heading/lemma identities.
    Cluster-distance and placement adapters are later stages, not claimed here.
    """
    counts = term_counts(page)
    results = []
    for check in checks:
        refs = page.refs + (check.ref,)
        value, available = False, page.text_ok
        if check.kind == "term" and available:
            count = counts[check.key]
            rate = Fraction(1000*count, page.word_count)
            value = (count > 0 and (check.low is None or rate >= check.low)
                     and (check.high is None or rate <= check.high))
        elif check.kind == "length" and available:
            value = ((check.low is None or page.word_count >= check.low) and
                     (check.high is None or page.word_count <= check.high))
        elif check.kind == "entity":
            available = page.text_ok and page.ner_ok
            value = available and check.key[0] in page.entity_ids
        elif check.kind in {"heading", "question"}:
            available = page.text_ok and page.headings is not None
            value = available and any(
                (check.level is None or h.level == check.level) and
                tuple(normalized(t) for t in h.lemmas) == check.key for h in page.headings)
        elif check.kind == "preserve" and available:
            value = any(contains([normalized(t.lemma) if t.word else None for t in s.tokens],
                                 check.key) for s in page.sentences)
        results.append({"id": check.id, "kind": check.kind,
                        "status": ("PASS" if value else "FAIL") if available else "MISSING",
                        "reason": None if available else "PAGE_STAGE_MISSING", "refs": refs})
    return score_checks(results)
