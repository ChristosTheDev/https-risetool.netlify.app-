from collections import defaultdict
from dataclasses import dataclass

from .contracts import Ref, all_refs, competitors, measured, missing, normalized


@dataclass(frozen=True)
class AttributePolicy:
    seed_attributes: tuple[str, ...]
    entity_cap: int = 10
    attribute_cap: int = 15
    corpus_min_pages: int = 2
    gap_min_pages: int = 1
    gap_max_pages: int = 2
    ref: Ref = Ref("roofing.attributes.v1", "", "bundle")

    def __post_init__(self):
        if min(self.entity_cap, self.attribute_cap, self.corpus_min_pages, self.gap_min_pages) < 1:
            raise ValueError("Positive matrix settings are required")
        if self.gap_max_pages < self.gap_min_pages:
            raise ValueError("Invalid gap range")
        if len(set(self.seed_attributes)) != len(self.seed_attributes):
            raise ValueError("Duplicate seed attributes")
        if any(normalized(a) != a or " " in a for a in self.seed_attributes):
            raise ValueError("Seed attributes must be normalized single lemmas")


def measure_attributes(pages, policy):
    sample = tuple(p for p in competitors(pages) if p.ner_ok and p.pos_ok)
    refs = all_refs(pages)+(policy.ref,)
    ids = tuple(p.id for p in sample)
    if not sample:
        return {"status": "MISSING", "reason": "NO_ENTITY_ATTRIBUTE_SAMPLE",
                "sample": measured(0, refs, "entity_attributes.v1", "pages"),
                "entities": (), "attributes": (), "cells": ()}
    seeds = set(policy.seed_attributes)
    entity_pages, source_pages = defaultdict(set), defaultdict(set)
    seed_cells, corpus_cells, cell_refs = defaultdict(set), defaultdict(set), defaultdict(set)
    for page in sample:
        for sentence in page.sentences:
            entities = {m.entity_id for m in sentence.mentions}
            excluded = {i for m in sentence.mentions for i in range(m.token_start, m.token_end)}
            for m in sentence.mentions:
                if m.source not in {"ruler", "model"} or not 0 <= m.token_start < m.token_end <= len(sentence.tokens):
                    raise ValueError("Invalid entity span/source")
                entity_pages[m.entity_id].add(page.id)
                source_pages[m.entity_id, m.source].add(page.id)
            observed_seeds = {normalized(t.lemma) for i, t in enumerate(sentence.tokens)
                              if i not in excluded and t.word and normalized(t.lemma) in seeds}
            corpus = {normalized(t.lemma) for i, t in enumerate(sentence.tokens)
                      if i not in excluded and t.word and t.eligible and t.pos in {"NOUN", "ADJ"}}
            for entity in entities:
                for attr in observed_seeds:
                    seed_cells[entity, attr].add(page.id)
                    cell_refs[entity, attr].add(sentence.ref)
                for attr in corpus:
                    corpus_cells[entity, attr].add(page.id)
                    cell_refs[entity, attr].add(sentence.ref)
    eligible = {attr for (_, attr), pg in corpus_cells.items() if len(pg) >= policy.corpus_min_pages}
    union = seeds | eligible
    entity_ids = sorted(entity_pages, key=lambda e: (-len(entity_pages[e]), e))[:policy.entity_cap]
    # Rank the entire union; allocating all slots to seeds would exclude corpus discoveries.
    attr_pages = {a: set().union(*(seed_cells[e, a] if a in seeds else corpus_cells[e, a]
                                 for e in entity_ids)) for a in union}
    seed_order = {a: i for i, a in enumerate(policy.seed_attributes)}
    attributes = sorted(union, key=lambda a: (-len(attr_pages[a]), seed_order.get(a, len(seeds)), a))[:policy.attribute_cap]
    make = lambda v, r=refs: measured(v, r, "entity_attributes.v1", "pages", ids)
    cells = []
    for entity in entity_ids:
        for attr in attributes:
            pg = seed_cells[entity, attr] if attr in seeds else corpus_cells[entity, attr]
            evidence = tuple(sorted(cell_refs[entity, attr]))+(policy.ref,)
            # A zero still traces to the examined population, not an invented missing value.
            if not pg:
                evidence = refs
            cells.append({"entity": entity, "attribute": attr,
                          "page_count": make(len(pg), evidence), "page_ids": tuple(sorted(pg)),
                          "attribute_gap": policy.gap_min_pages <= len(pg) <= policy.gap_max_pages,
                          "meaning": "Same-sentence mention; not a verified answer or relationship"})
    return {"status": "OK", "sample": make(len(sample)),
            "entities": tuple({"id": e, "page_count": make(len(entity_pages[e])),
                "by_source": {s: make(len(source_pages[e, s])) for s in ("ruler", "model")}}
                for e in entity_ids),
            "attributes": tuple({"lemma": a, "sources": tuple(
                s for s, present in (("vertical", a in seeds), ("corpus", a in eligible)) if present),
                "page_count": make(len(attr_pages[a]))} for a in attributes),
            "cells": tuple(cells),
            "priority_score": missing("GAP_PRIORITY_POLICY_MISSING", refs, "gaps.unconfigured")}
