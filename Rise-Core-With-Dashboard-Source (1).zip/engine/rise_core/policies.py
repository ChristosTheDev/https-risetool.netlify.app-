from fractions import Fraction

from .attributes import AttributePolicy
from .contracts import Ref
from .page_modes import ModePolicy
from .terms import TermPolicy


def mode_policy(config):
    return ModePolicy(**{name: Fraction(str(config[name])) for name in
                         ("coverage_rewrite", "short_coverage", "length_quantile", "jaccard", "containment")},
                      opposite_page_count=config["opposite_page_count"], shingle_size=config["shingle_size"],
                      ref=Ref(config["version"], "", "bundle"))


def term_policy(config):
    if config["smooth_idf"] is not True or config["sublinear_tf"] is not False or config["norm"] != "l2":
        raise ValueError("Only the approved smoothed natural-TF L2 variant is implemented")
    return TermPolicy(Fraction(config["required"]), Fraction(config["recommended"]),
                      config["min_tiers"], config["warn_below"], config["max_n"],
                      Ref(config["version"], "", "bundle"))


def attribute_policy(config):
    return AttributePolicy(tuple(config["attributes"]), config["entity_cap"], config["attribute_cap"],
                           config["corpus_min_pages"], config["gap_min_pages"], config["gap_max_pages"],
                           Ref(config["version"], "", "bundle"))
