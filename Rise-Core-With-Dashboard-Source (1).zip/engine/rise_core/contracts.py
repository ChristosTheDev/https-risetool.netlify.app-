from __future__ import annotations

import hashlib
import json
import unicodedata
from dataclasses import asdict, dataclass, is_dataclass
from decimal import Decimal
from fractions import Fraction
from typing import Any, Literal
from urllib.parse import urlsplit, urlunsplit


@dataclass(frozen=True, order=True)
class Ref:
    id: str
    pointer: str
    kind: Literal["raw", "artifact", "bundle", "documentation"] = "raw"


@dataclass(frozen=True)
class Measurement:
    value: Any
    status: Literal["OK", "MISSING"]
    provenance_class: Literal["RAW", "DERIVED", "CONFIG", "DOCUMENTATION"]
    input_refs: tuple[Ref, ...]
    method_id: str
    unit: str = ""
    population: tuple[str, ...] = ()
    reason: str | None = None

    def __post_init__(self):
        if (self.status == "MISSING") != (self.value is None):
            raise ValueError("MISSING must have a null value; OK must not")
        if not self.input_refs:
            raise ValueError("Every measurement needs source/configuration references")
        if self.status == "MISSING" and not self.reason:
            raise ValueError("MISSING needs a reason")


def measured(value, refs, method, unit="", population=(), provenance="DERIVED"):
    return Measurement(value, "OK", provenance, tuple(sorted(set(refs))), method,
                       unit, tuple(sorted(population)))


def missing(reason, refs, method, unit="", population=()):
    return Measurement(None, "MISSING", "DERIVED", tuple(sorted(set(refs))),
                       method, unit, tuple(sorted(population)), reason)


def normalized(text: str) -> str:
    return " ".join(unicodedata.normalize("NFC", text).casefold().split())


def url_key(url: str) -> str:
    """Conservative identity: do not merge schemes, www, paths, queries or slashes."""
    parsed = urlsplit(url)
    if parsed.scheme.lower() not in ("http", "https") or not parsed.hostname:
        raise ValueError("An absolute HTTP(S) URL is required")
    if parsed.username or parsed.password:
        raise ValueError("Userinfo is not a supported page URL")
    scheme = parsed.scheme.lower()
    host = parsed.hostname.lower()
    if ":" in host:
        host = f"[{host}]"
    port = parsed.port
    if port is not None and (scheme, port) not in (("http", 80), ("https", 443)):
        host += f":{port}"
    return urlunsplit((scheme, host, parsed.path, parsed.query, ""))


def jsonable(value):
    if isinstance(value, Fraction):
        return {"numerator": value.numerator, "denominator": value.denominator}
    if isinstance(value, Decimal):
        return str(value)
    if is_dataclass(value):
        return {k: jsonable(v) for k, v in asdict(value).items()}
    if isinstance(value, dict):
        return {k: jsonable(v) for k, v in value.items()}
    if isinstance(value, (tuple, list)):
        return [jsonable(v) for v in value]
    return value


def canonical_json(value) -> str:
    return json.dumps(jsonable(value), ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False)


def content_hash(value) -> str:
    return hashlib.sha256(canonical_json(value).encode()).hexdigest()


@dataclass(frozen=True)
class Token:
    text: str
    lemma: str
    pos: str
    word: bool = True       # Full denominator: includes stopwords, excludes URL/email.
    eligible: bool = True   # Non-stop signal; multiword windows retain interior stopwords.


@dataclass(frozen=True)
class Mention:
    entity_id: str
    label: str
    source: Literal["ruler", "model"]
    token_start: int
    token_end: int


@dataclass(frozen=True)
class Sentence:
    text: str
    tokens: tuple[Token, ...]
    ref: Ref
    mentions: tuple[Mention, ...] = ()


@dataclass(frozen=True)
class Heading:
    text: str
    level: int
    lemmas: tuple[str, ...]
    ref: Ref


@dataclass(frozen=True)
class Page:
    id: str
    url: str
    role: Literal["competitor", "client", "client_comparison"]
    sentences: tuple[Sentence, ...] | None
    headings: tuple[Heading, ...] | None
    refs: tuple[Ref, ...]
    ner_ok: bool = True
    pos_ok: bool = True
    serp_item_type: str | None = None

    @property
    def word_count(self) -> int | None:
        if self.sentences is None:
            return None
        return sum(t.word for s in self.sentences for t in s.tokens)

    @property
    def text_ok(self) -> bool:
        return self.word_count is not None and self.word_count > 0

    @property
    def entity_ids(self) -> frozenset[str]:
        return frozenset(m.entity_id for s in self.sentences or () for m in s.mentions)


def competitors(pages):
    ids = [p.id for p in pages]
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate page IDs would corrupt the denominator")
    return tuple(sorted((p for p in pages if p.role == "competitor" and p.text_ok),
                        key=lambda p: p.id))


def all_refs(pages):
    return tuple(sorted({r for p in pages for r in p.refs} |
                        {s.ref for p in pages for s in p.sentences or ()}))
