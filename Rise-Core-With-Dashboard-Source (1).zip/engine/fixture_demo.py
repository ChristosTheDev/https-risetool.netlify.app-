"""Print the audited synthetic fixture report; no network, database or LLM calls."""
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent / "tests"))
from fixture_support import (brief, config, improve_client, lemma_fixture, ranked_payload,
                             rewrite_client, rewritten_client, sample, source_responses, unknown_profile)
from rise_core.contracts import canonical_json
from rise_core.coverage import check_coverage
from rise_core.facts import salvage_facts
from rise_core.page_modes import decide_mode
from rise_core.ranked_keywords import Lookup, finish_lookup, parse_page, preserve_items
from rise_core.terms import measure_terms


def report():
    comps = sample()
    improve, before, after = improve_client(), rewrite_client(), rewritten_client()
    lookup = Lookup(before.url, "url", 2840, "en")
    result = finish_lookup([parse_page(ranked_payload(), "raw_ranked", lookup, 0)], lookup)
    preservation = preserve_items(result, lemma_fixture)
    enriched = brief()+tuple(i["check"] for i in preservation["items"])
    profiles = {p.id: unknown_profile() for p in comps}
    def decision(p):
        return decide_mode(p.url, check_coverage(brief(), p), p, comps, unknown_profile(), profiles)
    return {"fixture_only": True, "language_inference": "Hand-annotated; no spaCy model run",
            "source_records": source_responses(comps+(improve, before, after)),
            "gold_pages": comps+(improve, before, after),
            "terms": measure_terms(comps), "new": decide_mode(None),
            "improve": {"decision": decision(improve), "coverage": check_coverage(brief(), improve)},
            "rewrite": {"decision": decision(before), "preserve": preservation,
                "same_frozen_enriched_brief": enriched,
                "before_coverage": check_coverage(enriched, before),
                "after_coverage": check_coverage(enriched, after),
                "sme": salvage_facts(before, config("client_fact_patterns.v1.json"))},
            "unanswered_policy": "MISSING", "gap_priority_policy": "MISSING"}


if __name__ == "__main__":
    print(canonical_json(report()))
