import copy
import json
import unittest
from dataclasses import replace
from decimal import Decimal
from fractions import Fraction as F

from rise_core.attributes import AttributePolicy, measure_attributes
from rise_core.contracts import Mention, Ref, Token, canonical_json, measured, missing, url_key
from rise_core.coverage import Check, check_coverage, score_checks
from rise_core.edits import order_edits
from rise_core.facts import salvage_facts
from rise_core.generation import build_request, pointer, read_response, validate_slots
from rise_core.page_modes import (ModePolicy, compare_client_pages, decide_mode, override_mode,
                                  percentile, profile_page, shingle_similarity)
from rise_core.policies import mode_policy, term_policy, attribute_policy
from rise_core.questions import collect_questions
from rise_core.ranked_keywords import (Lookup, estimate, existing_page_warnings, finish_lookup,
                                       parse_page, preserve_items)
from rise_core.terms import measure_terms, term_counts, tier
from fixture_support import (brief, config, heading, improve_client, lemma_fixture, page,
                             ranked_payload, rewrite_client, rewritten_client, sample, sentence,
                             unknown_profile, source_responses)


class TermsAndCoverage(unittest.TestCase):
    def test_complete_hand_matrix(self):
        result = measure_terms(sample())
        rows = {r["term"]: r for r in result["rows"]}
        expected = {
            "roof": (1, 2, 2), "repair": (1, 1, 0), "gaf": (1, 1, 0), "roof repair": (1, 1, 0),
            "timberline": (1, 0, 0), "shingle": (1, 0, 0), "gaf timberline": (1, 0, 0),
            "timberline shingle": (1, 0, 0), "gaf timberline shingle": (1, 0, 0),
            "metal": (0, 1, 0), "gaf metal": (0, 1, 0), "metal roof": (0, 1, 0),
            "gaf metal roof": (0, 1, 0), "inspection": (0, 0, 2), "milwaukee": (0, 0, 1),
            "roof inspection": (0, 0, 2), "milwaukee roof": (0, 0, 1),
            "milwaukee roof inspection": (0, 0, 1)}
        self.assertEqual(set(rows), {tuple(t.split()) for t in expected})
        for text, counts in expected.items():
            row = rows[tuple(text.split())]
            self.assertEqual(tuple(row["counts"].value.values()), counts)
            self.assertEqual(row["df"].value, sum(v > 0 for v in counts))
            self.assertEqual(tuple(row["tf_per_1000"].value.values()), tuple(F(v*200) for v in counts))
            self.assertIsNone(row["tier"])
        self.assertEqual(rows[("roof",)]["idf"].value, 1)
        self.assertAlmostEqual(result["norms"].value["A"], 4.506452289144045, places=12)
        self.assertAlmostEqual(result["norms"].value["B"], 4.521212764214211, places=12)
        self.assertAlmostEqual(result["norms"].value["C"], 5.961058725211404, places=12)

    def test_sample_floors(self):
        for n, expected in [(4, [None]*4), (5, ["Differentiators", "Recommended", "Recommended", "Required", "Required"]),
                            (6, ["Differentiators"]*2+["Recommended"]*2+["Required"]*2),
                            (7, ["Differentiators"]*2+["Recommended"]*2+["Required"]*3)]:
            self.assertEqual([tier(df, n) for df in range(1, n+1)], expected)
        self.assertEqual(tier(7, 10), "Required")
        self.assertEqual(tier(4, 10), "Recommended")
        self.assertEqual(tier(3, 10), "Differentiators")

    def test_client_and_failed_pages_excluded(self):
        base = measure_terms(sample())
        self.assertEqual(base["sample"].value, measure_terms(sample()+(rewrite_client(),))["sample"].value)
        failed = replace(sample()[2], sentences=None)
        result = measure_terms(sample()[:2]+(failed,))
        self.assertEqual(result["sample"].value, 2)
        self.assertEqual(result["sample"].population, ("A", "B"))
        self.assertEqual(measure_terms((failed,))["status"], "MISSING")

    def test_stopwords_and_punctuation_do_not_bridge(self):
        s = sentence("x", 0, "roof and repair", ["roof", "and", "repair"], eligible=[True, False, True])
        p = page("x", [s])
        self.assertEqual(p.word_count, 3)
        self.assertNotIn(("roof", "repair"), term_counts(p))
        self.assertEqual(term_counts(p)[("roof", "and", "repair")], 1)
        self.assertNotIn(("and",), term_counts(p))
        s = replace(s, tokens=(Token("roof", "roof", "NOUN"), Token(",", ",", "PUNCT", False, False), Token("repair", "repair", "NOUN")))
        self.assertNotIn(("roof", "repair"), term_counts(page("x", [s])))

    def test_coverage_fixture(self):
        client = improve_client()
        result = check_coverage(brief(), client)
        self.assertEqual(client.word_count, 7)
        self.assertEqual(result["score"].value, 60)
        self.assertEqual([c["status"] for c in result["checks"]], ["PASS", "PASS", "PASS", "FAIL", "FAIL"])

    def test_partial_coverage_reports_denominator(self):
        result = check_coverage(brief(), replace(improve_client(), headings=None))
        self.assertFalse(result["complete"])
        self.assertEqual(result["assessed"].value, 3)
        self.assertEqual(result["expected"].value, 5)
        self.assertEqual(result["score"].value, F(200, 3))
        self.assertEqual(check_coverage(brief(), replace(improve_client(), sentences=None))["score"].status, "MISSING")

    def test_reproducible_serialization(self):
        self.assertEqual(canonical_json(measure_terms(sample())), canonical_json(measure_terms(tuple(reversed(sample())))))

    def test_gold_source_pointers_resolve_to_exact_text(self):
        pages = sample()+(improve_client(), rewrite_client(), rewritten_client())
        raw = source_responses(pages)
        for p in pages:
            for s in p.sentences:
                self.assertEqual(pointer(raw[s.ref.id], s.ref.pointer), s.text)
            for h in p.headings:
                self.assertEqual(pointer(raw[h.ref.id], h.ref.pointer), h.text)


class ModeTests(unittest.TestCase):
    def test_versioned_config_changes_rules(self):
        cfg = config("page_modes.v1.json")
        policy = mode_policy({**cfg, "coverage_rewrite": "61", "short_coverage": "70"})
        self.assertEqual(self.decision(improve_client(), policy=policy)["detected"], "REWRITE")
        self.assertEqual(term_policy(config("terms.v1.json")).required, F(7, 10))
        self.assertEqual(attribute_policy(config("roofing_attributes.v1.json")).attribute_cap, 15)

    def decision(self, client, coverage=None, **kwargs):
        return decide_mode(client.url, coverage or check_coverage(brief(), client), client,
                           kwargs.pop("competitor_pages", sample()),
                           kwargs.pop("client_profile", unknown_profile()),
                           kwargs.pop("profiles", {p.id: unknown_profile() for p in sample()}), **kwargs)

    def test_new_improve_rewrite(self):
        self.assertEqual(decide_mode(None)["detected"], "NEW")
        self.assertEqual(self.decision(improve_client())["detected"], "IMPROVE")
        result = self.decision(rewrite_client())
        self.assertEqual(result["detected"], "REWRITE")
        self.assertEqual([r["rule"] for r in result["rules"] if r["state"] == "TRIGGERED"], ["LOW_COVERAGE"])
        self.assertEqual(result["target_url"], rewrite_client().url)

    def fraction_coverage(self, passes, n):
        return score_checks([{"id": str(i), "status": "PASS" if i < passes else "FAIL",
                              "refs": (Ref("fixture", "/checks", "bundle"),)} for i in range(n)])

    def test_strict_coverage_threshold(self):
        self.assertEqual(self.decision(improve_client(), self.fraction_coverage(2, 5))["detected"], "IMPROVE")
        self.assertEqual(self.decision(improve_client(), self.fraction_coverage(39, 100))["detected"], "REWRITE")

    def test_percentile_and_short_conjunction(self):
        self.assertEqual(percentile([10, 20, 30], F(1, 4)), 15)
        self.assertIsNone(percentile([], F(1, 4)))
        def length_page(i, n, role="competitor"):
            return page(i, [sentence(i, 0, " ".join(["roof"]*n), ["roof"]*n)], role=role)
        comps = tuple(length_page(str(i), n) for i, n in enumerate((10, 20, 30)))
        client = length_page("client", 14, "client")
        result = self.decision(client, self.fraction_coverage(1, 2), competitor_pages=comps)
        self.assertEqual(result["detected"], "REWRITE")
        self.assertEqual(result["rules"][-1]["state"], "TRIGGERED")
        exact = length_page("client", 15, "client")
        self.assertEqual(self.decision(exact, self.fraction_coverage(1, 2), competitor_pages=comps)["detected"], "IMPROVE")
        self.assertEqual(self.decision(client, self.fraction_coverage(3, 5), competitor_pages=comps)["detected"], "IMPROVE")

    def test_page_type_absolute_quorum_not_proportional(self):
        comps = tuple(replace(sample()[0], id=f"p{i}") for i in range(10))
        profile = {"status": "OK", "label": "INFORMATIONAL"}
        profiles = {p.id: {"status": "OK", "label": "SERVICE_COMMERCIAL" if i < 7 else "UNKNOWN"}
                    for i, p in enumerate(comps)}
        result = self.decision(improve_client(), competitor_pages=comps, client_profile=profile, profiles=profiles)
        self.assertEqual(result["detected"], "REWRITE")
        profiles["p6"] = unknown_profile()
        self.assertEqual(self.decision(improve_client(), competitor_pages=comps,
                         client_profile=profile, profiles=profiles)["detected"], "IMPROVE")

    def test_missing_inputs_do_not_default_to_improve(self):
        bad = replace(improve_client(), headings=None)
        self.assertEqual(self.decision(bad)["status"], "MISSING")
        result = self.decision(rewrite_client(), client_profile={"status": "MISSING", "label": None})
        self.assertEqual(result["detected"], "REWRITE")  # known low coverage suffices

    def test_shingles_containment_and_short_missing(self):
        a = tuple("abcdefghijk")
        b = tuple("abcdefghijz")
        result = shingle_similarity(a, b)
        self.assertEqual(result["jaccard"], F(3, 4))
        self.assertEqual(result["containment"], F(6, 7))
        self.assertEqual(shingle_similarity(a, a+tuple("lmnop"))["containment"], 1)
        self.assertIsNone(shingle_similarity(tuple("abcd"), a))
        c = improve_client()
        other = replace(c, id="other", role="client_comparison", url="https://client.example/other")
        comparisons = compare_client_pages(c, [other])
        self.assertEqual(self.decision(c, comparisons=comparisons)["detected"], "REWRITE")

    def test_duplicate_exact_boundaries(self):
        for name, value in (("jaccard", F(3, 4)), ("containment", F(17, 20))):
            v = {"jaccard": F(0), "containment": F(0)}
            v[name] = value
            comparisons = ({"url": "https://client.example/other", "variants": {"normal": v}},)
            self.assertEqual(self.decision(improve_client(), comparisons=comparisons)["detected"], "REWRITE")

    def test_override_is_separate_event(self):
        old = self.decision(rewrite_client())
        new, event = override_mode(old, "IMPROVE", "writer", "Retain structure", "2026-09-11T00:00:00Z",
                                   Ref("mode_before", "", "artifact"))
        self.assertEqual(old["effective"], "REWRITE")
        self.assertEqual(new["detected"], "REWRITE")
        self.assertEqual(new["effective"], "IMPROVE")
        self.assertEqual(event["previous_effective"], "REWRITE")

    def test_transparent_page_profiles(self):
        p = page("x", [sentence("x", 0, "Contact us", ["contact", "us"])],
                 [heading("x", "Roof repair", ["roof", "repair"])])
        cfg = config("page_profiles.roofing.v1.json")
        result = profile_page(p, cfg)
        self.assertEqual(result["label"], "SERVICE_COMMERCIAL")
        self.assertEqual(result["signals"]["actions"], ("contact us",))
        self.assertEqual(profile_page(replace(p, headings=None), cfg)["status"], "MISSING")


class RankedTests(unittest.TestCase):
    def setUp(self):
        self.lookup = Lookup("https://client.example/roof", "url", 2840, "en")

    def result(self, payload=None):
        return finish_lookup([parse_page(payload or ranked_payload(), "raw_ranked", self.lookup, 0)], self.lookup)

    def test_contract_preserves_organic_rank_group(self):
        req = self.lookup.request()
        self.assertEqual(len(req), 1)
        self.assertEqual(req[0]["item_types"], ["organic"])
        result = self.result()
        self.assertTrue(result["complete"])
        items = preserve_items(result, lemma_fixture)["items"]
        self.assertEqual([i["keyword"] for i in items], ["roof inspection", "roof repair"])
        self.assertEqual([i["rankings"][0].rank.value for i in items], [17, 3])
        self.assertTrue(items[0]["rankings"][0].rank.input_refs[0].pointer.endswith("rank_group"))
        self.assertEqual(estimate(2, 1).value, Decimal("0.01224"))

    def test_two_pages_and_incomplete_page(self):
        lookup = replace(self.lookup, limit=1)
        payloads = []
        for item in ranked_payload()["tasks"][0]["result"][0]["items"]:
            payload = ranked_payload()
            payload["tasks"][0]["result"][0].update(items=[item], items_count=1)
            payloads.append(payload)
        first = parse_page(payloads[0], "r0", lookup, 0)
        self.assertFalse(finish_lookup([first], lookup)["complete"])
        result = finish_lookup([first, parse_page(payloads[1], "r1", lookup, 1)], lookup)
        self.assertTrue(result["complete"])
        self.assertEqual(preserve_items(finish_lookup([first], lookup), lemma_fixture)["status"], "MISSING")
        self.assertFalse(finish_lookup([first, parse_page(payloads[0], "r1", lookup, 1)], lookup)["complete"])

    def test_response_failures_and_explicit_empty(self):
        for field, value in (("total_count", 3), ("items_count", 0), ("location_code", 999)):
            payload = ranked_payload()
            payload["tasks"][0]["result"][0][field] = value
            self.assertFalse(self.result(payload)["complete"])
        payload = ranked_payload()
        payload["tasks"][0]["result"][0].update(total_count=0, items_count=0, items=None)
        self.assertEqual(preserve_items(self.result(payload), lemma_fixture)["items"], ())

    def test_url_identity_and_position_limits(self):
        payload = ranked_payload()
        items = payload["tasks"][0]["result"][0]["items"]
        items[0]["ranked_serp_element"]["serp_item"]["url"] = "https://client.example/roof/"
        items[1]["ranked_serp_element"]["serp_item"]["rank_group"] = 21
        result = self.result(payload)
        self.assertEqual(len(result["exclusions"]), 2)
        self.assertFalse(result["records"])
        self.assertFalse(result["complete"])
        self.assertEqual(url_key("HTTPS://CLIENT.EXAMPLE:443/roof#top"), "https://client.example/roof")
        self.assertNotEqual(url_key("http://client.example/roof"), url_key("https://client.example/roof"))

    def test_new_domain_warning_with_lemma_match(self):
        lookup = Lookup("client.example", "domain", 2840, "en")
        payload = ranked_payload()
        payload["tasks"][0]["result"][0]["target"] = "client.example"
        result = finish_lookup([parse_page(payload, "domain_raw", lookup, 0)], lookup)
        warnings = existing_page_warnings(result, "roofs repairs", ["roof inspection"], lemma_fixture)
        self.assertEqual({w["match"] for w in warnings["warnings"]}, {"LEMMA_MATCH", "CLUSTER_QUERY"})
        self.assertTrue(warnings["complete"])
        with self.assertRaises(ValueError):
            preserve_items(result, lemma_fixture)

    def test_rewrite_same_frozen_enriched_brief_and_sme(self):
        preservation = preserve_items(self.result(), lemma_fixture)
        enriched = brief()+tuple(i["check"] for i in preservation["items"])
        old, new = rewrite_client(), rewritten_client()
        self.assertEqual(check_coverage(brief(), old)["score"].value, 20)
        self.assertEqual(check_coverage(enriched, old)["score"].value, F(200, 7))
        self.assertEqual(check_coverage(enriched, new)["score"].value, F(600, 7))
        self.assertEqual(old.url, new.url)
        slots = salvage_facts(old, config("client_fact_patterns.v1.json"))["slots"]
        self.assertEqual(len(slots), 1)
        self.assertEqual(slots[0]["excerpt"], "In business since 2004.")
        self.assertFalse(slots[0]["verified"])
        self.assertFalse(slots[0]["allowed_in_parity"])


class AttributeAndQuestionTests(unittest.TestCase):
    def make_matrix(self, extra=()):
        fixtures = []
        for pid, words in (("A", ["GAF", "warranty", "installation", "durable"]),
                           ("B", ["GAF", "warranty", "durable"]), ("C", ["GAF", "cost"])):
            fixtures.append(page(pid, [sentence(pid, 0, " ".join(words), [w.lower() for w in words],
                [Mention("brand.gaf", "BRAND", "ruler", 0, 1)],
                pos=["PROPN"]+["ADJ" if w == "durable" else "NOUN" for w in words[1:]])]))
        policy = AttributePolicy(tuple(config("roofing_attributes.v1.json")["attributes"]))
        return measure_attributes(tuple(fixtures)+extra, policy)

    def test_hand_attribute_counts_and_corpus_cap(self):
        matrix = self.make_matrix()
        cells = {c["attribute"]: c for c in matrix["cells"]}
        self.assertEqual(matrix["sample"].value, 3)
        self.assertEqual(cells["warranty"]["page_count"].value, 2)
        self.assertEqual(cells["durable"]["page_count"].value, 2)
        self.assertEqual(cells["installation"]["page_count"].value, 1)
        self.assertEqual(cells["cost"]["page_count"].value, 1)
        self.assertTrue(cells["warranty"]["attribute_gap"])
        self.assertFalse(cells["hail"]["attribute_gap"])
        self.assertNotIn("color", cells)
        self.assertEqual(len(matrix["attributes"]), 15)
        self.assertEqual(matrix["priority_score"].status, "MISSING")

    def test_client_exclusion_and_source_union(self):
        client = page("client", [sentence("client", 0, "GAF hail", ["gaf", "hail"],
                      [Mention("brand.gaf", "BRAND", "model", 0, 1)])], role="client")
        matrix = self.make_matrix((client,))
        self.assertEqual(matrix["sample"].value, 3)
        self.assertEqual(next(c for c in matrix["cells"] if c["attribute"] == "hail")["page_count"].value, 0)
        same = page("x", [sentence("x", 0, "GAF GAF warranty", ["gaf", "gaf", "warranty"],
                    [Mention("brand.gaf", "BRAND", "ruler", 0, 1), Mention("brand.gaf", "BRAND", "model", 1, 2)])])
        result = measure_attributes((same,), AttributePolicy(("warranty",)))
        self.assertEqual(result["entities"][0]["page_count"].value, 1)
        self.assertEqual(result["cells"][0]["page_count"].value, 1)
        self.assertEqual(result["entities"][0]["by_source"]["model"].value, 1)

    def test_questions_are_not_claimed_unanswered(self):
        serp = {"status_code": 20000, "tasks": [{"status_code": 20000, "result": [{"items": [
            {"type": "people_also_ask", "items": [{"title": "How is a roof repaired?"}]},
            {"type": "ai_overview", "items": [{"type": "ai_overview_element", "references": [
                {"type": "ai_overview_reference", "url": "https://reference.example/roof"}]}]}]}]}]}
        result = collect_questions(serp, "serp_raw", sample(), config("questions.en.v1.json"))
        self.assertEqual(len(result["questions"]), 2)
        self.assertTrue(all(q["answer_status"] == "MISSING" for q in result["questions"]))
        self.assertEqual(result["aio_status"], "OBSERVED")
        self.assertEqual(result["aio_references"][0]["refs"][0].pointer,
                         "/tasks/0/result/0/items/1/items/0/references/0")

    def test_no_priority_formula_is_invented(self):
        gap = {"id": "gap_a", "kind": "attribute", "features": {}, "refs": (Ref("matrix", "", "artifact"),)}
        result = order_edits([gap])
        self.assertEqual(result["status"], "MISSING")
        self.assertEqual(result["ordering"], "STABLE_UNSCORED_IDS")


class WriterContractTests(unittest.TestCase):
    def test_provider_can_change_through_json_profile(self):
        # A synthetic second protocol proves the adapter is not tied to Anthropic's body layout.
        alternate = {"method": "POST", "url": "https://writer.example/generate", "headers": {},
            "auth": {"header": "Authorization", "prefix": "Bearer ", "env_binding": "api_key_env"},
            "request_template": {"deployment": {"$bind": "model"}, "instruction": {"$bind": "system"},
                                 "input": {"$bind": "prompt"}},
            "response": {"text_pointers": ["/answer"], "stop_pointer": "/state",
                         "accepted_stop_values": ["done"], "usage_pointer": "/usage"}}
        writer = {"model": "fixture-model", "api_key_env": "FIXTURE_WRITER_KEY", "max_tokens": 100}
        slots = [{"id": "intro", "tag": "SERP parity", "source_role": "competitor", "evidence_text": "Roof repair guide"}]
        self.assertEqual(build_request(alternate, writer, slots)["body"]["deployment"], "fixture-model")
        self.assertEqual(read_response(alternate, {"answer": '{"intro":"Roof guide"}', "state": "done", "usage": {}})[0],
                         {"intro": "Roof guide"})

    def test_request_excludes_sme_and_rejects_numeric_evidence(self):
        profile = config("anthropic.messages.v1.json")
        writer = config("runtime.v1.json")["writer"]
        slots = [{"id": "intro", "tag": "SERP parity", "source_role": "competitor", "evidence_text": "Roof repair guide"}]
        request = build_request(profile, writer, slots)
        self.assertEqual(request["body"]["model"], writer["model"])
        self.assertEqual(request["auth"]["env"], "ANTHROPIC_API_KEY")
        with self.assertRaises(ValueError):
            build_request(profile, writer, [{**slots[0], "tag": "NEEDS SME INPUT"}])
        with self.assertRaises(ValueError):
            build_request(profile, writer, [{**slots[0], "source_role": "client"}])
        with self.assertRaises(ValueError):
            build_request(profile, writer, [{**slots[0], "evidence_text": "Since 2004"}])

    def test_response_shape_and_numeric_rejection(self):
        profile = config("anthropic.messages.v1.json")
        payload = {"content": [{"type": "text", "text": '{"intro":"Roof repair guide"}'}],
                   "stop_reason": "end_turn", "usage": {"input_tokens": 10, "output_tokens": 5}}
        output, usage = read_response(profile, payload)
        self.assertEqual(validate_slots(output, ["intro"], lambda _: ())["intro"]["status"], "OK")
        for text in ("Since 2004", "twenty years", "½ price", "three options"):
            with self.assertRaises(ValueError):
                validate_slots({"intro": text}, ["intro"], lambda _: ())
        with self.assertRaises(ValueError):
            read_response(profile, {**payload, "stop_reason": "max_tokens"})
        with self.assertRaises(ValueError):
            validate_slots({"intro": 4}, ["intro"], lambda _: ())


if __name__ == "__main__":
    unittest.main()
