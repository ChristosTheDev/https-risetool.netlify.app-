import json
from pathlib import Path

from rise_core.contracts import Heading, Mention, Page, Ref, Sentence, Token
from rise_core.coverage import Check

ROOT = Path(__file__).resolve().parents[2]


def config(name):
    return json.loads((ROOT / "config" / name).read_text())


def sentence(page_id, index, text, lemmas, mentions=(), pos=None, word_flags=None, eligible=None):
    # Gold annotations supplied by the test author, not asserted spaCy predictions.
    surfaces = text.rstrip(".?").split()
    assert len(surfaces) == len(lemmas), (surfaces, lemmas)
    tokens = tuple(Token(t, lemma, pos[i] if pos else "NOUN",
                         word_flags[i] if word_flags else True,
                         eligible[i] if eligible else True)
                   for i, (t, lemma) in enumerate(zip(surfaces, lemmas)))
    pointer = ("/tasks/0/result/0/items/0/page_content/main_topic/0/h_title" if index == 0 else
               f"/tasks/0/result/0/items/0/page_content/main_topic/0/primary_content/{index-1}/text")
    return Sentence(text, tokens, Ref("fixture_cp_"+page_id, pointer),
                    tuple(mentions))


def heading(page_id, text, lemmas, level=2, index=0):
    return Heading(text, level, tuple(lemmas), Ref("fixture_ip_"+page_id,
                   f"/tasks/0/result/0/items/0/meta/htags/h{level}/{index}"))


def page(page_id, sentences, headings=(), role="competitor", url=None, **kwargs):
    return Page(page_id, url or f"https://{page_id.lower()}.example/roof", role,
                None if sentences is None else tuple(sentences),
                None if headings is None else tuple(headings),
                (Ref("fixture_cp_"+page_id, ""), Ref("fixture_gold.v1", "/"+page_id, "bundle")),
                serp_item_type="organic" if role == "competitor" else None, **kwargs)


def sample():
    a = page("A", [sentence("A", 0, "Roof repair", ["roof", "repair"]),
        sentence("A", 1, "GAF Timberline shingles.", ["gaf", "timberline", "shingle"],
                 [Mention("brand.gaf", "BRAND", "ruler", 0, 1),
                  Mention("product.timberline", "PRODUCT", "ruler", 1, 2)])],
        [heading("A", "Roof repair", ["roof", "repair"]), heading("A", "Shingles", ["shingle"], 3)])
    b = page("B", [sentence("B", 0, "Roof repair", ["roof", "repair"]),
        sentence("B", 1, "GAF metal roof.", ["gaf", "metal", "roof"],
                 [Mention("brand.gaf", "BRAND", "ruler", 0, 1), Mention("material.metal", "MATERIAL", "ruler", 1, 2)])],
        [heading("B", "Roof repair", ["roof", "repair"]), heading("B", "Metal", ["metal"], 3)])
    c = page("C", [sentence("C", 0, "Roof inspection", ["roof", "inspection"]),
        sentence("C", 1, "Milwaukee roof inspection.", ["milwaukee", "roof", "inspection"],
                 [Mention("gpe.milwaukee", "GPE", "model", 0, 1)])],
        [heading("C", "Roof inspection", ["roof", "inspection"]), heading("C", "Leaks?", ["leak"], 3)])
    return (a, b, c)


def brief():
    return (Check("roof", "term", ("roof",), 200, 400),
            Check("gaf", "entity", ("brand.gaf",)),
            Check("section", "heading", ("roof", "repair"), level=2),
            Check("question", "question", ("how", "be", "a", "roof", "repair")),
            Check("length", "length", low=5, high=5))


def improve_client():
    return page("improve", (sentence("improve", 0, "Roof repair", ["roof", "repair"]),
                sentence("improve", 1, "Roof repair", ["roof", "repair"]),
                sentence("improve", 2, "GAF Timberline shingles.", ["gaf", "timberline", "shingle"],
                         [Mention("brand.gaf", "BRAND", "ruler", 0, 1), Mention("product.timberline", "PRODUCT", "ruler", 1, 2)])),
                (heading("improve", "Roof repair", ["roof", "repair"], 1),
                 heading("improve", "Roof repair", ["roof", "repair"])),
                role="client", url="https://client.example/roof")


def rewrite_client():
    return page("client", [sentence("client", 0, "Roof inspection", ["roof", "inspection"]),
        sentence("client", 1, "GAF roof inspection materials service guide detail useful context projects.",
                 ["gaf", "roof", "inspection", "material", "service", "guide", "detail", "useful", "context", "project"],
                 [Mention("brand.gaf", "BRAND", "ruler", 0, 1)]),
        sentence("client", 2, "In business since 2004.", ["in", "business", "since", "2004"])],
        [heading("client", "Roof inspection", ["roof", "inspection"], 1)],
        role="client", url="https://client.example/roof")


def rewritten_client():
    rows = [sentence("after", 0, "Roof repair", ["roof", "repair"]),
            sentence("after", 1, "Roof repair", ["roof", "repair"]),
            sentence("after", 2, "GAF", ["gaf"], [Mention("brand.gaf", "BRAND", "ruler", 0, 1)]),
            sentence("after", 3, "How is a roof repaired?", ["how", "be", "a", "roof", "repair"]),
            sentence("after", 4, "Roof inspection", ["roof", "inspection"])]
    return page("after", rows, [heading("after", "Roof repair", ["roof", "repair"], 1),
        heading("after", "Roof repair", ["roof", "repair"]),
        heading("after", "How is a roof repaired?", ["how", "be", "a", "roof", "repair"], index=1),
        heading("after", "Roof inspection", ["roof", "inspection"], index=2)], role="client",
        url="https://client.example/roof")


def unknown_profile():
    return {"status": "OK", "label": "UNKNOWN", "refs": (Ref("fixture_gold.v1", "/profiles", "bundle"),)}


def ranked_payload():
    return json.loads((ROOT / "fixtures" / "ranked_keywords_two_preserve.json").read_text())


def lemma_fixture(text):
    # A narrow injected oracle, not a language model substitute.
    return tuple({"roofs": "roof", "repairs": "repair", "repaired": "repair", "is": "be"}.get(w, w)
                 for w in text.casefold().split())


def source_responses(pages):
    """Synthetic source records matching every gold sentence/heading pointer."""
    raw = {}
    def envelope(item):
        return {"status_code": 20000, "cost": 0.00015, "tasks": [{"id": "fixture-only",
                "status_code": 20000, "cost": 0.00015,
                "result": [{"crawl_progress": "finished", "items": [item]}]}]}
    for p in pages:
        sentences = p.sentences or ()
        cp = {"type": "content_parsing", "status_code": 200, "page_content": {
            "main_title": sentences[0].text if sentences else None,
            "header": {"primary_content": [{"text": "Menu Menu"}]},
            "footer": {}, "secondary_topic": [],
            "main_topic": [{"h_title": sentences[0].text if sentences else None,
                "primary_content": [{"text": s.text} for s in sentences[1:]], "secondary_content": []}]}}
        htags = {f"h{i}": [] for i in range(1, 7)}
        for h in p.headings or ():
            htags[f"h{h.level}"].append(h.text)
        meta = {"htags": htags, "content": {"plain_text_word_count": 6 if p.id in "ABC" else None},
                "images_count": {"A": 2, "B": 0, "C": 1}.get(p.id)}
        raw["fixture_cp_"+p.id] = envelope(cp)
        raw["fixture_ip_"+p.id] = envelope({"resource_type": "html", "status_code": 200,
                                         "url": p.url, "meta": meta})
    raw["raw_ranked"] = ranked_payload()
    return raw
