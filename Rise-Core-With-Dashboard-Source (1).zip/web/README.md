# Rise Content — query, URL and content entry

Version 0.3.0. Read `../docs/SETUP.md` for deployment, database SQL and environment variables.

This release includes the React entry screens, local candidate extraction, a Netlify gateway for authenticated live SERP and exact-URL Ranked Keywords lookups, raw response storage, saved lookups and connection diagnostics. Full extraction, briefs and drafts remain unfinished. The example report is separate.

From this directory run `npm ci`, `npm run build`, `npm test`, and `npm run check:render`. The compiled frontend is in `dist/`. Deploy the source with Netlify base directory `web`, build command `npm run build`, publish directory `dist`; the function directory is configured in netlify.toml. Static output alone does not install functions. No new dependency was added for this release.

Validation records are in `validation/`. Mocked tests are not live provider/account validation.
