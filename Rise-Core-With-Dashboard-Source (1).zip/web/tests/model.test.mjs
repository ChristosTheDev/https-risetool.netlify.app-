import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { briefMarkdown, csvCell, filterTerms, formatNumber, formatPercent,
  inspectReference, resolvePointer, scenarioFor, termCsv, valueOf } from '../src/model.mjs';

const report = JSON.parse(readFileSync(new URL('../src/fixture-report.json', import.meta.url), 'utf8'));

test('genuine zero remains zero; missing metrics stay MISSING', () => {
  assert.equal(formatNumber({status:'OK',value:0}), '0');
  assert.equal(formatNumber({status:'MISSING',value:null}), 'MISSING');
  assert.equal(formatNumber(undefined), 'MISSING');
  assert.equal(valueOf({numerator:2,denominator:0}), null);
});

test('filter and size controls select only matching stored rows', () => {
  assert.equal(filterTerms(report).length, 18);
  assert.deepEqual(filterTerms(report, 'ROOF REPAIR').map(row => row.term.join(' ')), ['roof repair']);
  assert.ok(filterTerms(report, '', '3').every(row => row.term.length === 3));
  assert.equal(filterTerms(report, 'not-a-real-term').length, 0);
  assert.equal(filterTerms(report)[0].term.join(' '), 'roof');
});

test('baseline and enriched before/after scores remain distinct', () => {
  const improve = scenarioFor(report, 'improve');
  const rewrite = scenarioFor(report, 'rewrite');
  assert.equal(formatPercent(improve.baseline), '60%');
  assert.equal(formatPercent(rewrite.baseline), '20%');
  assert.equal(formatPercent(rewrite.before.score), '28.6%');
  assert.equal(formatPercent(rewrite.after.score), '85.7%');
  assert.equal(rewrite.before.expected.value, rewrite.after.expected.value);
});

test('inspect controls resolve exact raw text and rank fields', () => {
  const ranking = report.rewrite.preserve.items[0].rankings[0];
  assert.equal(inspectReference(report, ranking.keyword_ref), 'roof inspection');
  assert.equal(inspectReference(report, ranking.rank.input_refs[0]), 17);
  const fact = report.rewrite.sme.slots[0];
  assert.equal(inspectReference(report, fact.source_ref), 'In business since 2004.');
  assert.equal(resolvePointer({}, '/constructor'), undefined);
});

test('exports retain synthetic labels, missing tiers and unverified SME facts', () => {
  const csv = termCsv(report);
  assert.ok(csv.includes('SYNTHETIC FIXTURE'));
  assert.ok(csv.includes('MISSING — insufficient sample'));
  assert.equal(csv.split('\r\n').length, report.terms.rows.length+1);
  assert.equal(csvCell('=FORMULA()'), '"\'=FORMULA()"');
  const brief = briefMarkdown(report);
  const parity = brief.split('## SERP parity')[1].split('## NEEDS SME INPUT')[0];
  assert.ok(!parity.includes('2004'));
  assert.ok(brief.includes('FOUND ON CURRENT PAGE — VERIFY'));
  assert.ok(brief.includes('Gap-priority score: MISSING'));
});
