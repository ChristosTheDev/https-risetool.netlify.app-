import test from 'node:test';
import assert from 'node:assert/strict';
import { candidateQueries, estimatedCost, normalizedInput, parseDiscovery, providerTask, publicUrl } from '../shared/discovery.mjs';
import { api } from '../src/api.mjs';
const input={kind:'ranked',country:'US',language:'en',client_url:'https://example.com/roof/',offset:0};
const scope={location_code:2840};
const wrap=result=>({status_code:20000,cost:0,tasks:[{status_code:20000,result:[result]}]});
const row=(url,volume)=>({keyword_data:{keyword:'roof repair',keyword_info:{search_volume:volume}},ranked_serp_element:{serp_item:{type:'organic',url,rank_group:3,rank_absolute:8}}});
test('content gives deterministic candidate counts, never inferred rankings',()=>{
 const a=candidateQueries('Roof repair. Roof repair. Gutter cleaning.');
 assert.deepEqual(a.rows.map(r=>[r.query,r.occurrences]),[['roof repair',2],['gutter cleaning',1]]);
 assert.equal(a.words,6);assert.ok(a.rows.every(r=>r.position===null&&r.volume===null));
 assert.deepEqual(a,candidateQueries('Roof repair. Roof repair. Gutter cleaning.'));
 assert.throws(()=>candidateQueries('<p>Roof repair</p>'),/visible page text/);
 assert.throws(()=>candidateQueries('roof repair','fr'),/supports English/);
});
test('input enforces scope and URL boundaries before spending',()=>{
 assert.throws(()=>normalizedInput({kind:'serp',query:'roof',country:'US',language:'en'}),/one location/);
 assert.throws(()=>normalizedInput({kind:'serp',query:'site:example.com roof',country:'US',language:'en'}),/operators/);
 assert.throws(()=>publicUrl('https://user:pass@example.com/'),/public/);
 assert.equal(publicUrl('https://example.com/Path?x=1#part'),'https://example.com/Path?x=1');
 assert.throws(()=>normalizedInput({...input,client_url:'http://example.com/roof/'}),/HTTPS/);
 assert.equal(providerTask(input,scope).length,1);
 assert.equal(providerTask(input,scope)[0].limit,100);
 assert.deepEqual(estimatedCost('ranked'),{min:.012,max:.024});
});
test('URL results use organic rank, keep zero volume, exclude other URLs',()=>{
 const result=parseDiscovery(wrap({target:input.client_url,location_code:2840,language_code:'en',total_count:2,items_count:2,items:[row(input.client_url,0),row('https://example.com/other/',99)]}),input,scope,'fixture');
 assert.equal(result.rows[0].position,3);assert.equal(result.rows[0].volume,0);assert.equal(result.rows.length,1);
 assert.equal(result.excluded_rows,1);assert.equal(result.inventory_complete,false);assert.equal(result.actual_cost,0);
 assert.equal(result.rows[0].ref.pointer,'/tasks/0/result/0/items/0');
});
test('empty inventory is different from missing metadata; pages stay partial',()=>{
 const empty={target:input.client_url,location_code:2840,language_code:'en',total_count:0,items_count:0,items:null};
 assert.equal(parseDiscovery(wrap(empty),input,scope,'fixture').inventory_complete,true);
 assert.throws(()=>parseDiscovery(wrap({...empty,total_count:null}),input,scope,'fixture'),/metadata/);
 const partial=parseDiscovery(wrap({...empty,total_count:2,items_count:1,items:[row(input.client_url,null)]}),input,scope,'fixture');
 assert.equal(partial.next_offset,1);assert.equal(partial.inventory_complete,false);assert.equal(partial.rows[0].volume,null);
});
test('SERP deduplicates exact URLs and marks client outside competitors',()=>{
 const q={kind:'serp',query:'roof',client_url:'https://example.com/',language:'en'};
 const result=parseDiscovery(wrap({keyword:'roof',location_code:2840,language_code:'en',items:[{type:'paid',url:'https://ads.example/'},{type:'organic',url:'https://example.com/',rank_group:1},{type:'organic',url:'https://example.com/#same',rank_group:2},{type:'organic',url:'https://competitor.example/',rank_group:3}]}),q,scope,'fixture');
 assert.equal(result.rows.length,2);assert.equal(result.competitor_count,1);assert.equal(result.analyzed_pages,null);
});
test('static HTML fallback never masquerades as successful API configuration',async()=>{
 await assert.rejects(api('config',{fetcher:async()=>new Response('<html/>',{headers:{'content-type':'text/html'}})}),/not deployed/);
});
