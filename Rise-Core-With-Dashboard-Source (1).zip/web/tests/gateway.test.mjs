import test from 'node:test';
import assert from 'node:assert/strict';
import { createHandler, environmentStatus } from '../server/gateway.mjs';
const uid='10000000-0000-4000-8000-000000000001',id='20000000-0000-4000-8000-000000000001';
const env={SUPABASE_URL:'https://fixture.supabase.co',SUPABASE_PUBLISHABLE_KEY:'sb_publishable_fixture',SUPABASE_SECRET_KEY:'sb_secret_fixture',DATAFORSEO_LOGIN:'fixture-login',DATAFORSEO_PASSWORD:'fixture-password'};
const input={kind:'serp',query:'roof repair',country:'US',language:'en',location_code:123,device:'desktop'};
const envelope=result=>({status_code:20000,cost:.002,tasks:[{status_code:20000,result}]});
function mock({failInsert=false,failRaw=false,timeout=false,providerFail=false}={}){
 const runs=new Map(),raws=new Map(),calls=[];
 const fetcher=async(url,options={})=>{
  url=new URL(url);const method=options.method??'GET';calls.push({path:url.pathname,method});
  if(url.pathname==='/auth/v1/user')return Response.json({id:uid,email:'owner@example.com'});
  if(url.pathname.includes('/rest/v1/')){
   assert.equal(options.headers.apikey,'sb_secret_fixture');assert.equal(options.headers.Authorization,undefined);
   const isRaw=url.pathname.endsWith('core_discovery_raw'),map=isRaw?raws:runs;
   const rowId=(url.searchParams.get(isRaw?'run_id':'id')??'').replace('eq.','');
   const owner=url.searchParams.get('owner_id')?.replace('eq.','');
   if(method==='GET')return Response.json(map.has(rowId)&&map.get(rowId).owner_id===owner?[map.get(rowId)]:[]);
   const body=JSON.parse(options.body);
   if(method==='POST'){
    if(failInsert&&!isRaw||failRaw&&isRaw)return Response.json({}, {status:500});
    const key=isRaw?body.run_id:body.id;
    if(map.has(key))return Response.json({}, {status:409});
    map.set(key,body);return Response.json([body],{status:201});
   }
   if(method==='PATCH'){map.set(rowId,{...map.get(rowId),...body});return Response.json([map.get(rowId)]);}
  }
  if(url.pathname.endsWith('/locations/us'))return Response.json(envelope([{location_code:123,country_iso_code:'US',location_name:'Fixture city'}]));
  if(url.pathname.endsWith('/languages'))return Response.json(envelope([{language_code:'en'}]));
  if(url.pathname.endsWith('/user_data'))return Response.json(envelope([{}]));
  if(url.pathname.endsWith('/live/advanced')){
   if(timeout)throw new Error('timeout');
   if(providerFail)return Response.json({status_code:20000,cost:.002,tasks:[{status_code:40501,result:null}]});
   return Response.json(envelope([{keyword:'roof repair',location_code:123,language_code:'en',items:[{type:'organic',url:'https://example.com/',rank_group:1,title:'Roof repair'}]}]));
  }
  throw new Error('Unexpected mocked request '+url.pathname);
 };
 return {handler:createHandler({env,fetcher}),runs,raws,calls};
}
const request=(body={input,request_id:id},token=true)=>new Request('https://fixture.netlify.app/.netlify/functions/gateway?action=lookup',{method:'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:'Bearer fixture-user-token'}:{})},body:JSON.stringify(body)});
test('public status never returns credentials or claims complete readiness',async()=>{
 const h=createHandler({env,fetcher:()=>{throw Error('No network expected');}});
 const r=await h(new Request('https://fixture.netlify.app/?action=config'));const text=await r.text();
 assert.ok(!text.includes('fixture-password'));assert.ok(!text.includes('sb_secret_fixture'));assert.equal(JSON.parse(text).full_analysis_ready,false);
 assert.equal(environmentStatus({}).supabase.status,'MISSING');
 assert.equal(environmentStatus(env).supabase.status,'CONFIGURED');
 assert.deepEqual(environmentStatus(env).supabase.missing,[]);
});
test('Supabase email/password sign-in works without an email allowlist',async()=>{
 const email='writer@example.com';let calls=0;
 const h=createHandler({env,fetcher:async(url,options)=>{
  calls++;assert.equal(url,'https://fixture.supabase.co/auth/v1/token?grant_type=password');
  assert.deepEqual(JSON.parse(options.body),{email,password:'fixture-user-password'});
  return Response.json({access_token:'fixture-session',refresh_token:'private-refresh-token',expires_in:3600,user:{id:uid,email}});
 }});
 const r=await h(new Request('https://fixture.netlify.app/?action=login',{method:'POST',body:JSON.stringify({email:' '+email+' ',password:'fixture-user-password'})}));
 assert.equal(r.status,200);assert.deepEqual(await r.json(),{access_token:'fixture-session',expires_in:3600,email});assert.equal(calls,1);
});
test('a leftover email allowlist variable does not restrict signed-in Supabase users',async()=>{
 const email='writer@example.com';const paths=[];
 const h=createHandler({env:{...env,AGENCY_ALLOWED_EMAILS:'owner@example.com'},fetcher:async url=>{
  url=new URL(url);paths.push(url.pathname);
  if(url.pathname==='/auth/v1/user')return Response.json({id:uid,email});
  assert.equal(url.pathname,'/rest/v1/core_discovery_runs');assert.equal(url.searchParams.get('owner_id'),'eq.'+uid);
  return Response.json([]);
 }});
 const r=await h(new Request('https://fixture.netlify.app/?action=runs',{headers:{Authorization:'Bearer fixture-session'}}));
 assert.equal(r.status,200);assert.deepEqual(await r.json(),{runs:[]});assert.equal(paths.length,2);
});
test('Supabase-rejected credentials and invalid sign-in sessions remain blocked',async()=>{
 for(const outcome of ['credentials','missing-user','missing-token','anonymous']){
  let calls=0;
  const h=createHandler({env,fetcher:async()=>{
   calls++;
   if(outcome==='credentials')return Response.json({error:'invalid_grant'},{status:400});
   return Response.json({access_token:outcome==='missing-token'?null:'fixture-session',user:outcome==='missing-user'?null:{id:uid,email:'writer@example.com',is_anonymous:outcome==='anonymous'}});
  }});
  const r=await h(new Request('https://fixture.netlify.app/?action=login',{method:'POST',body:JSON.stringify({email:'writer@example.com',password:'fixture-password'})}));
  assert.equal(r.status,401,outcome);assert.equal((await r.json()).access_token,undefined);assert.equal(calls,1);
 }
});
test('invalid or anonymous authentication cannot reach saved data or paid endpoints',async()=>{
 for(const outcome of ['expired','invalid-user','anonymous']){
  let calls=0;
  const h=createHandler({env,fetcher:async url=>{
   calls++;assert.equal(new URL(url).pathname,'/auth/v1/user');
   if(outcome==='expired')return Response.json({error:'expired'},{status:401});
   return Response.json({id:outcome==='invalid-user'?'invalid':uid,email:'writer@example.com',is_anonymous:outcome==='anonymous'});
  }});
  assert.equal((await h(request())).status,401,outcome);assert.equal(calls,1);
 }
});
test('unsigned requests cannot make provider or database calls',async()=>{
 const m=mock();assert.equal((await m.handler(request(undefined,false))).status,401);assert.equal(m.calls.length,0);
});
test('connection verification checks discovery tables without paid requests',async()=>{
 const m=mock();const response=await m.handler(new Request('https://fixture.netlify.app/?action=verify',{method:'POST',headers:{Authorization:'Bearer fixture','Content-Type':'application/json'},body:'{}'}));
 const status=await response.json();assert.equal(status.discovery_ready,true);assert.equal(status.full_analysis_ready,false);
 assert.ok(m.calls.some(c=>c.path.endsWith('core_discovery_raw')));assert.equal(m.calls.filter(c=>c.path.endsWith('/live/advanced')).length,0);
});
test('raw storage precedes result; repeated ID reuses saved result without spending',async()=>{
 const m=mock();const first=await (await m.handler(request())).json();assert.equal(first.run.state,'complete');assert.equal(first.run.actual_cost,.002);
 assert.equal(first.run.catalogue_json,undefined);assert.ok(m.raws.has(id));
 assert.equal(Buffer.from(m.raws.get(id).body_base64,'base64').toString(),JSON.stringify(m.raws.get(id).parsed_json));
 const second=await (await m.handler(request())).json();assert.equal(second.reused,true);
 assert.equal(m.calls.filter(c=>c.path.endsWith('/live/advanced')).length,1);
 const rawIndex=m.calls.findIndex(c=>c.path.endsWith('core_discovery_raw')&&c.method==='POST');
 const resultIndex=m.calls.findIndex(c=>c.path.endsWith('core_discovery_runs')&&c.method==='PATCH');assert.ok(rawIndex<resultIndex);
});
test('failed initial storage prevents spending',async()=>{
 const m=mock({failInsert:true});assert.equal((await m.handler(request())).status,503);assert.equal(m.calls.filter(c=>c.path.endsWith('/live/advanced')).length,0);
});
test('provider timeout stays unknown without an automatic retry',async()=>{
 const m=mock({timeout:true});assert.equal((await m.handler(request())).status,502);assert.equal(m.runs.get(id).state,'unknown_outcome');assert.equal(m.raws.size,0);assert.equal(m.runs.get(id).actual_cost,undefined);
 assert.equal((await (await m.handler(request())).json()).reused,true);assert.equal(m.calls.filter(c=>c.path.endsWith('/live/advanced')).length,1);
});
test('provider task failure is stored; raw save failure cannot return success',async()=>{
 const bad=mock({providerFail:true});const r=await(await bad.handler(request())).json();assert.equal(r.run.state,'failed');assert.equal(r.run.actual_cost,.002);assert.ok(bad.raws.has(id));
 const unsaved=mock({failRaw:true});assert.equal((await unsaved.handler(request())).status,503);assert.equal(unsaved.runs.get(id).state,'started');
});
test('raw response reads remain owner-bound and ID conflicts reject changed input',async()=>{
 const m=mock();await m.handler(request());const response=await m.handler(request({request_id:id,input:{...input,query:'different'}}));assert.equal(response.status,409);
 const other='30000000-0000-4000-8000-000000000001';m.raws.set(other,{run_id:other,owner_id:other,parsed_json:{private:true}});
 const denied=await m.handler(new Request('https://fixture.netlify.app/?action=raw&id='+other,{headers:{Authorization:'Bearer fixture'}}));assert.equal(denied.status,404);
});
