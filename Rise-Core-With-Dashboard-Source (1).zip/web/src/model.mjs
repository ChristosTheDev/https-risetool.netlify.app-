export function valueOf(measurement) {
  if (measurement == null || measurement?.status === 'MISSING') return null;
  const value = measurement?.status === 'OK' ? measurement.value : measurement;
  if (value && typeof value === 'object' && 'numerator' in value && 'denominator' in value) {
    if (!Number.isFinite(value.numerator) || !Number.isFinite(value.denominator) || value.denominator === 0) return null;
    return value.numerator / value.denominator;
  }
  return value;
}

export function formatNumber(measurement, digits = 2) {
  const value = valueOf(measurement);
  if (typeof value !== 'number' || !Number.isFinite(value)) return 'MISSING';
  return value.toLocaleString('en-US', { maximumFractionDigits: digits });
}

export function formatPercent(measurement) {
  return valueOf(measurement) == null ? 'MISSING' : `${formatNumber(measurement, 1)}%`;
}

export function filterTerms(report, search = '', size = 'all', sort = 'pages') {
  const query = search.trim().toLocaleLowerCase('en-US');
  return report.terms.rows.filter(row => row.term.join(' ').includes(query) &&
    (size === 'all' || row.term.length === Number(size))).toSorted((a, b) => {
      const lexical = a.term.join(' ').localeCompare(b.term.join(' '), 'en');
      if (sort === 'alphabetical') return lexical;
      const left = valueOf(sort === 'tfidf' ? a.mean_tfidf : a.df);
      const right = valueOf(sort === 'tfidf' ? b.mean_tfidf : b.df);
      if (left == null && right != null) return 1;
      if (left != null && right == null) return -1;
      return (right ?? 0) - (left ?? 0) || lexical;
    });
}

export function scenarioFor(report, id) {
  if (id === 'rewrite') return {
    decision: report.rewrite.decision,
    baseline: report.rewrite.decision.rules.find(rule => rule.rule === 'LOW_COVERAGE').measurements.value.coverage,
    before: report.rewrite.before_coverage,
    after: report.rewrite.after_coverage,
    client: report.gold_pages.find(page => page.id === 'client'),
  };
  return { decision: report.improve.decision, baseline: report.improve.coverage.score,
    before: report.improve.coverage, after: null,
    client: report.gold_pages.find(page => page.id === 'improve') };
}

export function resolvePointer(value, pointer) {
  if (!pointer) return value;
  if (!pointer.startsWith('/')) return undefined;
  for (const encoded of pointer.slice(1).split('/')) {
    const key = encoded.replaceAll('~1', '/').replaceAll('~0', '~');
    if (value == null || typeof value !== 'object' || !Object.hasOwn(value, key)) return undefined;
    value = value[key];
  }
  return value;
}

export function inspectReference(report, ref) {
  if (ref.kind === 'raw') return resolvePointer(report.source_records[ref.id], ref.pointer);
  if (ref.id === 'fixture_gold.v1') {
    return resolvePointer(Object.fromEntries(report.gold_pages.map(page => [page.id, page])), ref.pointer);
  }
  if (ref.id === 'brief') return resolvePointer({ checks: report.rewrite.same_frozen_enriched_brief }, ref.pointer);
  return undefined;
}

export function csvCell(value) {
  let text = value == null ? 'MISSING' : String(value);
  if (/^[\s]*[=+@-]/u.test(text)) text = `'${text}`;
  return `"${text.replaceAll('"', '""')}"`;
}

export function termCsv(report, rows = report.terms.rows) {
  const records = [['Data source', 'Term', 'Document frequency', 'Analyzed pages', 'Minimum TF per 1000', 'Maximum TF per 1000', 'Mean normalized TF-IDF', 'Tier']];
  for (const row of rows) records.push(['SYNTHETIC FIXTURE', row.term.join(' '), formatNumber(row.df),
    formatNumber(report.terms.sample), formatNumber(valueOf(row.range)?.[0]),
    formatNumber(valueOf(row.range)?.[1]), formatNumber(row.mean_tfidf, 6), row.tier ?? 'MISSING — insufficient sample']);
  return records.map(row => row.map(csvCell).join(',')).join('\r\n');
}

export function briefMarkdown(report) {
  const checks = report.rewrite.same_frozen_enriched_brief;
  const rate = checks.find(check => check.id === 'roof');
  const length = checks.find(check => check.id === 'length');
  const facts = report.rewrite.sme.slots;
  return ['# Roof repair — demonstration brief', '',
    'SYNTHETIC FIXTURE. This intentionally short brief is a test case, not a researched client recommendation.', '',
    `Analyzed competitors: ${formatNumber(report.terms.sample)}. Tiers: MISSING (insufficient sample).`,
    `Fixture clean-body length: ${formatNumber(length.low)}–${formatNumber(length.high)} words.`,
    `Observed roof term rate: ${formatNumber(rate.low)}–${formatNumber(rate.high)} per 1,000 words.`, '',
    '## SERP parity', '', 'H1: Roof repair', 'H2: Roof repair', 'H2: How is a roof repaired?', 'Entity: GAF', '',
    '## Preserve items — reported country-level organic rankings', '',
    ...report.rewrite.preserve.items.map(item => `- ${item.keyword} — organic position ${formatNumber(item.rankings[0].rank)}. Source: ${item.rankings[0].keyword_ref.id}${item.rankings[0].keyword_ref.pointer}`), '',
    '## NEEDS SME INPUT', '', ...facts.map(fact => `FOUND ON CURRENT PAGE — VERIFY: “${fact.excerpt}”\n${fact.prompt}\nSource: ${fact.source_ref.id}${fact.source_ref.pointer}`), '',
    'Schema benchmarks: MISSING.', 'Unanswered-question labels: MISSING.', 'Gap-priority score: MISSING.', '',
    'Coverage is a mechanical brief check and does not predict rankings.', ''].join('\n');
}

export function downloadText(name, text, type = 'text/plain;charset=utf-8') {
  const href = URL.createObjectURL(new Blob([text], { type }));
  const link = document.createElement('a');
  link.href = href;
  link.download = name;
  document.body.append(link);
  link.click();
  link.remove();
  setTimeout(() => URL.revokeObjectURL(href), 1000);
}
