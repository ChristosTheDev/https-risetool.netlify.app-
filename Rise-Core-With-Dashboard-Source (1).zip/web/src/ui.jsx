import React from 'react';
export function Icon({ name = 'arrow', size = 20 }) {
  const icons = {
    search: <><circle cx="10.5" cy="10.5" r="6.5" /><path d="m16 16 5 5" /></>,
    link: <><path d="m8 10-2 2a4 4 0 0 0 6 6l2-2M16 14l2-2a4 4 0 0 0-6-6l-2 2M9 15l6-6" /></>,
    content: <><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9zM14 3v6h6M8 13h8M8 17h6" /></>,
    history: <><path d="M3 11a9 9 0 1 1 2 7M3 4v7h7M12 7v6l4 2" /></>,
    setup: <><path d="M4 7h16M4 17h16" /><circle cx="9" cy="7" r="3" fill="currentColor" /><circle cx="15" cy="17" r="3" fill="currentColor" /></>,
    arrow: <path d="M5 12h14m-5-5 5 5-5 5" />,
    download: <><path d="M12 3v12m-5-5 5 5 5-5M4 16v4h16v-4" /></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.65" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{icons[name] ?? icons.arrow}</svg>;
}
export function Button({ children, icon, primary = false, ...props }) { return <button className={`button button-${primary ? 'primary' : 'secondary'}`} {...props}>{icon && <Icon name={icon} size={17} />}{children}</button>; }
export function Tag({ children, status }) { return <span className={`badge badge-${['VERIFIED','complete'].includes(status) ? 'green' : ['FAILED','failed'].includes(status) ? 'coral' : ['REACHABLE','CONFIGURED'].includes(status) ? 'blue' : 'neutral'}`}>{children ?? status}</span>; }
export function Notice({ children, error = false }) { return <div role={error ? 'alert' : 'status'} className={`notice notice-${error ? 'amber' : 'blue'}`}><p>{children}</p></div>; }
export function Field({ label, hint, children }) { return <label className="form-field"><span>{label}</span>{children}{hint && <small>{hint}</small>}</label>; }
