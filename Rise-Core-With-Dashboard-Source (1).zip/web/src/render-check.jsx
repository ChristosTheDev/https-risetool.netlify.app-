import React from 'react';
import { renderToStaticMarkup } from 'react-dom/server';
import App from './App.jsx';
import NewAnalysis from './NewAnalysis.jsx';
import FixtureReport from './FixtureReport.jsx';
export function renderView(view) {
 if(['query','url','content'].includes(view))return renderToStaticMarkup(<NewAnalysis initialMode={view}/>);
 if(view==='example')return renderToStaticMarkup(<FixtureReport/>);
 return renderToStaticMarkup(<App initialView={view}/>);
}
