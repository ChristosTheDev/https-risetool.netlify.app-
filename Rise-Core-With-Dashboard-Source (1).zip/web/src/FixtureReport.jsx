import React, { useEffect, useRef, useState } from 'react';
import report from './fixture-report.json';
import { briefMarkdown, downloadText, filterTerms, formatNumber, formatPercent,
  inspectReference, scenarioFor, termCsv, valueOf } from './model.mjs';

const VIEWS = [
  { id: 'terms', label: 'Term analysis', icon: 'table' },
  { id: 'brief', label: 'Content brief', icon: 'file' },
  { id: 'comparison', label: 'Page comparison', icon: 'compare' },
  { id: 'sources', label: 'Source evidence', icon: 'code' },
];
const CHECK_LABELS = { roof: 'Roof term range', gaf: 'GAF entity', section: 'Roof repair section',
  question: 'Question heading', length: 'Clean-body length' };
const RULE_LABELS = { LOW_COVERAGE: 'Brief coverage', PAGE_TYPE_MISMATCH: 'Page type mismatch',
  NEAR_DUPLICATE: 'Similar client pages', SHORT_AND_LOW_COVERAGE: 'Length and coverage' };

function Icon({ name, size = 20 }) {
  const paths = {
    table: <><rect x="3" y="4" width="18" height="16" rx="2" /><path d="M3 9h18M9 9v11M15 9v11" /></>,
    file: <><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9zM14 3v6h6M8 13h8M8 17h6" /></>,
    compare: <><rect x="3" y="4" width="7" height="16" rx="1.5" /><rect x="14" y="4" width="7" height="16" rx="1.5" /><path d="M6 8h1M6 12h1M17 8h1M17 12h1M17 16h1" /></>,
    code: <><path d="m8 7-5 5 5 5M16 7l5 5-5 5M14 4l-4 16" /></>,
    search: <><circle cx="10.5" cy="10.5" r="6.5" /><path d="m16 16 5 5" /></>,
    download: <><path d="M12 3v12m-5-5 5 5 5-5M4 16v4h16v-4" /></>,
    arrow: <path d="M5 12h14m-5-5 5 5-5 5" />,
    close: <path d="m6 6 12 12M6 18 18 6" />,
    connection: <><path d="m8 10-2 2a4 4 0 0 0 6 6l2-2M16 14l2-2a4 4 0 0 0-6-6l-2 2M9 15l6-6" /></>,
    check: <path d="m5 12 4 4L19 6" />,
    info: <><circle cx="12" cy="12" r="9" /><path d="M12 11v6M12 7v.5" /></>,
  };
  return <svg width={size} height={size} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.65" strokeLinecap="round" strokeLinejoin="round" aria-hidden="true">{paths[name] ?? paths.file}</svg>;
}

function Badge({ children, tone = 'neutral' }) { return <span className={`badge badge-${tone}`}>{children}</span>; }
function Missing({ reason }) { return <span className="missing" title={reason}>MISSING</span>; }
function Button({ children, icon, variant = 'secondary', className = '', ...props }) {
  return <button className={`button button-${variant} ${className}`} {...props}>{icon && <Icon name={icon} size={17} />}{children}</button>;
}
function Metric({ label, value, detail, badge }) {
  return <article className="metric"><div className="metric-label">{label}</div><div className="metric-number">{value}{badge}</div><p>{detail}</p></article>;
}
function ViewHeader({ eyebrow, title, children }) {
  return <div className="view-header"><div><p className="eyebrow">{eyebrow}</p><h2>{title}</h2></div>{children}</div>;
}

function EvidenceDialog({ entry, onClose }) {
  const dialog = useRef(null);
  useEffect(() => { if (entry && dialog.current && !dialog.current.open) dialog.current.showModal(); }, [entry]);
  if (!entry) return null;
  const refs = entry.value?.input_refs ?? entry.refs ?? [];
  return <dialog ref={dialog} className="evidence-dialog" onClose={onClose} onClick={event => { if (event.target === dialog.current) dialog.current.close(); }}>
    <header><div><p className="eyebrow">Stored evidence</p><h2>{entry.title}</h2></div><button className="icon-button" onClick={() => dialog.current.close()} aria-label="Close evidence"><Icon name="close" /></button></header>
    <div className="dialog-body">
      <div className="notice notice-blue"><Icon name="info" /><p>This report uses synthetic source records. Values below are copied or calculated from that fixture.</p></div>
      <pre>{JSON.stringify(entry.value, null, 2)}</pre>
      {refs.length > 0 && <><h3>Source fields</h3><div className="reference-list">{refs.map((ref, i) => {
        const resolved = inspectReference(report, ref);
        return <details key={`${ref.id}-${ref.pointer}-${i}`}><summary><Badge>{ref.kind}</Badge><span>{ref.id}<code>{ref.pointer || '/'}</code></span></summary>
          {resolved === undefined ? <p className="reference-note">This configuration/artifact reference is preserved in the source package.</p> : <pre>{JSON.stringify(resolved, null, 2)}</pre>}
        </details>;
      })}</div></>}
    </div>
  </dialog>;
}

function TermAnalysis({ inspect }) {
  const [search, setSearch] = useState('');
  const [size, setSize] = useState('all');
  const [sort, setSort] = useState('pages');
  const rows = filterTerms(report, search, size, sort);
  const sample = formatNumber(report.terms.sample);
  const population = report.terms.sample.population;
  return <>
    <ViewHeader eyebrow="Competitor coverage" title="Find the terms behind the pages">
      <Button icon="download" onClick={() => downloadText('rise-fixture-terms.csv', termCsv(report, rows), 'text/csv;charset=utf-8')}>Export CSV</Button>
    </ViewHeader>
    <div className="notice notice-amber"><Icon name="info" /><p><strong>Small sample: document frequency only.</strong> Tier labels require at least five successful pages. This fixture has {sample}; no terms are labeled Required or Recommended.</p></div>
    <section className="panel table-panel">
      <div className="table-toolbar"><label className="search-box"><Icon name="search" size={18} /><span className="sr-only">Filter terms</span><input value={search} onChange={event => setSearch(event.target.value)} placeholder="Filter terms…" type="search" /></label>
        <div className="filters"><label><span className="sr-only">Term size</span><select value={size} onChange={event => setSize(event.target.value)}><option value="all">All term sizes</option><option value="1">Single words</option><option value="2">Two-word phrases</option><option value="3">Three-word phrases</option></select></label>
          <label><span className="sr-only">Sort terms</span><select value={sort} onChange={event => setSort(event.target.value)}><option value="pages">Most pages first</option><option value="tfidf">Highest TF-IDF first</option><option value="alphabetical">Alphabetical</option></select></label></div>
      </div>
      <div className="table-scroll" role="region" aria-label="Term measurements" tabIndex="0"><table>
        <thead><tr><th>Term</th><th>Pages</th><th>TF / 1,000 words</th><th>Mean TF-IDF</th><th>Evidence</th></tr></thead>
        <tbody>{rows.map(row => <tr key={row.term.join(' ')}><td><span className="term-text">{row.term.join(' ')}</span><span className="term-size">{row.term.length === 1 ? 'Word' : `${row.term.length}-word phrase`}</span></td>
          <td><div className="frequency-cell"><span>{formatNumber(row.df)} <span className="muted">/ {sample}</span></span><div className="page-marks" aria-label={`Present on pages ${population.filter(id => valueOf(row.counts)[id] > 0).join(', ')}`}>{population.map(id => <span key={id} className={valueOf(row.counts)[id] > 0 ? 'present' : ''} title={`Page ${id}: ${valueOf(row.counts)[id]} occurrences`}>{id}</span>)}</div></div></td>
          <td className="numeric">{formatNumber(valueOf(row.range)?.[0])}<span className="range-dash">–</span>{formatNumber(valueOf(row.range)?.[1])}</td>
          <td className="numeric">{formatNumber(row.mean_tfidf, 3)}</td>
          <td><button className="evidence-link" onClick={() => inspect({ title: row.term.join(' '), value: row.df })}>Inspect <Icon name="arrow" size={15} /></button></td></tr>)}</tbody>
      </table>{rows.length === 0 && <div className="empty"><Icon name="search" size={28} /><h3>No matching terms</h3><p>Try another phrase or clear the filters.</p><Button onClick={() => { setSearch(''); setSize('all'); }}>Clear filters</Button></div>}</div>
      <footer className="table-footer"><span>{rows.length} of {report.terms.rows.length} terms</span><span>Client pages excluded · observed ranges include zeroes</span></footer>
    </section>
    <p className="method-note">TF-IDF describes this sample’s vocabulary. The measurements do not establish an ideal keyword density or predict rankings.</p>
  </>;
}

function Brief({ inspect }) {
  const checks = report.rewrite.same_frozen_enriched_brief;
  const length = checks.find(check => check.id === 'length');
  const rate = checks.find(check => check.id === 'roof');
  return <>
    <ViewHeader eyebrow="Saved fixture brief" title="A brief with traceable requirements"><Button icon="download" onClick={() => downloadText('rise-fixture-brief.md', briefMarkdown(report), 'text/markdown;charset=utf-8')}>Export brief</Button></ViewHeader>
    <div className="notice notice-blue"><Icon name="info" /><p><strong>Demonstration brief.</strong> The deliberately short content and length target belong to a hand-checkable test fixture.</p></div>
    <div className="brief-layout"><section className="panel brief-outline"><div className="panel-heading"><h3>Page outline</h3><Badge tone="blue">SERP parity</Badge></div>
      <div className="outline-line"><span className="level">H1</span><strong>Roof repair</strong></div>
      <div className="outline-line"><span className="level">H2</span><strong>Roof repair</strong></div>
      <div className="outline-line"><span className="level">H2</span><strong>How is a roof repaired?</strong></div>
      <div className="outline-line"><span className="level">H2</span><strong>Roof inspection</strong><Badge>Preserve</Badge></div>
      <div className="brief-divider" /><h3>Preserve existing keywords</h3><p className="muted">Reported organic positions for the exact client URL. The keyword metrics have country scope.</p>
      {report.rewrite.preserve.items.map(item => <button className="preserve-row" key={item.keyword} onClick={() => inspect({ title: item.keyword, value: item.rankings[0].rank })}><span>{item.keyword}</span><span>Position <strong>{formatNumber(item.rankings[0].rank)}</strong></span><Icon name="arrow" size={17} /></button>)}
      <div className="brief-divider" /><div className="panel-heading"><h3>Client evidence</h3><Badge tone="amber">NEEDS SME INPUT</Badge></div>
      {report.rewrite.sme.slots.map(slot => <div className="sme-slot" key={slot.id}><p className="slot-label">{slot.status}</p><blockquote>“{slot.excerpt}”</blockquote><p>{slot.prompt}</p><button className="evidence-link" onClick={() => inspect({ title: 'Unverified current-page excerpt', value: slot, refs: [slot.source_ref] })}>View source <Icon name="arrow" size={15} /></button></div>)}
    </section><aside className="brief-aside"><section className="panel requirements"><h3>Fixture requirements</h3>
      <dl><div><dt>Clean-body target</dt><dd>{formatNumber(length.low)}–{formatNumber(length.high)} words</dd></div><div><dt>Roof term / 1,000</dt><dd>{formatNumber(rate.low)}–{formatNumber(rate.high)}</dd></div><div><dt>Entity</dt><dd>GAF</dd></div><div><dt>Schema benchmark</dt><dd><Missing /></dd></div><div><dt>Unanswered labels</dt><dd><Missing /></dd></div><div><dt>Gap priority</dt><dd><Missing /></dd></div></dl>
    </section><div className="plain-note"><Icon name="info" /><p>Current-page claims stay in SME slots until verified. They are excluded from the parity draft.</p></div></aside></div>
  </>;
}

function CoverageCard({ label, coverage, inspect }) {
  const score = valueOf(coverage?.score);
  return <article className="panel coverage-card"><div className="metric-label">{label}</div><button onClick={() => inspect({ title: label, value: coverage.score })} className="coverage-number">{formatPercent(coverage.score)}</button>
    {score != null && <div className="coverage-track" aria-hidden="true"><span style={{ width: `${score}%` }} /></div>}
    <p>{coverage.checks.filter(check => check.status === 'PASS').length} passed · {formatNumber(coverage.expected)} checks in the same brief</p>
  </article>;
}

function PageComparison({ scenario, inspect, changeScenario }) {
  const data = scenarioFor(report, scenario);
  const rewrite = scenario === 'rewrite';
  const afterPage = report.gold_pages.find(page => page.id === 'after');
  const checks = data.before.checks;
  const getLabel = id => CHECK_LABELS[id] ?? `Preserve: ${report.rewrite.preserve.items.find(item => item.check.id === id)?.keyword ?? id}`;
  return <>
    <ViewHeader eyebrow="Current page and proposed changes" title="See what drives the page mode"><label className="select-labeled"><span>Fixture case</span><select value={scenario} onChange={event => changeScenario(event.target.value)}><option value="improve">IMPROVE example</option><option value="rewrite">REWRITE example</option></select></label></ViewHeader>
    <section className="panel decision-strip"><Badge tone={rewrite ? 'coral' : 'green'}>{data.decision.detected}</Badge><div><h3>{rewrite ? 'Coverage triggers a rewrite' : 'Improve the existing page'}</h3><p>{rewrite ? `${formatPercent(data.baseline)} baseline coverage falls below the configured rewrite cutoff. The comparison below adds both preserve keywords to the brief.` : 'The fixture does not trigger a rewrite rule. Its missing question heading and length check remain visible.'}</p></div><button className="evidence-link" onClick={() => inspect({ title: 'Page-mode decision', value: data.decision })}>Rules <Icon name="arrow" size={16} /></button></section>
    <div className={`coverage-grid ${rewrite ? '' : 'single'}`}><CoverageCard label={rewrite ? 'Before · enriched brief' : 'Current brief coverage'} coverage={data.before} inspect={inspect} />
      {rewrite ? <CoverageCard label="After · same enriched brief" coverage={data.after} inspect={inspect} /> : <div className="improve-note"><h3>Edits are still unscored</h3><p>The missing question-gap priority policy is marked MISSING. No priority order is invented.</p><Button onClick={() => changeScenario('rewrite')}>View rewrite fixture <Icon name="arrow" size={17} /></Button></div>}</div>
    <section className="panel"><div className="panel-heading"><h3>Coverage checks</h3><span className="muted">Mechanical brief coverage</span></div><div className="check-list">{checks.map(check => <div className="check-row" key={check.id}><span>{getLabel(check.id)}</span><Badge tone={check.status === 'PASS' ? 'green' : check.status === 'FAIL' ? 'coral' : 'neutral'}>{check.status}</Badge>{rewrite && <><Icon name="arrow" size={15} /><Badge tone={data.after.checks.find(item => item.id === check.id)?.status === 'PASS' ? 'green' : 'coral'}>{data.after.checks.find(item => item.id === check.id)?.status ?? 'MISSING'}</Badge></>}</div>)}</div></section>
    <div className="page-text-grid"><section className="panel source-copy"><div className="panel-heading"><h3>Current page</h3><Badge>Fixture</Badge></div><p className="url-label">{data.client.url}</p><p className="small-note">Current-page claims are unverified.</p>{data.client.sentences.map((s, i) => <p key={i}>{s.text}</p>)}</section>
      {rewrite && <section className="panel source-copy"><div className="panel-heading"><h3>Proposed parity text</h3><Badge tone="blue">SERP parity</Badge></div><p className="url-label">{afterPage.url}</p>{afterPage.sentences.map((s, i) => <p key={i}>{s.text}</p>)}<div className="inline-note">The length check still fails. The year statement stays in an SME slot.</div></section>}</div>
    <div className="rule-summary">{data.decision.rules.map(rule => <button key={rule.rule} onClick={() => inspect({ title: RULE_LABELS[rule.rule], value: rule })}><span>{RULE_LABELS[rule.rule]}</span><Badge tone={rule.state === 'TRIGGERED' ? 'coral' : 'neutral'}>{rule.state.replaceAll('_', ' ')}</Badge></button>)}</div>
  </>;
}

function Sources() {
  const ids = Object.keys(report.source_records).sort();
  const [selected, setSelected] = useState('fixture_cp_A');
  return <>
    <ViewHeader eyebrow="Inspectable source records" title="Follow each number to its source"><Button icon="download" onClick={() => downloadText('rise-synthetic-fixture-report.json', JSON.stringify(report, null, 2), 'application/json')}>Download report</Button></ViewHeader>
    <div className="notice notice-blue"><Icon name="info" /><p><strong>Synthetic responses, real field names.</strong> These records test the analysis contracts. They are not live Google results or client data.</p></div>
    <section className="panel source-browser"><div className="source-picker"><label htmlFor="source-record">Source record</label><select id="source-record" value={selected} onChange={event => setSelected(event.target.value)}>{ids.map(id => <option key={id}>{id}</option>)}</select><span className="muted">Original fixture JSON</span></div><pre className="source-json">{JSON.stringify(report.source_records[selected], null, 2)}</pre></section>
    <div className="provenance-grid">{[['RAW', 'A field copied from a stored response.'], ['DERIVED', 'A measurement calculated in code.'], ['CONFIG', 'A versioned setting or test input.'], ['DOCUMENTATION', 'A value sourced from published documentation.']].map(([name, description]) => <div key={name}><Badge>{name}</Badge><p>{description}</p></div>)}</div>
  </>;
}

export default function FixtureReport() {
  const [view, setView] = useState('terms');
  const [scenario, setScenario] = useState('improve');
  const [evidence, setEvidence] = useState(null);
  return <>
    <div className="notice notice-amber"><p><strong>SAMPLE REPORT.</strong> Synthetic roofing fixture, separate from your query or client input.</p></div>
    <nav className="example-tabs" aria-label="Sample report views">{VIEWS.map(item => <Button key={item.id} variant={view === item.id ? 'primary' : 'secondary'} onClick={() => setView(item.id)}>{item.label}</Button>)}</nav>
    {view === 'terms' && <TermAnalysis inspect={setEvidence} />}
    {view === 'brief' && <Brief inspect={setEvidence} />}
    {view === 'comparison' && <PageComparison scenario={scenario} inspect={setEvidence} changeScenario={setScenario} />}
    {view === 'sources' && <Sources />}
    <EvidenceDialog entry={evidence} onClose={() => setEvidence(null)} />
  </>;
}
