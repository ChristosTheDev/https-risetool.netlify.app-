export async function api(action, { token, body, params = {}, fetcher = fetch } = {}) {
  const response = await fetcher(`/.netlify/functions/gateway?${new URLSearchParams({ action, ...params })}`, {
    method: body === undefined ? 'GET' : 'POST',
    headers: { ...(body === undefined ? {} : { 'Content-Type': 'application/json' }), ...(token ? { Authorization: `Bearer ${token}` } : {}) },
    ...(body === undefined ? {} : { body: JSON.stringify(body) }),
  });
  if (!response.headers.get('content-type')?.includes('application/json')) throw new Error('Server function is not deployed. Uploading the static website does not install it. Open Connections for the source deployment steps.');
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || 'Request failed. Check Connections.');
  return data;
}
