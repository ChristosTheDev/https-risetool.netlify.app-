import React from 'react';
import { createRoot } from 'react-dom/client';
import App from './App.jsx';
import './generated.css';

class ErrorBoundary extends React.Component {
  state = { error: null };
  static getDerivedStateFromError(error) { return { error }; }
  render() {
    if (this.state.error) return <main className="load-error"><h1>The report could not open</h1><p>Reload this page. If the problem continues, upload the complete dashboard build again, including its assets folder.</p><button onClick={() => location.reload()}>Reload dashboard</button></main>;
    return this.props.children;
  }
}

createRoot(document.getElementById('root')).render(<ErrorBoundary><App /></ErrorBoundary>);
