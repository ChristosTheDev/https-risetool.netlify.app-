import React, { lazy, Suspense, useEffect, useState } from 'react';
import { api } from './api.mjs';
import { Button, Icon, Notice, Tag } from './ui.jsx';
import Connections from './Connections.jsx';
import NewAnalysis from './NewAnalysis.jsx';
import LookupResult from './LookupResult.jsx';
import { money } from '../shared/discovery.mjs';
const FixtureReport=lazy(()=>import('./FixtureReport.jsx'));
const NAV=[{id:'new',label:'New analysis',icon:'search'},{id:'runs',label:'Saved lookups',icon:'history'},{id:'setup',label:'Connections',icon:'setup'}];

function SavedLookups({session,openSetup,onOpen}){
  const [runs,setRuns]=useState([]),[error,setError]=useState(''),[busy,setBusy]=useState(false);
  async function refresh(){setBusy(true);setError('');try{setRuns((await api('runs',{token:session?.access_token})).runs);}catch(e){setError(e.message);}finally{setBusy(false);}}
  useEffect(()=>{if(session)refresh();},[session]);
  return <><div className="workspace-heading"><p className="eyebrow">Your agency data</p><h1>Saved lookups</h1><p>Reopen a stored response without paying for another provider request.</p></div>{!session?<Notice>Sign in through Connections to load your saved lookups. <button className="text-link" onClick={openSetup}>Open connections</button></Notice>:<><div className="action-row"><Button onClick={refresh} disabled={busy}>{busy?'Loading…':'Refresh saved lookups'}</Button></div>{error&&<Notice error>{error}</Notice>}<div className="saved-list">{runs.map(run=><button className="panel saved-run" key={run.id} onClick={()=>onOpen(run.id)}><Icon name={run.kind==='serp'?'search':'link'}/><div><strong>{run.input_json.query??run.input_json.client_url}</strong><span>{run.started_at} · {run.input_json.country} · Reported cost {money(run.actual_cost)}</span></div><Tag status={run.state}/><Icon/></button>)}{!busy&&!error&&!runs.length&&<div className="panel empty"><h2>No saved lookups yet</h2><p>Start with a query or page URL.</p></div>}</div></>}</>;
}

export default function App({initialView=null,initialMode='query'}){
  const [view,setView]=useState(initialView??(typeof window!=='undefined'?window.location.hash.slice(1):'new'));
  const [session,setSession]=useState(null),[status,setStatus]=useState(null),[serverError,setServerError]=useState('');
  const [opened,setOpened]=useState(null),[openError,setOpenError]=useState(''),[target,setTarget]=useState(null),[busy,setBusy]=useState(false),[epoch,setEpoch]=useState(0);
  const active=[...NAV.map(item=>item.id),'examples','saved'].includes(view)?view:'new';
  async function refreshStatus(){try{setStatus(await api('config'));setServerError('');}catch(e){setServerError(e.message);setStatus(null);}}
  useEffect(()=>{refreshStatus();const sync=()=>setView(window.location.hash.slice(1)||'new');window.addEventListener('hashchange',sync);return()=>window.removeEventListener('hashchange',sync);},[]);
  const navigate=id=>{window.location.hash=id;setView(id);setOpenError('');};
  async function openRun(id){try{setOpened((await api('run',{token:session?.access_token,params:{id}})).run);navigate('saved');}catch(e){setOpenError(e.message);}}
  async function more(source,offset){if(busy)return;setBusy(true);setOpenError('');try{const result=await api('lookup',{token:session?.access_token,body:{input:{...source,offset},request_id:crypto.randomUUID()}});setOpened(result.run);}catch(e){setOpenError(e.message);}finally{setBusy(false);}}
  return <div className="app-shell"><a href="#main-content" className="skip-link" onClick={e=>{e.preventDefault();document.getElementById('main-content')?.focus();}}>Skip to content</a><aside className="sidebar"><a href="#new" className="brand"><span className="brand-mark">R</span><span>rise<span className="brand-product">CONTENT</span></span></a><p className="workspace-label">Rise Marketing HQ</p><p className="nav-caption">WORKSPACE</p><nav aria-label="Main navigation">{NAV.map(item=><a key={item.id} href={`#${item.id}`} onClick={()=>setView(item.id)} className={`nav-item ${active===item.id?'active':''}`} aria-current={active===item.id?'page':undefined}><Icon name={item.icon}/><span>{item.label}</span></a>)}</nav><div className="sidebar-bottom"><a className={`nav-item ${active==='examples'?'active':''}`} href="#examples"><Icon name="content"/><span>Example report</span></a><div className="workspace-footer"><span className="avatar">RH</span><div><strong>Agency workspace</strong><span>{session?'Signed in':'Not signed in'}</span></div></div></div></aside>
    <div className="main-shell"><header className="topbar"><div className="breadcrumbs">Workspace<span>/</span><strong>{NAV.find(item=>item.id===active)?.label??(active==='examples'?'Example report':'Saved result')}</strong></div><div className="topbar-actions"><span className="session-label">{session?.email??'Agency access'}</span><Button onClick={()=>navigate('setup')}>{session?'Connections':'Sign in / setup'}</Button></div></header><main id="main-content" tabIndex="-1"><div hidden={active!=='new'}><NewAnalysis key={epoch} session={session} status={status} openSetup={()=>navigate('setup')} initialMode={initialMode} target={target}/></div>
      {active==='setup'&&<Connections session={session} setSession={value=>{setSession(value);if(!value){setOpened(null);setTarget(null);setEpoch(n=>n+1);}}} status={status} setStatus={setStatus} serverError={serverError} refreshStatus={refreshStatus}/>}
      {active==='runs'&&<SavedLookups session={session} openSetup={()=>navigate('setup')} onOpen={openRun}/>}
      {active==='saved'&&opened&&<><div className="workspace-heading"><h1>Saved lookup</h1></div><LookupResult key={opened.id} run={opened} token={session?.access_token} chooseQuery={(query,source)=>{setTarget({query,source});navigate('new');}} loadMore={more} busy={busy}/><Button onClick={()=>navigate('new')}>Start a new analysis</Button></>}
      {active==='examples'&&<Suspense fallback={<p>Opening example report…</p>}><FixtureReport/></Suspense>}{openError&&<Notice error>{openError}</Notice>}<footer className="app-footer"><span>Rise Marketing HQ · Content workspace</span><span>Source evidence · Human review · No ranking guarantees</span></footer></main></div></div>;
}
