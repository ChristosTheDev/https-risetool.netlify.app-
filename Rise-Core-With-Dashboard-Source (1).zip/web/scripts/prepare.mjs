import { readFileSync, writeFileSync, mkdirSync, copyFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
const hash = body => createHash('sha256').update(body).digest('hex');
mkdirSync('public/setup', { recursive: true });
copyFileSync('../docs/SETUP.md', 'public/setup/SETUP.md');
copyFileSync('../supabase/002_discovery.sql', 'public/setup/002_discovery.sql');
const kb = ['KB-01_dataforseo_api.md','KB-02_google_ranking_systems.md','KB-03_nlp_methods.md'].map(name => {
  const text = readFileSync(`../kb/${name}`, 'utf8');
  return { name, sha256: hash(text), text };
});
const code = ['server/gateway.mjs','shared/discovery.mjs'].map(path => ({ path, sha256: hash(readFileSync(path)) }));
writeFileSync('server/release.json', JSON.stringify({version:'discovery.v1',kb,code}));
