import { spawnSync } from 'node:child_process';
import { readFileSync, existsSync } from 'node:fs';
import './prepare.mjs';

function run(command, args) {
  const result = spawnSync(command, args, { stdio: 'inherit', shell: false });
  if (result.status !== 0) process.exit(result.status ?? 1);
}
run(process.execPath, ['node_modules/tailwindcss/lib/cli.js', '-i', 'src/styles.css', '-o', 'src/generated.css', '--minify']);
run(process.execPath, ['node_modules/vite/bin/vite.js', 'build']);
const html = readFileSync('dist/index.html', 'utf8');
for (const [, asset] of html.matchAll(/(?:src|href)="(\/[^"#]+)"/g)) {
  if (!existsSync('dist' + asset)) throw new Error(`Built asset missing: ${asset}`);
}
if (!readFileSync('dist/_redirects', 'utf8').includes('/* /index.html 200')) throw new Error('Netlify fallback missing');
console.log('Verified: root index.html, local assets and Netlify fallback.');
