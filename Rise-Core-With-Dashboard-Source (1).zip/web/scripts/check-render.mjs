import { build } from 'vite';
import { readFileSync, writeFileSync } from 'node:fs';
import { pathToFileURL } from 'node:url';
import { resolve } from 'node:path';
import assert from 'node:assert/strict';

await build({ logLevel: 'warn', build: { ssr: 'src/render-check.jsx', outDir: '.qa-render', emptyOutDir: true } });
const { renderView } = await import(pathToFileURL(resolve('.qa-render/render-check.js')).href);
const expected = { query: 'Research one search query', url: 'Which queries does this page rank for?', content: 'Start with the page content', setup: 'Connect your services', runs: 'Saved lookups', example: 'SAMPLE REPORT' };
const checks = [];
for (const [view, heading] of Object.entries(expected)) {
  const html = renderView(view);
  assert.ok(html.includes(heading), `Missing ${view} heading`);
  if(view !== 'example') assert.ok(!html.includes('SAMPLE REPORT'), `Fixture leaked into ${view}`);
  if(view === 'query') assert.ok(html.includes('name=') || html.includes('Target query'));
  assert.ok(!html.includes('[object Object]'), `Invalid rendered metric on ${view}`);
  checks.push({view,status:'PASS'});
}
const index = readFileSync('dist/index.html', 'utf8');
assert.ok(index.includes('/assets/'));
assert.ok(!index.includes('/src/main.jsx'));
writeFileSync('.qa-render/validation.json', JSON.stringify({status:'PASS', checks, method:'React server-render smoke check; no browser automation'}, null, 2));
console.log('All dashboard views render. The upload uses compiled assets, not JSX source.');
