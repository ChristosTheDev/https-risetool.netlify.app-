import { createHandler } from '../../server/gateway.mjs';
export default createHandler();
