import { createHash, randomUUID } from 'node:crypto';
import release from './release.json' with { type: 'json' };
import { DISCOVERY_CONFIG, ENDPOINTS, normalizedInput, providerTask, providerResults, parseDiscovery } from '../shared/discovery.mjs';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[1-8][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
const sha = text => createHash('sha256').update(text).digest('hex');
const publicRun = row => Object.fromEntries(['id','kind','state','input_json','result_json','actual_cost','failure','started_at','finished_at'].map(key => [key,row[key] ?? null]));
const json = (value, status = 200) => Response.json(value, { status, headers: { 'Cache-Control': 'no-store', 'X-Content-Type-Options': 'nosniff' } });
class ApiError extends Error { constructor(message, status = 400) { super(message); this.status = status; } }

export function environmentStatus(env) {
  const groups = {
    supabase: [['SUPABASE_URL'], ['SUPABASE_PUBLISHABLE_KEY', 'SUPABASE_ANON_KEY'], ['SUPABASE_SECRET_KEY', 'SUPABASE_SERVICE_ROLE_KEY']],
    dataforseo: [['DATAFORSEO_LOGIN'], ['DATAFORSEO_PASSWORD']],
    render: [['ANALYSIS_API_URL'], ['ANALYSIS_API_TOKEN']],
    claude: [['ANTHROPIC_API_KEY'], ['TEXT_GENERATOR_MODEL']],
  };
  return Object.fromEntries(Object.entries(groups).map(([name, keys]) => [name, {
    status: keys.every(options => options.some(key => String(env[key] ?? '').trim())) ? 'CONFIGURED' : 'MISSING',
    missing: keys.filter(options => !options.some(key => String(env[key] ?? '').trim())).map(options => options[0]),
    capability: name === 'render' || name === 'claude' ? 'INTEGRATION_PENDING' : 'AVAILABLE_AFTER_VERIFICATION',
  }]));
}

export function createHandler({ env = process.env, fetcher = fetch, now = () => new Date().toISOString(), uuid = randomUUID } = {}) {
  const pub = () => env.SUPABASE_PUBLISHABLE_KEY || env.SUPABASE_ANON_KEY;
  const secret = () => env.SUPABASE_SECRET_KEY || env.SUPABASE_SERVICE_ROLE_KEY;
  const validUser = user => UUID.test(user?.id ?? '') && typeof user?.email === 'string' && Boolean(user.email.trim()) && user.is_anonymous !== true;
  const configured = group => environmentStatus(env)[group].status === 'CONFIGURED';
  const base = () => {
    let url;
    try { url = new URL(env.SUPABASE_URL); } catch { throw new ApiError('Set a valid SUPABASE_URL in Netlify.', 503); }
    if (url.protocol !== 'https:' || url.username || url.password || url.pathname !== '/') throw new ApiError('SUPABASE_URL must be the HTTPS project origin.', 503);
    return url.origin;
  };
  async function call(url, options = {}) {
    return fetcher(url, { ...options, signal: AbortSignal.timeout(20000), redirect: 'error' });
  }
  async function db(path, method = 'GET', body) {
    const key = secret();
    if (!key) throw new ApiError('MISSING: Supabase server key. Open Connections.', 503);
    const headers = { apikey: key, 'Content-Type': 'application/json', Prefer: 'return=representation' };
    if (!key.startsWith('sb_secret_')) headers.Authorization = `Bearer ${key}`;
    const response = await call(`${base()}/rest/v1/${path}`, { method, headers, ...(body === undefined ? {} : { body: JSON.stringify(body) }) });
    if (!response.ok) throw new ApiError(response.status === 409 ? 'Request already exists. Open Saved lookups before running it again.' : 'Supabase storage check failed. Apply the supplied discovery SQL and check the server key.', response.status === 409 ? 409 : 503);
    return response.status === 204 ? null : response.json();
  }
  async function authenticate(request) {
    const authorization = request.headers.get('authorization') ?? '';
    if (!authorization.startsWith('Bearer ') || !pub()) throw new ApiError('Sign in through Connections before using live data.', 401);
    const response = await call(`${base()}/auth/v1/user`, { headers: { apikey: pub(), Authorization: authorization } });
    if (!response.ok) throw new ApiError('Your sign-in expired. Sign in again through Connections.', 401);
    const user = await response.json();
    if (!validUser(user)) throw new ApiError('Sign in with your Supabase email and password through Connections.', 401);
    return user;
  }
  const dfsHeaders = () => ({ Authorization: `Basic ${Buffer.from(`${env.DATAFORSEO_LOGIN}:${env.DATAFORSEO_PASSWORD}`).toString('base64')}`, 'Content-Type': 'application/json' });
  async function catalogue(path) {
    if (!configured('dataforseo')) throw new ApiError('MISSING: DataForSEO API login or password.', 503);
    const response = await call(`https://api.dataforseo.com${path}`, { headers: dfsHeaders() });
    if (!response.ok) throw new ApiError('DataForSEO catalogue request failed. Check API credentials.', 502);
    const raw = await response.json();
    return { path, raw, records: providerResults(raw) };
  }
  async function resolveScope(input) {
    if (input.kind === 'ranked') {
      const cat = await catalogue('/v3/dataforseo_labs/locations_and_languages');
      const country = cat.records.find(row => row.country_iso_code === input.country && row.location_type === 'Country');
      const language = country?.available_languages?.find(row => row.language_code === input.language && row.available_sources?.includes('google'));
      if (!country || !language) throw new ApiError('MISSING: Labs does not list this country/language pair for Google.', 422);
      return { scope: { kind: 'COUNTRY_DATABASE', country: input.country, location_code: country.location_code, location_name: country.location_name, language: input.language, device: null }, catalogues: [cat] };
    }
    const locations = await catalogue(`/v3/serp/google/locations/${input.country.toLowerCase()}`);
    const match = locations.records.find(row => row.country_iso_code === input.country && (input.location_code != null ? row.location_code === input.location_code : row.location_name?.toLowerCase() === input.location_name.toLowerCase()));
    if (!match) throw new ApiError('Location not found in the selected country. Use Find location and choose a supported result.', 422);
    const languages = await catalogue('/v3/serp/google/languages');
    if (!languages.records.some(row => row.language_code === input.language)) throw new ApiError('Language is not listed for Google SERPs.', 422);
    return { scope: { kind: 'LOCAL_OR_COUNTRY_SERP', country: input.country, location_code: match.location_code, location_name: match.location_name, language: input.language, device: input.device }, catalogues: [locations, languages] };
  }
  async function verify(user) {
    const services = environmentStatus(env);
    if (configured('supabase')) {
      try {
        const row = { id: uuid(), owner_id: user.id, checked_at: now() };
        await db('core_connection_checks', 'POST', row);
        const readback = await db(`core_connection_checks?id=eq.${row.id}&owner_id=eq.${user.id}&select=id`);
        if (readback?.[0]?.id !== row.id) throw new Error('Readback failed');
        await db(`core_discovery_runs?owner_id=eq.${user.id}&select=id&limit=1`);
        await db(`core_discovery_raw?owner_id=eq.${user.id}&select=run_id&limit=1`);
        services.supabase = { status: 'VERIFIED', detail: 'Sign-in, database write/read and discovery-table access succeeded.', capability: 'DISCOVERY_STORAGE' };
      } catch (error) { services.supabase = { status: 'FAILED', detail: error.message }; }
    }
    if (configured('dataforseo')) {
      try {
        await catalogue('/v3/appendix/user_data');
        services.dataforseo = { status: 'VERIFIED', detail: 'API credentials accepted by the free account endpoint. Paid query coverage and balance are not verified.' };
      } catch { services.dataforseo = { status: 'FAILED', detail: 'Credential check failed. Use the API-access login and password.' }; }
    }
    if (configured('render')) {
      try {
        const url = new URL(env.ANALYSIS_API_URL);
        if (url.protocol !== 'https:') throw new Error('HTTPS required');
        const response = await call(new URL('/health', url), { headers: { Authorization: `Bearer ${env.ANALYSIS_API_TOKEN}` } });
        const data = await response.json();
        services.render = { status: response.ok && data.status === 'ok' ? 'REACHABLE' : 'FAILED', capability: 'INTEGRATION_PENDING', detail: 'Health reachability only. This release does not dispatch full analysis jobs.' };
      } catch { services.render = { status: 'FAILED', capability: 'INTEGRATION_PENDING', detail: 'Analysis service health endpoint is unavailable or invalid.' }; }
    }
    if (configured('claude')) {
      try {
        const response = await call(`https://api.anthropic.com/v1/models/${encodeURIComponent(env.TEXT_GENERATOR_MODEL)}`, { headers: { 'x-api-key': env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' } });
        const model = await response.json();
        services.claude = { status: response.ok && typeof model.id === 'string' ? 'REACHABLE' : 'FAILED', capability: 'INTEGRATION_PENDING', detail: 'Key/model check only. No text generation was requested; draft writing is not connected.' };
      } catch { services.claude = { status: 'FAILED', capability: 'INTEGRATION_PENDING', detail: 'Claude key/model check failed.' }; }
    }
    return { checked_at: now(), services, discovery_ready: services.supabase.status === 'VERIFIED' && services.dataforseo.status === 'VERIFIED', full_analysis_ready: false };
  }
  async function dispatch(user, source) {
    let input;
    try { input = normalizedInput(source.input); } catch (error) { throw new ApiError(error.message, 422); }
    const id = source.request_id;
    if (!UUID.test(id ?? '')) throw new ApiError('A valid request ID is required.');
    if (!configured('supabase') || !configured('dataforseo')) throw new ApiError('Finish Supabase and DataForSEO setup before running a lookup.', 503);
    const fingerprint = sha(JSON.stringify(input));
    const previous = await db(`core_discovery_runs?id=eq.${id}&owner_id=eq.${user.id}&select=*`);
    if (previous.length) {
      if (previous[0].input_sha256 !== fingerprint) throw new ApiError('Request ID is already associated with different input.', 409);
      return { run: publicRun(previous[0]), reused: true };
    }
    const { scope, catalogues } = await resolveScope(input);
    const request = providerTask(input, scope);
    const record = { id, owner_id: user.id, kind: input.kind, state: 'started', input_json: input,
      input_sha256: fingerprint, endpoint: ENDPOINTS[input.kind], request_json: request,
      scope_json: scope, config_json: { ...DISCOVERY_CONFIG, release },
      catalogue_json: catalogues.map(cat => ({ path: cat.path, raw: cat.raw })), started_at: now() };
    // Insert before spending; a unique request ID prevents concurrent duplicate dispatch.
    await db('core_discovery_runs', 'POST', record);
    let response;
    let bytes;
    try {
      response = await call(`https://api.dataforseo.com${record.endpoint}`, { method: 'POST', headers: dfsHeaders(), body: JSON.stringify(request) });
      bytes = Buffer.from(await response.arrayBuffer());
    } catch {
      await db(`core_discovery_runs?id=eq.${id}&owner_id=eq.${user.id}`, 'PATCH', { state: 'unknown_outcome', finished_at: now(), failure: 'MISSING: no complete response received. Cost is unknown. No automatic retry.' });
      throw new ApiError('Lookup outcome is unknown. Open Saved lookups; do not repeat it automatically.', 502);
    }
    let raw = null;
    try { raw = JSON.parse(bytes.toString('utf8')); } catch { /* Original bytes remain stored. */ }
    const rawRecord = { run_id: id, owner_id: user.id, http_status: response.status, body_base64: bytes.toString('base64'),
      body_sha256: sha(bytes), parsed_json: raw, received_at: now() };
    // The original provider response must be stored successfully before any analysis is returned.
    try { await db('core_discovery_raw', 'POST', rawRecord); }
    catch { throw new ApiError('Provider responded but raw storage failed. Outcome remains started in Saved lookups. Do not rerun automatically.', 503); }
    let result = null;
    let failure = null;
    try {
      if (!response.ok) throw new Error('MISSING: provider HTTP request failed.');
      result = parseDiscovery(raw, input, scope, id);
    } catch (error) { failure = error.message; }
    const actual_cost = typeof raw?.cost === 'number' && Number.isFinite(raw.cost) ? raw.cost : null;
    const updated = await db(`core_discovery_runs?id=eq.${id}&owner_id=eq.${user.id}`, 'PATCH', {
      state: failure ? 'failed' : 'complete', result_json: result, failure, actual_cost, finished_at: now(), cost_pointer: '/cost',
    });
    return { run: publicRun(updated[0]), reused: false };
  }
  return async request => {
    try {
      const url = new URL(request.url);
      const action = url.searchParams.get('action') ?? 'config';
      if (!['GET', 'POST'].includes(request.method)) return json({ error: 'Method not allowed.' }, 405);
      const origin = request.headers.get('origin');
      if (origin && origin !== url.origin) throw new ApiError('Cross-origin requests are not allowed.', 403);
      if (action === 'config' && request.method === 'GET') return json({ version: DISCOVERY_CONFIG.version, services: environmentStatus(env), discovery_ready: false, full_analysis_ready: false });
      let body = {};
      if (request.method === 'POST') {
        const text = await request.text();
        if (text.length > 120000) throw new ApiError('Request is too large.', 413);
        try { body = JSON.parse(text); } catch { throw new ApiError('Invalid JSON request.'); }
      }
      if (action === 'login' && request.method === 'POST') {
        if (!pub()) throw new ApiError('Configure the Supabase project URL and publishable key in Netlify.', 503);
        const email = typeof body.email === 'string' ? body.email.trim() : '';
        if (!email) throw new ApiError('Enter your Supabase user email.');
        if (typeof body.password !== 'string' || !body.password) throw new ApiError('Enter your Supabase user password.');
        const response = await call(`${base()}/auth/v1/token?grant_type=password`, { method: 'POST', headers: { apikey: pub(), 'Content-Type': 'application/json' }, body: JSON.stringify({ email, password: body.password }) });
        if (!response.ok) throw new ApiError('Sign-in failed. Check the email, password and email confirmation in Supabase Authentication.', 401);
        const session = await response.json();
        if (typeof session.access_token !== 'string' || !session.access_token || !validUser(session.user)) throw new ApiError('Sign-in response was invalid.', 401);
        return json({ access_token: session.access_token, expires_in: session.expires_in, email: session.user.email });
      }
      const user = await authenticate(request);
      if (action === 'verify' && request.method === 'POST') return json(await verify(user));
      if (action === 'locations' && request.method === 'GET') {
        const country = url.searchParams.get('country') ?? '';
        const term = (url.searchParams.get('q') ?? '').trim().toLowerCase();
        if (!/^[A-Z]{2}$/.test(country) || term.length < 2) throw new ApiError('Choose a country and type at least two characters.');
        const cat = await catalogue(`/v3/serp/google/locations/${country.toLowerCase()}`);
        return json({ locations: cat.records.filter(row => row.country_iso_code === country && (String(row.location_code) === term || row.location_name?.toLowerCase().includes(term))).slice(0, 20) });
      }
      if (action === 'lookup' && request.method === 'POST') return json(await dispatch(user, body));
      if (action === 'runs' && request.method === 'GET') return json({ runs: await db(`core_discovery_runs?owner_id=eq.${user.id}&select=id,kind,state,input_json,actual_cost,failure,started_at&order=started_at.desc&limit=25`) });
      if (['run', 'raw'].includes(action) && request.method === 'GET') {
        const id = url.searchParams.get('id');
        if (!UUID.test(id ?? '')) throw new ApiError('Invalid saved run ID.');
        const rows = action === 'raw' ? await db(`core_discovery_raw?run_id=eq.${id}&owner_id=eq.${user.id}&select=*`) : await db(`core_discovery_runs?id=eq.${id}&owner_id=eq.${user.id}&select=*`);
        if (!rows.length) throw new ApiError('Saved record not found.', 404);
        return json(action === 'raw' ? { raw: rows[0] } : { run: publicRun(rows[0]) });
      }
      return json({ error: 'Action or method not found.' }, 404);
    } catch (error) {
      return json({ error: error instanceof ApiError || error.message?.startsWith('MISSING:') ? error.message : 'Request failed. Check Connections and the server logs.', status: 'MISSING' }, error.status ?? 502);
    }
  };
}
