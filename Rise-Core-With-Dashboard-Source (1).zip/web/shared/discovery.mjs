// Deterministic intake/discovery only. Core spaCy analysis remains in Python.
export const DISCOVERY_CONFIG = Object.freeze({
  version: 'discovery.v1', checked: '2026-09-12',
  page_size: 100, organic_limit: 10, max_content_chars: 100000,
  candidate_limit: 15, candidate_ngram_min: 2, candidate_ngram_max: 3,
  prices: { serp_micro_usd: 2000, labs_task_micro_usd: 12000, labs_item_micro_usd: 120 },
  price_sources: ['https://dataforseo.com/pricing/google-serp/google-organic-serp-api',
    'https://dataforseo.com/pricing/dataforseo-labs/dataforseo-google-api'],
  kb_snapshot: 'Stored by gateway in config_json.release: exact KB text and SHA-256 hashes.',
});
const STOP = new Set('a an and are as at be been by can for from has have how if in into is it its of on or our that the their these they this to was we were what when where which who will with you your'.split(' '));
const OPERATORS = /\b(?:allinanchor|allintext|allintitle|allinurl|define|filetype|id|inanchor|info|intext|intitle|inurl|link|site):/i;
export const ENDPOINTS = { serp: '/v3/serp/google/organic/live/advanced', ranked: '/v3/dataforseo_labs/google/ranked_keywords/live' };

export function publicUrl(value, { httpsOnly = false } = {}) {
  let url;
  try { url = new URL(String(value).trim()); } catch { throw new Error('Enter a complete page URL, including https://.'); }
  if (!['https:', 'http:'].includes(url.protocol) || (httpsOnly && url.protocol !== 'https:') || url.username || url.password || url.port ||
      !url.hostname.includes('.') || /^\d+(?:\.\d+){3}$/.test(url.hostname) || url.hostname.startsWith('[') || /(?:\.local|\.localhost|\.internal)$/.test(url.hostname)) {
    throw new Error(httpsOnly ? 'URL ranking lookup requires a public HTTPS page URL.' : 'Enter a public HTTP or HTTPS page URL without credentials or a custom port.');
  }
  url.hash = '';
  return url.href;
}

export function normalizedInput(source) {
  if (!source || !['serp', 'ranked'].includes(source.kind)) throw new Error('Choose query analysis or URL rankings.');
  const country = String(source.country ?? '').trim().toUpperCase();
  const language = String(source.language ?? '').trim().toLowerCase();
  if (!/^[A-Z]{2}$/.test(country)) throw new Error('Enter a two-letter country code, such as US.');
  if (!/^[a-z]{2,3}(?:-[a-z]{2,4})?$/.test(language)) throw new Error('Enter a language code, such as en.');
  const output = { kind: source.kind, country, language };
  if (source.kind === 'ranked') {
    output.client_url = publicUrl(source.client_url, { httpsOnly: true });
    output.offset = source.offset ?? 0;
    if (!Number.isSafeInteger(output.offset) || output.offset < 0) throw new Error('Invalid results offset.');
    return output;
  }
  output.query = String(source.query ?? '').trim();
  if (!output.query || output.query.length > 300 || /[\x00-\x1f]/.test(output.query)) throw new Error('Enter one query, up to 300 characters.');
  if (OPERATORS.test(output.query)) throw new Error('Advanced search operators are not enabled in this priced query flow. Enter a normal search query.');
  output.device = source.device ?? 'desktop';
  if (!['desktop', 'mobile'].includes(output.device)) throw new Error('Choose desktop or mobile.');
  const hasCode = source.location_code !== undefined && source.location_code !== '';
  const hasName = Boolean(String(source.location_name ?? '').trim());
  if (hasCode === hasName) throw new Error('Provide one location code or one exact location name.');
  if (hasCode) {
    if (!Number.isSafeInteger(source.location_code) || source.location_code <= 0) throw new Error('Location code must be a positive integer.');
    output.location_code = source.location_code;
  } else output.location_name = String(source.location_name).trim();
  if (source.client_url) output.client_url = publicUrl(source.client_url);
  if (source.client_domain) {
    const domain = String(source.client_domain).trim().toLowerCase();
    if (!/^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}$/.test(domain)) throw new Error('Client domain should look like example.com, without a path.');
    output.client_domain = domain;
  }
  const content = String(source.content ?? '');
  if (content.length > DISCOVERY_CONFIG.max_content_chars) throw new Error('Content exceeds the configured input limit.');
  if (content) output.content = content;
  return output;
}

export function estimatedCost(kind) {
  const p = DISCOVERY_CONFIG.prices;
  return kind === 'serp' ? { min: p.serp_micro_usd / 1000000, max: p.serp_micro_usd / 1000000 }
    : { min: p.labs_task_micro_usd / 1000000, max: (p.labs_task_micro_usd + DISCOVERY_CONFIG.page_size * p.labs_item_micro_usd) / 1000000 };
}

export function providerTask(input, scope) {
  if (input.kind === 'ranked') return [{ target: input.client_url, location_code: scope.location_code,
    language_code: input.language, item_types: ['organic'], ignore_synonyms: false,
    include_clickstream_data: false, historical_serp_mode: 'live',
    limit: DISCOVERY_CONFIG.page_size, offset: input.offset,
    order_by: ['ranked_serp_element.serp_item.rank_group,asc', 'keyword_data.keyword,asc'] }];
  return [{ keyword: input.query, location_code: scope.location_code, language_code: input.language,
    device: input.device, depth: DISCOVERY_CONFIG.organic_limit,
    load_async_ai_overview: false, people_also_ask_click_depth: 0, calculate_rectangles: false }];
}

export function providerResults(raw) {
  if (raw?.status_code !== 20000 || raw?.tasks?.length !== 1 || raw.tasks[0]?.status_code !== 20000 || !Array.isArray(raw.tasks[0]?.result)) {
    throw new Error('MISSING: provider response or task failed. Inspect the saved raw response.');
  }
  return raw.tasks[0].result;
}

export function parseDiscovery(raw, input, scope, runId) {
  const result = providerResults(raw)[0];
  if (!result || result.location_code !== scope.location_code || result.language_code !== input.language) throw new Error('MISSING: returned location or language does not match the request.');
  const pointer = '/tasks/0/result/0';
  const ref = path => ({ kind: 'RAW', run_id: runId, pointer: path });
  const base = { kind: input.kind, run_id: runId, input, scope,
    actual_cost: typeof raw.cost === 'number' && Number.isFinite(raw.cost) ? raw.cost : null,
    cost_ref: ref('/cost'), raw_available: true, rows: [],
    analysis_status: 'MISSING', analysis_reason: 'Full page extraction, analysis and drafting are not connected in this build.' };
  if (input.kind === 'ranked') {
    if (publicUrl(result.target, { httpsOnly: true }) !== input.client_url) throw new Error('MISSING: provider target differs from the requested URL.');
    const items = result.items ?? (result.items_count === 0 && result.total_count === 0 ? [] : null);
    if (!Array.isArray(items) || items.length !== result.items_count || !Number.isSafeInteger(result.total_count) || result.total_count < 0) throw new Error('MISSING: incomplete or invalid keyword inventory metadata.');
    let excluded = 0;
    items.forEach((item, index) => {
      const serp = item.ranked_serp_element?.serp_item;
      let url;
      try { url = publicUrl(serp?.url); } catch { excluded++; return; }
      if (serp?.type !== 'organic' || url !== input.client_url || typeof item.keyword_data?.keyword !== 'string') { excluded++; return; }
      base.rows.push({ query: item.keyword_data.keyword, url,
        position: Number.isInteger(serp.rank_group) && serp.rank_group > 0 ? serp.rank_group : null,
        volume: typeof item.keyword_data.keyword_info?.search_volume === 'number' ? item.keyword_data.keyword_info.search_volume : null,
        updated: item.ranked_serp_element.last_updated_time ?? null,
        ref: ref(`${pointer}/items/${index}`) });
    });
    const next = input.offset + items.length;
    return { ...base, total_count: result.total_count, total_ref: ref(`${pointer}/total_count`),
      page_item_count: items.length, offset: input.offset, excluded_rows: excluded,
      next_offset: next < result.total_count && items.length > 0 ? next : null,
      page_complete: excluded === 0 && (items.length > 0 || result.total_count === 0),
      inventory_complete: input.offset === 0 && next === result.total_count && excluded === 0,
      inventory_note: 'Country database snapshot. An individual page of results is not an exhaustive preserve-keyword inventory.' };
  }
  if (result.keyword !== input.query || !Array.isArray(result.items)) throw new Error('MISSING: SERP keyword or items are absent or mismatched.');
  const seen = new Set();
  result.items.forEach((item, index) => {
    if (item.type !== 'organic' || base.rows.length >= DISCOVERY_CONFIG.organic_limit) return;
    let url;
    try { url = publicUrl(item.url); } catch { return; }
    if (seen.has(url)) return;
    seen.add(url);
    base.rows.push({ url, title: item.title ?? null, description: item.description ?? null,
      position: Number.isInteger(item.rank_group) && item.rank_group > 0 ? item.rank_group : null,
      role: input.client_url === url ? 'client' : 'competitor', ref: ref(`${pointer}/items/${index}`) });
  });
  return { ...base, features: Array.isArray(result.item_types) ? result.item_types : null,
    features_ref: ref(`${pointer}/item_types`), observed_at: result.datetime ?? null,
    analyzed_pages: null, competitor_count: base.rows.filter(row => row.role === 'competitor').length };
}

export function candidateQueries(text, language = 'en') {
  if (language !== 'en') throw new Error('Candidate extraction currently supports English. You can still enter a target query in another language.');
  if (typeof text !== 'string' || !text.trim()) throw new Error('Paste the page content first.');
  if (text.length > DISCOVERY_CONFIG.max_content_chars) throw new Error('Content exceeds the configured input limit.');
  if (/<\/?[a-z][^>]*>/i.test(text)) throw new Error('Paste the visible page text instead of HTML code.');
  const normalized = text.normalize('NFKC').toLowerCase();
  const counts = new Map();
  let words = 0;
  for (const sentence of normalized.split(/[.!?\n;:]+/u)) {
    const tokens = sentence.match(/\p{L}+(?:['’]\p{L}+)*/gu) ?? [];
    words += tokens.length;
    for (let n = DISCOVERY_CONFIG.candidate_ngram_min; n <= DISCOVERY_CONFIG.candidate_ngram_max; n++) {
      for (let i = 0; i + n <= tokens.length; i++) {
        const phrase = tokens.slice(i, i + n);
        if (phrase.some(token => STOP.has(token) || token.length < 2)) continue;
        const query = phrase.join(' ');
        counts.set(query, (counts.get(query) ?? 0) + 1);
      }
    }
  }
  const rows = [...counts].map(([query, occurrences]) => ({ query, occurrences, position: null, volume: null,
    provenance: { kind: 'DERIVED', input: 'USER_PROVIDED_CONTENT', method: 'candidate_ngrams.en.v1' } }))
    .sort((a, b) => b.occurrences - a.occurrences || b.query.split(' ').length - a.query.split(' ').length || (a.query < b.query ? -1 : a.query > b.query ? 1 : 0))
    .slice(0, DISCOVERY_CONFIG.candidate_limit);
  return { rows, words, rankings_status: 'MISSING', method: 'candidate_ngrams.en.v1',
    limitation: 'Literal repeated phrases, without lemmatization or semantic analysis. Candidates are not observed rankings or measured search demand.' };
}

export function money(value) { return typeof value === 'number' && Number.isFinite(value) ? `$${value.toFixed(5)}` : 'MISSING'; }
