# KB-03 — Deterministic NLP measurements for the Core

Prepared and sources checked: **2026-09-11**. Version: **1.1, approved core decisions and page-mode methods**. Owner: Rise Marketing HQ.

**T1:** Google official. **T2:** vendor/maintainer documentation. **T3:** academic. **T4:** industry study, correlation-only. **T5:** unconfirmed; never a recommendation. **Internal:** a chosen measurement definition, configuration or proposed method. Internal choices are versioned configuration and measurement methods, not Google ranking facts. The core foundation has executable arithmetic/contract fixtures; statistical NLP accuracy and full acquisition integration remain UNVERIFIED.

This file defines methods and Python implementation notes. Part 2 now specifies the interfaces and fixture; the first core code slice implements pure calculations on supplied annotations. No dependency or model package was added in this step. Module 0 and KB-12 are unchanged.

## Provenance and reproducibility boundary

**Approved provenance:** RAW / DERIVED / CONFIG / DOCUMENTATION. Raw DataForSEO fields supply observations; deterministic code supplies document frequency, TF-IDF, page counts and coverage; configuration supplies cutoffs/caps; documented prices/model metrics retain their source class. The LLM does not calculate, invent or fill numeric fields.

Each measurement retains input response IDs and field paths, formula/configuration version and population. Derived draft measurements point to the exact saved draft. Retained/excluded blocks, language/model versions and software manifest accompany the run.

“Same input” means the same stored response bytes, text selection, draft where relevant, settings, code, package versions and model bytes. Re-fetching the same query is a new input. Pin CPU execution, package versions, text order, stopwords, model hash, vocabulary and clustering parameters. Store full precision; round only for display under a declared rule. Unsupported stages produce MISSING independently of stages that succeeded.

## Notation and text population — Internal

Let \(D\) be the ordered set of successfully extracted, accepted competitor documents for a metric, \(N=|D|\), and \(V\) its frozen candidate vocabulary. A document is a selected distinct organic URL, not a domain. Denominator policy must be explicit when redirects or duplicate bodies occur; do not silently collapse the user's URL sample to domains.

Let \(B_d\) be the ordered source blocks selected from document d. Each block retains the raw JSON pointer and its original string. Let \(W_d\) be the count of word tokens in those blocks, including stopwords. Let \(c_{dt}\) be the number of occurrences of term t in d under the rules below. Absent terms on a successfully analyzed page have count zero; failed analysis has no count.

Do not pool failed pages into zeros. If the text sample is incomplete, state the analyzed denominator. When N=0, aggregate text metrics are MISSING. When a specific stage fails on a page, either exclude that page for that stage with its own denominator or withhold that aggregate. Do not quietly compare metrics computed on different page sets.

## Boilerplate removal and structured text selection

Boilerplate means navigation, templates, ads and similar material outside the text being studied. Academic work shows that shallow structural/text features can help classify such material; that research does not validate a particular removal rule on this agency's corpus. [N-11, T3]

DataForSEO separates header/footer and main/secondary topics through heuristics. Secondary text can contain useful short or linked content. Its priorities are not semantic truth or Google's quality-rater definitions. See KB-01 DF-15 for the vendor's scoring explanation. [N-12, T2]

**Chosen review proposal: conservative structured-body profile.**

1. Start with topic objects in `page_content.main_topic[]` and `page_content.secondary_topic[]`. Retain topic origin and provider order; cross-array DOM order is not assumed.
2. Include each topic's `h_title` once. `main_title` is metadata, not a second body-heading occurrence.
3. Include both `primary_content[].text` and `secondary_content[].text` within those topics. Include table-cell text using `table_content` sections and row/cell positions.
4. Exclude `page_content.header` and `footer`. Keep separate `ratings`, `offers`, `comments`, and `contacts` objects as structured evidence; do not append them again to the body word count.
5. Do not append link `anchor_text` when the block's `text` already contains it. Do not also append `page_as_markdown`: that would represent the same content twice.
6. Maintain a ledger of every included/excluded source field and reason. Do not remove text merely because it appears on several competing domains. Such overlap is precisely what document frequency measures.

Formally, an explicit field-path rule supplies a mask \(m(b)\in\{0,1\}\). The analyzed blocks are \(B_d=[b\in\text{source blocks}:m(b)=1]\). There is no universal numeric “boilerplate score” in this proposal. Additional deduplication rules need separate source identity/position evidence and tests; identical text at different real positions is not automatically a duplicate extraction.

**Limits:** body navigation may survive; useful header/footer information is excluded; topic ordering may differ from the DOM; useful product details may exist only in structured objects; provider segmentation can fail. The profile is a reproducible text view, not a claim to have recovered every visible word. Empty/blocked/partial pages remain failed or partial. Whole-page validity must be reviewed on representative page types before benchmarks are trusted. No BeautifulSoup, trafilatura, boilerpipe, embedding library or other dependency is added.

## Tokenization

Tokenization segments text into token spans. Punctuation, apostrophes, hyphens, identifiers and languages without whitespace make a whitespace split inadequate as a universal definition. [N-01, T3]

spaCy's tokenizer creates a `Doc`; token attributes and offsets expose its segmentation. Statistical components then add linguistic annotations. Preserve original strings and character offsets; normalize feature keys without overwriting the source. [N-05, T2]

**Chosen word-count definition — Internal:** a word token contains at least one Unicode letter or digit and is neither whitespace/punctuation-only nor a URL/email token. Count numeric tokens as words; do not count punctuation-only tokens. A multi-token contraction counts according to the pinned tokenizer. Therefore this is a **spaCy token-based word count**, not necessarily the vendor's `plain_text_word_count`.

\[
W_d=\sum_{b\in B_d}\sum_{u\in\operatorname{tokens}(b)}
\mathbf{1}[\operatorname{word}(u)].
\]

Python notes: process original block text with the approved pipeline; inspect `token.text`, `token.idx`, `token.is_space`, `token.is_punct`, `token.like_url`, and `token.like_email`. A word predicate can use `any(ch.isalnum() for ch in token.text)` after those exclusions. Store offsets relative to the original block plus its JSON pointer. NFC/casefold normalization belongs to matching keys, not a rewritten source text whose offsets no longer align.

**Limits:** different tokenizer versions can change counts; product names and technical strings may split unexpectedly; token counts are not universal linguistic word counts. An unsupported language must not silently use English processing. Long-input limits must cause an explicit failure or a declared chunking policy; never truncate invisibly.

## Stopword removal

Stopword removal excludes a specified set of frequent function words from a feature vocabulary. It can reduce noise but can also destroy meaningful phrases and distinctions. Its usefulness depends on the task. [N-02, T3]

**Chosen policy — Internal:** freeze a language-specific set S from the approved spaCy language defaults, with an explicit retained-negation exception set (`no`, `not`, `nor`, `never` for English). Store the effective set and hash; do not rely solely on mutable `token.is_stop`. For a word token, test its normalized surface and lemma against S. Preserve negation when either surface or lemma matches the retained-negation set.

Stopwords are excluded from unigram candidates, but remain in the text, word-count denominator, NER input, heading display and internal positions of n-grams. Stopword-only multiword sequences are rejected. The mathematical filtering rule is feature selection, not deletion from the original stream:

\[
V_1=\{\ell(u):\operatorname{word}(u)\land\neg\operatorname{stop}(u)\}.
\]

**Limits:** generic defaults can discard meaningful words or retain site navigation; no stopword list is universally correct. Version exceptions instead of having the LLM invent per-run stopwords. Do not infer that Google ignores a word because this tool filters it.

## Lemmatization

Lemmatization maps inflected forms to a base lexical form using vocabulary and linguistic information; it differs from suffix-stripping stemming. [N-03, T3] spaCy's rule-mode lemmatizer depends on POS annotation from an earlier component. [N-06, T2]

**Chosen feature key — Internal:**

\[
\ell(u)=\operatorname{casefold}(\operatorname{NFC}(u.\text{lemma\_})).
\]

Use the approved English trained pipeline, including its tagger, attribute ruler and lemmatizer. Keep a surface-form-to-lemma record so a writer sees readable observed variants. An uninitialized `spacy.blank("en")` is not equivalent to the trained lemmatization/NER pipeline. If the required component or a needed lemma is missing, label the affected lemma analysis MISSING; a separate surface-token count may still be available if explicitly named.

**Limits:** POS ambiguity, jargon, spelling errors and unseen brands can produce wrong merges or splits. Lemma equivalence does not establish synonymy, search intent or entity identity. Preserve originals for review. Never replace prices, measurements or first-person claims with generated variants.

## Contiguous n-grams: unigrams, bigrams and trigrams

An n-gram is an ordered sequence of n adjacent tokens; here n is in {1,2,3}. scikit-learn can count n-grams, but its default tokenizer and stopword behavior must not silently replace the policy above. [N-07, T2]

**Chosen boundary policy — Internal:** construct windows on the original token sequence after assigning lemma keys, before filtering out stopwords. A punctuation-only token, excluded URL/email token, sentence boundary, block boundary or table-cell boundary breaks a window. Whitespace between words does not. Retain a multiword window only if all members are word tokens and at least one is non-stop. Do not join across removed tokens.

For valid windows \(\mathcal{W}_{d,n}\):

\[
c_{dt}=\sum_{w\in\mathcal{W}_{d,n}}
\mathbf{1}[(\ell(w_1),\dots,\ell(w_n))=t].
\]

Overlapping occurrences count. For example, the token sequence `a a a` contains two adjacent bigram windows before any stopword rule is applied. Store n with the term key; a trigram is one occurrence, not three occurrences.

Python notes: a custom `CountVectorizer(analyzer=...)` can emit these precomputed feature strings, with vocabulary keys sorted deterministically. With a callable analyzer, explicitly generate n-grams and apply stopword policy in that callable; do not expect `ngram_range`/`stop_words` to add the missing behavior. The same analyzer must process competitor text and the draft. [N-07; Internal choice]

**Limits:** lexical n-grams miss paraphrases and long phrases, can count awkward fragments, and can inflate signals from repeated templates. Treat candidate terms as observed strings, not verified concepts or recommended copy. Canonical URL normalization and extraction must be fixed before comparing document counts.

## Document frequency and prevalence

Document frequency counts how many documents contain a term, regardless of how often it occurs within each document. [N-04, T3]

\[
df(t)=\sum_{d\in D}\mathbf{1}[c_{dt}>0],\qquad
p(t)=\frac{df(t)}{N}\quad(N>0).
\]

Python note: for a count matrix X with pages as rows, `(X > 0).sum(axis=0)` supplies df. Count pages, not occurrences, headings or domains. Terms absent from every successful page have df=0 but are outside an observed-only candidate vocabulary.

**Approved internal tiers:** Required when p≥0.7; Recommended when 0.4≤p<0.7; Differentiators when 0<p<0.4, with configurable cutoffs. N counts successful competitor text/term pages. If N<5, omit tiers and show raw df; if N<7, show the low-sample warning. Client and comparison pages never enter this denominator. At N=10 the original cutoffs remain 7+, 4–6, and 1–3. Use exact fractions for comparisons, not display-rounded percentages.

**Limits:** a small, selected SERP sample has selection bias and correlated pages; prevalence is descriptive, not causal. “Required” is an agency label, not a Google rule. “Differentiators” means uncommon in this sample, not proven information gain. Extraction failures can systematically exclude particular page types.

## Term frequency per 1,000 words and ranges

**Internal exact definition:**

\[
TF_{1000}(t,d)=1000\frac{c_{dt}}{W_d},\qquad W_d>0.
\]

The denominator includes stopwords and numeric word tokens in the selected text view. An n-gram occurrence is divided by word count, not by the number of n-gram windows. NER mentions, snippets and excluded navigation do not increase this numerator. If W=0, the value is MISSING; do not divide by a replacement denominator.

For accepted documents with valid W, define the observed range:

\[
R_t=[\min_d TF_{1000}(t,d),\ \max_d TF_{1000}(t,d)].
\]

Include valid zero occurrences. If showing a positive-occurrence-only range, label it separately and report its page count. Do not silently drop zeros to make suggested minimum usage appear positive. A positive-only range is MISSING if no page contains the term.

Python notes: calculate from integer counts with float64 or exact rational intermediate arithmetic; preserve numerator/denominator. Use a declared display rounding rule without modifying comparison values. A draft occurrence interval derived from a length target needs a separately approved rounding/editorial policy, not an LLM guess.

**Limits:** short pages can yield high rates, repetition can inflate counts, and a min/max range is sensitive to extremes. None establishes optimal keyword density. Prefer natural writing and human review, as explained in KB-02.

## TF-IDF: the selected variant

Use scikit-learn's natural-count TF, smoothed IDF and L2 row normalization: `TfidfTransformer(use_idf=True, smooth_idf=True, sublinear_tf=False, norm="l2")`. Use natural logarithms. This is the exact selected variant; do not substitute unsmoothed textbook IDF, log-TF or per-1,000 TF. [N-08, T2]

\[
idf(t)=\ln\left(\frac{1+N}{1+df(t)}\right)+1,
\qquad w_{dt}=c_{dt}\,idf(t),
\]
\[
v_{dt}=\frac{w_{dt}}{\sqrt{\sum_{u\in V}w_{du}^{2}}}
\quad\text{if the row norm is positive.}
\]

The all-zero row remains zero in the transformation; its cosine similarity is not mathematically defined and must not be interpreted as semantic evidence. If no valid vocabulary exists, return an explicit empty-vocabulary/MISSING result instead of fitting an invalid matrix. A term present in every document has idf=1 in this variant, not zero. [N-08; Internal missing-state policy]

**Internal aggregation:** retain per-page `c`, `df`, `idf`, unnormalized w and normalized v as distinct quantities. If a single summary is required, define \(\bar v_t=N^{-1}\sum_dv_{dt}\), including valid zeros, and label it mean normalized TF-IDF. Do not relabel it search volume, topical importance or a Google score.

Python notes: fit X and IDF on successful competitors only. Freeze vocabulary and IDF before transforming a draft; never refit on the draft and move its own benchmark. Unseen draft terms are out-of-vocabulary and reported separately. Sorting the vocabulary and document IDs makes column/row identity reproducible. All retained 1–3-gram candidates enter the declared vocabulary before later UI filtering.

**Limits:** corpus-specific rarity is not semantic importance; unusual brand/navigation fragments can score highly. Vocabulary changes alter normalized weights. Normalization couples terms within a document. Lexical paraphrases may score differently despite similar meaning. KB-02 records why this method is not presented as Google's current production formula.

## Named entity recognition and entity page counts

NER labels spans such as organizations, people and places. It is statistical extraction, not entity linking, fact verification, or a complete list of SEO topics. spaCy's transition-based recognizer produces non-overlapping spans and can struggle when boundaries are ambiguous or decisive evidence lies late in a long entity. [N-09, T2]

**Approved model:** `en_core_web_sm` **3.8.0**, a CPU-oriented English pipeline, compatible with spaCy `>=3.8.0,<3.9.0` according to its metadata. Its metadata lists no static word vectors, and names OntoNotes 5 among its sources. The model family is described as English web text (blogs/news/comments). Compatible spaCy 3.8.x and this model are approved; exact patch locking and model integration remain an implementation step. scikit-learn 1.8.x is approved. [N-10, N-13, T2]

The official model metadata publishes these benchmark values; they are documentation facts, not results measured on contractor content:

| Metric | Exact value from metadata | JSON pointer |
|---|---:|---|
| Entity precision | 0.8429743795 | `/performance/ents_p` |
| Entity recall | 0.8436498397 | `/performance/ents_r` |
| Entity F1 | 0.8433119744 | `/performance/ents_f` |
| PRODUCT F1 | 0.3087248322 | `/performance/ents_per_type/PRODUCT/f` |
| ORG F1 | 0.8045827366 | `/performance/ents_per_type/ORG/f` |
| GPE F1 | 0.9044262757 | `/performance/ents_per_type/GPE/f` |

Source: N-10. Broad NER performance does not establish accurate recognition of local businesses, equipment brands, products, credentials or service terminology. Accuracy for this tool's actual languages/page types is **UNVERIFIED**.

**Internal identity/count policy:** run NER on the original retained blocks, preserving case. Retain `ent.text`, `label_`, `start_char`, `end_char` and source pointer. The initial identity key is `(NFC + whitespace-normalized + casefolded surface, label)`; keep displayed originals. Do not automatically equate acronyms, aliases or similarly named companies. The approved EntityRuler runs before statistical NER with versioned per-vertical patterns; the roofing fixture supplies canonical brand, material, product and certification IDs. Capture spans before NER and preserve source=ruler versus source=model. Model spans use surface+label unless an explicit reviewed alias map applies. Count unique pages per source and their union separately. See Part 2 and its A-03/A-04 maintainer sources.

\[
df(e)=\sum_{d\in D_{NER}}\mathbf{1}[e\text{ appears at least once in }d],
\qquad p(e)=df(e)/|D_{NER}|.
\]

Count once per successful page, not once per mention. Dates, money and cardinal-number spans remain observed source material; they are not facts to reuse as client claims. A recognized organization is not a verified credential. Ordinary service concepts may have no NER label and still be important to the brief.

For future labeled evaluation, define precision=TP/(TP+FP), recall=TP/(TP+FN), and F1=2TP/(2TP+FP+FN), using exact span plus label matches. Undefined denominators are MISSING. Evaluation labels are human reference data, not LLM-generated numbers. No such tool-specific evaluation is claimed here.

## Heading clustering

**Chosen method — Internal:** lexical TF-IDF plus complete-linkage agglomerative clustering, using only confirmed H2/H3 headings. Retain raw headings, levels, URLs and positions; do not treat a SERP title as a page H2. If the extraction cannot confirm heading level/order, that dimension is MISSING.

Deduplicate identical normalized heading strings for the vector fit while keeping all page/position occurrences. Tokenize/lemmatize under the same boundary policy. Build heading-specific TF-IDF vectors with the variant above; its IDF corpus is headings, not competitor pages. For nonzero vectors x and y:

\[
\operatorname{cos}(x,y)=\frac{x\cdot y}{\|x\|_2\|y\|_2},\qquad
\delta(x,y)=1-\operatorname{cos}(x,y).
\]

Cosine is defined by scikit-learn's pairwise metrics reference. [N-14, T2]

Complete-linkage distance is:

\[
\Delta(A,B)=\max_{x\in A,y\in B}\delta(x,y).
\]

At each step, merge the eligible pair with smallest distance while it is **below** the configured distance threshold. `AgglomerativeClustering(metric="cosine", linkage="complete", n_clusters=None, distance_threshold=tau, compute_full_tree=True)` matches the selected algorithm. Ward linkage is not substituted because this selection uses cosine. [N-15, T2]

**Provisional configuration:** `tau=0.35`, explicitly uncalibrated and not a Google fact. Zero-vector headings remain individual/unclustered records. Sort unique heading keys before fitting, preserve the distance matrix, and pin package versions for tie/float behavior. Exact duplicate strings share their stored group. A single heading needs no clustering call.

A deterministic displayed cluster label can be an observed medoid: choose the heading minimizing the sum of within-cluster distances; break ties by normalized heading key. Store member headings and distinct page counts. The LLM may later write a brief outline, but it does not decide these measured clusters or their counts.

**Limits:** lexical similarity misses synonyms, may group opposite questions, and can confuse shared generic words with equivalent coverage. Short headings yield sparse vectors. Complete linkage can split related topics. Clusters do not recover a reliable H2/H3 parent tree from level-grouped arrays. Threshold quality and clustering accuracy on this tool's pages are **UNVERIFIED** until reviewed examples are available. No embedding model is added.

## Questions and benchmarks: measurement boundaries

These notes prevent ambiguous use of the methods above; the output contracts remain Part 2 work.

- PAA source strings come from the SERP response path documented in KB-01. A heading-question detector can use terminal question marks plus a versioned language-specific interrogative rule set; mark detected strings as candidates. Rhetorical questions and punctuation-free questions limit accuracy. Do not let an LLM manufacture observed questions.
- Word-count ranges, H2/H3 counts and entity counts must state the text/heading definition and eligible pages. A zero is permitted only when the relevant extraction succeeded.
- On-page FAQ sections, schema types and SERP features require separate observations. Do not infer markup from a question heading, or an image count from a placeholder URL. Missing schema/video extraction stays MISSING.
- The approved equal-weight brief coverage is 100×PASS/(PASS+FAIL), with assessed/expected counts and missing checks reported separately. The first core fixture tests this arithmetic; it is not a semantic quality or ranking score.

## Approved page-mode methods — Internal, CONFIG

Page mode (NEW / IMPROVE / REWRITE) is separate from Module 0 scope. NEW requires no client URL. With a client URL, freeze the competitor brief first and measure the old page against it. Use complete assessable coverage for the mode trigger; a partial score cannot establish low coverage. The code uses three-valued rules: any known true rule gives REWRITE; no true rule plus a required missing input gives MISSING; otherwise IMPROVE. The user may override the result, with an immutable decision reference, actor and reason.

REWRITE triggers: coverage <40%; opposite page-type quorum ≥7; five-shingle Jaccard ≥0.75 or shorter-set containment ≥0.85 against a supplied client comparison; or clean-body length below P25 AND coverage <60%. All cutoffs are CONFIG, with strict versus inclusive comparisons retained. The page-type quorum remains an absolute seven observed pages, not 70% of a smaller sample. Client pages are excluded from competitor counts, lengths and IDF.

Google's documented result formats describe how results appear; an organic/text item does not itself label the destination a service page or guide. [N-16, T1] The **internal uncalibrated** roofing profile requires a service heading phrase plus a call-to-action body phrase for SERVICE_COMMERCIAL, or an informational heading phrase plus an explanatory body phrase for INFORMATIONAL. Both/neither becomes UNKNOWN; failed text/headings becomes MISSING. Exact phrases, matched evidence and version are in `page_profiles.roofing.v1.json`. This heuristic can misclassify mixed-purpose, ecommerce or unconventional pages; an unconfigured vertical is UNKNOWN rather than assumed roofing. No classifier accuracy is claimed.

P25 uses a declared linear-interpolation quantile: sort accepted competitor lengths x; let r=(N−1)×0.25, i=floor(r), f=r−i; return x[i]+f×(x[i+1]−x[i]), or x[i] when f=0. N=0 is MISSING. This choice is CONFIG, not an externally established preferred content length.

For normalized surface-word five-shingle sets A and B, J=|A∩B|/|A∪B|; containment=|A∩B|/min(|A|,|B|). Short inputs with no five-shingle sets are MISSING. Preserve matched shingles, compared URLs and source/configuration refs. Normal and supplied geo-masked comparisons use the same calculation; mask dictionaries are versioned inputs. This reuses the parked Module 0 method without changing it. Similarity does not establish Google spam-policy compliance.

Before REWRITE generation, the exact-URL, fully paginated country Labs inventory supplies every reported organic keyword at positions 1–20 as a preserve check (KB-01 DF-26). Keep the URL. Freeze the enriched brief and show before/after against the same check IDs; retain the earlier classification score separately. Source-scope failure is MISSING, not permission to discard keywords.

## Entity-attribute matrix and question gaps — Internal

For successful competitor text/POS/NER pages D, define a cell count c(e,a)=sum over d in D of 1[entity e and attribute a co-occur in at least one retained sentence of d]. Repetition within a page adds no pages. The source ledger records sentences and ruler/model entity mentions; entity page counts are unions, with per-source counts also retained.

Candidate attributes are the approved versioned vertical list UNION noun/adjective lemmas that co-occur with an entity on at least two pages. Exclude entity-span tokens from attribute discovery and exclude PROPN tokens from corpus-derived attributes. A corpus lemma qualifies when at least one entity–attribute pair meets the page floor; seed attributes need no floor. For each selected entity, then measure every selected attribute cell, including valid zeroes. A seed can match its lemma irrespective of POS. Missing NLP stages are excluded explicitly.

Select the top ten entities by page count, then the top fifteen attributes by their distinct-page co-occurrence count across those selected entities. Break entity ties by canonical ID; attribute ties by seed order then lexical key. Caps and the two-page eligibility floor are CONFIG. Rank the entire union so a discovered adjective can enter the capped matrix. Cells on one or two pages are flagged as attribute gaps and become priority inputs. A zero is not labeled an answered/absent question; co-mention is not semantic entailment or a verified attribute value.

The observed question collection combines PAA and question-like competitor headings. Store AI Overview reference URLs and exact response pointers separately, including nested references. Google's AI feature guidance describes supporting links and query expansion; those references do not prove that our sampled pages answered a question. [N-17, T1] Cached-only acquisition may return no AIO item; label NOT_RETURNED rather than asserting universal absence. References do not silently enlarge the competitor sample or trigger extra crawls.

**Missing B configuration:** the earlier unanswered-detection definition and gap-priority formula were not available. Collection is enabled, but answer labels/production priority scores remain MISSING. Do not substitute heading absence, same-sentence co-mention or LLM judgment for the missing rule. A generic configured additive scorer exists as a pure interface; it has no production weights and is not asserted to be the earlier B formula.

Fact salvage copies matching old-page excerpts into NEEDS SME INPUT slots with “FOUND ON CURRENT PAGE — VERIFY.” Patterns cover years, certifications, named projects, warranties, service areas, phones and addresses. They neither verify facts nor comprehensively extract them. These excerpts never enter the parity writing context. No client fact is inferred from a competitor entity mention.

## Unit-test obligations before implementation is accepted

The following are acceptance obligations. The first core slice verifies term arithmetic, coverage, modes, preservation and source pointers on synthetic annotations; the remaining extraction and fixed-model obligations are still pending:

| Method | Failure mode an independent expected-value test must cover |
|---|---|
| Source selection | Header/footer exclusion, useful secondary text, table cells, no duplicate markdown/anchor counting |
| Tokens/lemmas | Unicode, case, contractions, hyphens, URLs, numbers, POS ambiguity, missing model and long input |
| Stopwords/n-grams | Negation preserved; no false adjacency after filtering; no sentence/block/cell crossing; overlapping windows |
| DF | Repetition within one page does not add pages; failed-page exclusion and N=0 |
| TF/1,000 | Known numerator/word denominator, absent term zero, zero-word MISSING |
| TF-IDF | Hand-derived smoothed IDF/L2 values, ubiquitous term idf=1, frozen IDF for draft, empty vocabulary |
| NER aggregation | Repeated mentions once/page, label distinctions, missing-stage denominator; accuracy is evaluated separately |
| Heading clustering | Known distances, strict threshold boundary, duplicate/zero vectors, stable tie handling |
| Reproducibility | Identical stored bytes/settings/model/version yield identical serialized measurements |

Tests should compare against independently calculated values, not mirror the implementation. Fixed-model inference can be repeatable while wrong; unit tests do not replace extraction/NER/cluster quality evaluation. No model training or calibration is performed in Part 1.

## Completeness checklist

- [x] Tokenization, stopwords, lemmatization and contiguous 1–3-gram definitions.
- [x] Exact DF, prevalence, TF/1,000 and range formulas with denominators.
- [x] Selected smoothed TF-IDF variant, normalization and Python parameters.
- [x] Named English spaCy model, version compatibility, published evaluation fields and limits.
- [x] Entity page-count definition and human-evaluation formulas.
- [x] Heading clustering formula, linkage, threshold status and limitations.
- [x] Boilerplate profile, field provenance and method limitations.
- [x] Unit-test obligations stated without claiming implementation.
- [ ] **UNVERIFIED:** actual corpus extraction quality, NER/heading-cluster accuracy, non-English model coverage, model/package installation and complete reproducibility validation.
- [x] User approved provenance classes, denominator floors, English model and scikit-learn version family.
- [x] Page modes, P25, duplicate thresholds, entity-attribute method and SME-only salvage specified below.
- [ ] **UNVERIFIED / missing configuration:** prior B unanswered-detection and gap-priority formula.

## Source register

All sources accessed **2026-09-11**. The academic textbook is Manning, Raghavan and Schütze, *Introduction to Information Retrieval* (2008); linked pages are the authors' online edition. Maintainer API references are T2 for method behavior, not SEO effects. Internal formulas/policies are identified in their sections and do not acquire an external evidence tier.

| ID | Tier | Source URL | Source version/date |
|---|---|---|---|
| N-01 | T3 | [Tokenization](https://nlp.stanford.edu/IR-book/html/htmledition/tokenization-1.html) | IIR, 2008 |
| N-02 | T3 | [Stop words](https://nlp.stanford.edu/IR-book/html/htmledition/dropping-common-terms-stop-words-1.html) | IIR, 2008 |
| N-03 | T3 | [Stemming and lemmatization](https://nlp.stanford.edu/IR-book/html/htmledition/stemming-and-lemmatization-1.html) | IIR, 2008 |
| N-04 | T3 | [Inverse document frequency](https://nlp.stanford.edu/IR-book/html/htmledition/inverse-document-frequency-1.html) | IIR, 2008 |
| N-05 | T2 | [spaCy linguistic features](https://spacy.io/usage/linguistic-features) | Rolling docs; accessed date above |
| N-06 | T2 | [spaCy Lemmatizer](https://spacy.io/api/lemmatizer) | Rolling docs; accessed date above |
| N-07 | T2 | [CountVectorizer](https://scikit-learn.org/1.8/modules/generated/sklearn.feature_extraction.text.CountVectorizer.html) | scikit-learn 1.8.0 |
| N-08 | T2 | [TfidfTransformer](https://scikit-learn.org/1.8/modules/generated/sklearn.feature_extraction.text.TfidfTransformer.html) | scikit-learn 1.8.0 |
| N-09 | T2 | [spaCy EntityRecognizer](https://spacy.io/api/entityrecognizer) | Rolling docs; accessed date above |
| N-10 | T2 | [Official English model metadata](https://github.com/explosion/spacy-models/blob/master/meta/en_core_web_sm-3.8.0.json) | en_core_web_sm 3.8.0; benchmark fields read from raw JSON |
| N-11 | T3 | [Kohlschütter, Fankhauser, Nejdl: Boilerplate Detection Using Shallow Text Features](https://research.uni-hannover.de/en/publications/boilerplate-detection-using-shallow-text-features/) | WSDM 2010; published 2010-02-04; DOI 10.1145/1718487.1718542; institutional abstract/record |
| N-12 | T2 | [DataForSEO content priority method](https://dataforseo.com/help-center/difference-between-primary-and-secondary-content) | Updated 2025-05-21 |
| N-13 | T2 | [spaCy English model family](https://spacy.io/models/en) | Rolling docs; model metrics loaded separately from N-10 |
| N-14 | T2 | [Pairwise metrics / cosine similarity](https://scikit-learn.org/1.8/modules/metrics.html#cosine-similarity) | scikit-learn 1.8 documentation |
| N-15 | T2 | [AgglomerativeClustering](https://scikit-learn.org/1.8/modules/generated/sklearn.cluster.AgglomerativeClustering.html) | scikit-learn 1.8.0 |
| N-16 | T1 | [Google Search visual elements gallery](https://developers.google.com/search/docs/appearance/visual-elements-gallery) | Rolling Google documentation; accessed 2026-09-11 |
| N-17 | T1 | [AI features and your website](https://developers.google.com/search/docs/appearance/ai-features) | Rolling Google documentation; accessed 2026-09-11 |

Recheck version compatibility before approved implementation. The selected English model is not a claim of universal language support; additional model packages require the user's dependency approval.
