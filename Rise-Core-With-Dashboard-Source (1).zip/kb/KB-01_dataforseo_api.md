# KB-01 — DataForSEO API contracts for the Core

Prepared and sources checked: **2026-09-11**. Version: **1.2, approved page-mode additions**. Owner: Rise Marketing HQ. This is the source contract. The accompanying core foundation now has a fixture-tested Ranked Keywords request/parser adapter; no paid production run was executed.

**Approved decision record:** numeric provenance is RAW / DERIVED / CONFIG / DOCUMENTATION, with calculations exclusively in code. Labs uses a separately labeled country scope. The MVP adds Instant Pages for headings, word count and image count alongside Content Parsing for body text. Microdata is excluded and schema benchmarks remain MISSING. Use one task/request and host serialization; JavaScript starts off and a page gets at most one logged JavaScript retry for empty/near-empty extraction. These approvals resolve the earlier scope questions without resolving vendor-documentation ambiguities. Part 2 specifies the implementation contracts.

**T1:** Google official. **T2:** vendor/maintainer documentation. **T3:** academic. **T4:** industry study, correlation-only. **T5:** unconfirmed; never a recommendation. **Internal:** an application rule or proposed implementation choice, not external ranking evidence. A verified T2 contract is not a verified Google ranking factor. **UNVERIFIED** identifies a gap or inconsistency; runtime data that cannot be obtained is **MISSING**.

Module 0 and `KB-12_query_scope_and_location.md` remain parked and unchanged. KB-12 owns detailed SERP location, coordinate, language, device and grid conventions. This file supplies the Core API reference and cross-references that record without expanding it. Its formerly unassigned API tier is not rewritten here.

## Common request and response conventions

The original eight endpoints and newly approved Ranked Keywords endpoint use HTTPS POST at `https://api.dataforseo.com` with JSON UTF-8, HTTP Basic authentication, and an outer array of task objects. Credentials belong in server environment variables. The complete URL is the host plus the path below. [DF-01–DF-08, DF-26]

The shared response envelope contains `version`, `status_code`, `status_message`, `time`, `cost`, `tasks_count`, `tasks_error`, `tasks[]`. Each task contains `id`, `status_code`, `status_message`, `time`, `cost`, `result_count`, `path[]`, `data`, `result[]`. `data` echoes task parameters; costs are USD. [DF-01–DF-08]

**Internal handling:** inspect transport, envelope, task, and page statuses separately. HTTP success alone is insufficient. Persist the original response before transformation. Preserve unknown fields and native nulls. Missing fields/failed tasks become MISSING with a reason; observed zero remains zero. Reconcile envelope cost against task costs, but do not add both together. A timeout with no response means cost is MISSING, not zero. No paid API requests were made for this research.

Notation: `R` below means `tasks[i].result[j]`, `I` means `R.items[k]`. Arrays must be iterated; these symbols do not assume a single result object. Request tables list endpoint-specific fields, not the response-only `api`, `function`, or `se_type` values echoed in examples.

## Endpoint and limits register

Published limits are ceilings, not reserved capacity or throughput guarantees. Shared/account-wide enforcement and account-specific overrides are UNVERIFIED. [DF-01–DF-08]

| Source | Endpoint | Exact POST path | Calls/minute | Tasks per request | Simultaneous calls | Keyword/result constraints |
|---|---|---|---:|---|---|---|
| DF-01 | Organic Live Advanced | `/v3/serp/google/organic/live/advanced` | 2,000 | 1 | UNVERIFIED here | `keyword` ≤700 characters; `depth` default 10, maximum 200 |
| DF-02 | Content Parsing Live | `/v3/on_page/content_parsing/live` | 2,000 | 1 | UNVERIFIED | One URL |
| DF-03 | Instant Pages | `/v3/on_page/instant_pages` | 2,000 | **UNVERIFIED: contradictory documentation** | 30 | One URL per task; duplicate-host queue restriction |
| DF-04 | Keyword Overview | `/v3/dataforseo_labs/google/keyword_overview/live` | 2,000 | 1 | 30 | ≤700 keywords; ≤80 characters and ≤10 words per keyword |
| DF-05 | Search Intent | `/v3/dataforseo_labs/google/search_intent/live` | 2,000 | 1 | 30 | ≤1,000 keywords |
| DF-06 | Related Keywords | `/v3/dataforseo_labs/google/related_keywords/live` | 2,000 | 1 | 30 | `depth` 0–4; `limit` default 100, maximum 1,000 |
| DF-07 | Keyword Suggestions | `/v3/dataforseo_labs/google/keyword_suggestions/live` | 2,000 | 1 | 30 | `limit` default 100, maximum 1,000 |
| DF-08 | Bulk Keyword Difficulty | `/v3/dataforseo_labs/google/bulk_keyword_difficulty/live` | 2,000 | 1 | 30 | ≤1,000 keywords |
| DF-26 | Ranked Keywords | `/v3/dataforseo_labs/google/ranked_keywords/live` | 2,000 | 1 | 30 | `limit` default 100, maximum 1,000; offset pagination |

Instant Pages explicitly says both one task per Live call and up to 20 tasks per request, with at most five identical domains. Its URL note also warns against another task on a host still queued, returning `40501`. The approved conservative subset is one task/request with host serialization; actual batching semantics need vendor confirmation. This is not a spend-approval workflow. [DF-03]

## Geographic, language and freshness boundaries

`GET /v3/dataforseo_labs/locations_and_languages` is free. Its documented `location_type` is **Country only**; `location_code_parent` is null. Validate both the country/language pair and `available_sources` containing `google`. A city code from the SERP catalog is not a Labs code. [DF-12]

**Approved scope treatment:** a city SERP cannot supply city-level metrics through these Labs endpoints. Keep the chosen local SERP, request separately labeled country-level Labs metrics, and store both scopes. Do not silently substitute a country. Search Intent accepts language, but no location or device. Its label is not a city/device-specific observation. Unsupported coverage remains MISSING. [DF-05, DF-12]

Labs “Live” describes response delivery from its databases. It does not mean each keyword metric is freshly measured during the request. Keyword Overview documents monthly Google Ads refreshes and possible revision of historical monthly values. Preserve `last_updated_time` separately for each available metric family and retain the collection timestamp. [DF-04]

## Organic Live Advanced — Core reference

Required: `keyword:string`; one location selector (`location_code:integer`, `location_name:string`, or `location_coordinate:string`); one language selector (`language_code:string` or `language_name:string`). KB-12 supplies selector semantics and device defaults. [DF-01]

Optional field inventory, beyond the KB-12 selectors: `depth:integer`, `device:string`, `os:string`, `se_domain:string`, `tag:string`, `url:string`, `search_param:string`, `target:string`, `max_crawl_pages:integer`, `stop_crawl_on_match:array`, `target_search_mode:string`, `find_targets_in:array`, `ignore_targets_in:array`, `remove_from_url:array`, `group_organic_results:boolean`, `people_also_ask_click_depth:integer`, `load_async_ai_overview:boolean`, `calculate_rectangles:boolean`, `browser_screen_width:integer`, `browser_screen_height:integer`, `browser_screen_resolution_ratio:number`. Each stop target has `match_type` and `match_value`. Numeric resolution-ratio values are documented despite an integer type label. [DF-01]

Core fields: `R.keyword`, `location_code`, `language_code`, `datetime`, `check_url`, `item_types[]`, `items[]`; organic items have `type`, `rank_group`, `rank_absolute`, `url`, `domain`, `title`, `description`. PAA questions are `I.items[].title` where `I.type="people_also_ask"`; expanded source material is under `expanded_element[]`. [DF-01]

**Internal:** select `type="organic"`, preserve provider rank/order, then deduplicate URLs under an explicit normalization rule. `items_count` includes other features and is not the organic denominator. A depth of 10 does not guarantee 10 distinct usable URLs. Do not synthesize missing competitors. Additional SERP pulls are a Part 2 decision.

## On-Page requests: shared and endpoint-specific options

Both endpoints require `url:string`. Every other field below is optional. These are document contracts, not an instruction to enable all options. [DF-02, DF-03]

| Field(s) | Type | Documented behavior/default |
|---|---|---|
| `custom_user_agent` | string | Default `Mozilla/5.0 (compatible; RSiteAuditor)` |
| `accept_language` | string | Request header; omission can cause access denial |
| `browser_preset` | string | `desktop`, `mobile`, `tablet`; requires JavaScript or browser rendering |
| `browser_screen_width`, `browser_screen_height` | integer | 240–9,999 pixels; custom values override preset |
| `browser_screen_scale_factor` | number | 0.5–3; requires JavaScript or browser rendering |
| `store_raw_html` | boolean | false; enables later Raw HTML retrieval |
| `disable_cookie_popup` | boolean | false |
| `enable_javascript` | boolean | false; additional charge |
| `enable_browser_rendering` | boolean | false; additional charge; dependency discrepancy below |
| `enable_xhr` | boolean | false; requires JavaScript |
| `switch_pool` | boolean | Alternative provider proxy pools; default not stated |
| `ip_pool_for_scan` | string | `us` or `de`; this is fetch origin, not the SERP location |

Preset dimensions: desktop 1920×1080 at scale 1; mobile 390×844 at scale 3; tablet 1024×1366 at scale 2. [DF-02, DF-03]

| Endpoint | Additional optional fields | Meaning/constraints |
|---|---|---|
| Content Parsing | `markdown_view:boolean` | false; adds `page_as_markdown` |
| Instant Pages | `load_resources:boolean` | false; additional charge |
| Instant Pages | `return_despite_timeout:boolean` | false; can return partial data after the documented 120-second timeout |
| Instant Pages | `custom_js:string` | Execution budget ≤700 ms; returns `custom_js_response` and exception information |
| Instant Pages | `validate_micromarkup:boolean` | false; enables separate Microdata retrieval |
| Instant Pages | `check_spell:boolean` | false; provider spelling check |
| Instant Pages | `checks_threshold:array` | Override supported integer check thresholds |

**UNVERIFIED:** Content Parsing says rendering requires `enable_javascript` and `load_resources`, but omits `load_resources` from its request table. Instant Pages says rendering enables both automatically. Do not transfer one endpoint's dependency rules to the other. [DF-02, DF-03]

## What the On-Page responses actually expose

| Need | Content Parsing Live [DF-02] | Instant Pages [DF-03] |
|---|---|---|
| Extraction outcome | `R.crawl_progress`, `crawl_status`; `I.type`, `fetch_time`, page `status_code` | `R.crawl_progress`, `crawl_status`; `I.resource_type`, `status_code`, `url`, `fetch_time`, `resource_errors`, `checks` |
| Text | `I.page_content`; `primary_content[].text`, `secondary_content[].text` in `header`, `footer`, `main_topic[]`, `secondary_topic[]`; optional `page_as_markdown` | `I.meta.content` contains measurements, **not a documented full plain-text string** |
| Headings | Topic `h_title`, `main_title`, `level` | `I.meta.htags.h1` through `h6` when present |
| Other structured content | `ratings`, `offers`, `comments`, `contacts`; links in `url`/`urls[]` | `meta.title`, `description`, `canonical`, `social_media_tags` |
| Word count | Calculate from the chosen text view; no equivalent count field confirmed | `meta.content.plain_text_word_count` |
| Media | No complete image/video inventory confirmed | `meta.images_count`, `images_size`, `scripts_count`, `stylesheets_count`; a complete video inventory is UNVERIFIED |
| Schema | A structured extraction object is **not** a schema.org inventory | No complete JSON-LD/Microdata graph in the base response contract |

`table_content` holds table sections `header`, `body`, `footer`, each with rows containing `row_cells[].text`, `urls`, `is_header`. Do not lose table text or count anchor text twice. [DF-16]

**UNVERIFIED:** Content Parsing's field table calls `level` a string while its example contains integers; it labels `h_title` as “meta title” and `level` as “HTML level.” Those labels do not establish a complete ordered H2/H3 tree. Heading arrays in Instant Pages group by level; they do not establish cross-level DOM order or parent-child relationships. Validate heading fidelity before using it to claim complete H2/H3 coverage. “No headings returned” and “confirmed no headings” are different states. [DF-02, DF-03]

### Extraction failures and partial results

Documented controls exist for JavaScript, XHR, rendering, headers, timeouts and alternative fetch pools. They do not prove complete extraction. An empty JavaScript shell, consent/login screen, access-denied response, timeout, malformed extraction, or incomplete rendered content must not become a short-content benchmark. [DF-02, DF-03]

**Internal validity rules:** preserve URL/status/body evidence; classify each observation as usable, failed, or partial with a reason. A partial page is excluded from whole-page term/length benchmarks unless an explicit later policy allows it. If a successfully read text view has no entities, that is an observed zero; if text or the NER stage failed, entity count is MISSING. Show the actual number of pages analyzed and metric-specific denominators. Never replace a failed body with the SERP snippet.

Provider “primary” classification is heuristic: word composition/length and anchor share contribute; its documentation uses a content-score threshold above 3 and anchor share below 30%. Main/secondary topics group text by proximity and these scores. Short useful content and link-heavy listings can therefore be relegated to secondary text. This is a measurement limitation, not Google main-content classification. [DF-15]

### Verified follow-up capabilities; not added to MVP scope

`store_raw_html=true` makes subsequent `POST /v3/on_page/raw_html` retrieval possible using task `id` and `url`. The documented response uses `R.items.html` (**object**, not `items[]`). [DF-18]

Instant Pages documents `validate_micromarkup=true` for subsequent `POST /v3/on_page/microdata`, using task `id` and page `url`. Microdata documents JSON-LD/Microdata validation and returns `R.test_summary`, `R.items[].type`, `inspection_info.types[]`, nested `fields[]`, and validation results. This is a verified retrieval path for reported schema; exhaustive RDFa/rendered coverage remains UNVERIFIED. [DF-03, DF-17]

**Approved scope decision:** add Instant Pages for `meta.htags`, `meta.content.plain_text_word_count` and `meta.images_count`. Content Parsing remains the body source. Do not schedule Microdata or Raw HTML follow-ups; schema and unsupported video benchmarks remain MISSING.

## Labs request contracts

`L` means one of `location_code:integer` / `location_name:string`. `G` means one of `language_code:string` / `language_name:string`. Explicitly set both where supported; never rely on inferred defaults. Keyword inputs are lowercased by the service. `tag:string` is optional, maximum 255 characters. [DF-04–DF-08]

| Endpoint | Required | Optional fields beyond alternatives above |
|---|---|---|
| Keyword Overview | `keywords:array[string]`, L, G | `include_serp_info:boolean=false`, `include_clickstream_data:boolean=false`, `tag` |
| Search Intent | `keywords:array[string]`, G | `tag`; **no location/device** |
| Related Keywords | `keyword:string`, L, G | `depth:integer=1`, `include_seed_keyword:boolean=false`, `include_serp_info:boolean=false`, `replace_with_core_keyword:boolean=false`, `filters:array`, `order_by:array`, `limit:integer=100`, `offset:integer=0`, `tag` |
| Keyword Suggestions | `keyword:string` | L, G, `include_seed_keyword:boolean=false`, `include_serp_info:boolean=false`, `include_clickstream_data:boolean=false`, `exact_match:boolean=false`, `ignore_synonyms:boolean=false`, `filters:array`, `order_by:array`, `limit:integer=100`, `offset:integer=0`, `offset_token:string`, `tag` |
| Bulk Keyword Difficulty | `keywords:array[string]`, L, G | `tag` |

Suggestions omission of location requests all available locations; omitted language defaults to the language with most database records for that location. This is unsuitable as an implicit fallback. Search Intent supports a specific language allowlist in DF-05; inclusion in the general Labs catalog alone does not establish support. [DF-05, DF-07]

Related Keywords depth 0–4 has documented maximum expansion counts 1 (seed), 8, 72, 584, 4,680. These are ceilings, not promised returned counts. It explores stored related-search associations. `replace_with_core_keyword` changes the source keyword; keep false for exact-query evidence unless explicitly approved. [DF-06]

Suggestions searches keyword text; `exact_match=true` retains the seed phrase order, while `ignore_synonyms=true` restricts to core keywords. It is not a live Autocomplete request. Both expansion endpoints allow at most eight filter conditions and three ordering rules, with default search-volume descending. Filters use their own field paths: Related nests metrics beneath `keyword_data`; Suggestions does not. Suggestions `offset_token` makes other parameters except `limit` ineffective; do not combine it with a new query. [DF-06, DF-07]

## Labs response fields and limitations

| Endpoint | Response fields to preserve | Interpretation limits |
|---|---|---|
| Keyword Overview [DF-04] | `R.location_code`, `language_code`, `items_count`; `I.keyword`, `keyword_info`, `keyword_properties`, `serp_info`, `search_intent_info` | Missing database keywords can be omitted entirely; explicitly join back to requested keywords. Omitted keywords are documented as uncharged. |
| Search Intent [DF-05] | `R.language_code`, `items_count`; `I.keyword`, `keyword_intent.label`, `.probability`, `secondary_keyword_intents[]` | Labels: informational, navigational, commercial, transactional. Vendor predictions; probability calibration and per-market accuracy UNVERIFIED. |
| Related Keywords [DF-06] | `R.seed_keyword`, `seed_keyword_data`, `location_code`, `language_code`, `total_count`, `items_count`; `I.keyword_data`, `depth`, `related_keywords[]` | Stored expansion, potentially stale/limited; results are not demonstrated client relevance. |
| Keyword Suggestions [DF-07] | `R.seed_keyword`, `seed_keyword_data`, `location_code`, `language_code`, `total_count`, `items_count`, `offset`, `offset_token`; `I.keyword`, metric objects | Published sample splits fields across two `result` objects despite `result_count=1`; see UNVERIFIED log. |
| Bulk Keyword Difficulty [DF-08] | `R.location_code`, `language_code`, `total_count`, `items_count`; `I.keyword`, `keyword_difficulty` | Country-level vendor score; no volume or client-specific probability supplied. |

For Overview/Suggestions, and under Related's `I.keyword_data`, relevant metric paths are:

- `keyword_info.search_volume`, `.monthly_searches[].year`, `.month`, `.search_volume`, `.last_updated_time`, `.cpc`, `.competition`, `.competition_level`, `.low_top_of_page_bid`, `.high_top_of_page_bid`, `.categories`, `.search_volume_trend` where supplied.
- `keyword_properties.keyword_difficulty`, `.core_keyword`, `.synonym_clustering_algorithm`, `.detected_language`, `.is_another_language`.
- `serp_info.serp_item_types`, `.check_url`, `.se_results_count`, `.last_updated_time`, `.previous_updated_time` when returned.
- `search_intent_info.main_intent`, `.foreign_intent`, `.last_updated_time`. These names differ from the dedicated Search Intent endpoint.
- `avg_backlinks_info` and optional `clickstream_keyword_info`, `keyword_info_normalized_with_bing`, `keyword_info_normalized_with_clickstream` are separate metric families. Their availability does not authorize building Module A. [DF-04, DF-06, DF-07]

## Ranked Keywords — approved NEW/REWRITE support

Exact path: `POST /v3/dataforseo_labs/google/ranked_keywords/live`. Required `target:string`. Domains omit scheme/`www`; a page target includes its full HTTPS URL. Omitting location/language broadens scope. Data updates weekly; this is stored Labs evidence, not a new local/device rank check. [DF-26, DF-27]

| Optional task fields [DF-26] | MVP choice |
|---|---|
| `location_code`/`location_name`, `language_code`/`language_name` | Explicit country/language |
| `item_types:array` | `["organic"]`; default also includes paid |
| `ignore_synonyms:boolean`, `include_clickstream_data:boolean`, `load_rank_absolute:boolean` | false |
| `historical_serp_mode:string` | `live`; other values `lost`, `all` |
| `limit:integer`, `offset:integer` | 1,000; paginate |
| `filters:array`, `order_by:array`, `tag:string` | At most 8 filters, 3 order rules; tag ≤255 characters |

Response: `R.target`, `location_code`, `language_code`, `total_count`, `items_count`, `items[]`; each item has `keyword_data.keyword`, keyword metric objects, and `ranked_serp_element.serp_item.{type,url,relative_url,rank_group,rank_absolute}` plus `ranked_serp_element.last_updated_time`. Organic positions use `rank_group`, not rank among mixed SERP features. [DF-26]

**Internal call policy.** NEW with `client_domain`: retrieve reported organic keywords for that domain and match exact normalized query, ordered lemma sequence, or supplied cluster-query keys in code. Record each reported URL and matching reason. Without a supplied cluster-query set, that portion is MISSING, not a completed topical-cluster check. A partial scan can produce positive warnings, but cannot establish that no existing page exists. Display: **“Possible existing page — check before building.”**

REWRITE: target the exact `client_url`, filter `ranked_serp_element.serp_item.rank_group <= 20`, retain `item_types=["organic"]` and `ignore_synonyms=false`. Accept only exact normalized URL matches after validating the returned context. Every accepted keyword becomes a preserve item, without a search-volume minimum. A phrase absent from the old copy still gets preserved as a topic/coverage requirement; ranking alone is not proof it occurred in the page.

**Pagination/completeness — Internal.** Keep the target, filters and ordering fixed; increment offset by the actual returned item count. Save every response and record initial/latest `total_count`, offsets, duplicate rows, and retrieval timestamps. A short/empty page before the declared total, changed total, repeated results or failed call makes the scan incomplete. No arbitrary first-page/top-volume truncation can satisfy “every preserve keyword.” If an operational page cap is configured, show the truncation and leave preservation completeness MISSING; do not draft an automatic REWRITE on an incomplete preserve set. Complete means all matching records in the provider snapshot, not all possible Google queries. Snapshot consistency across pages is UNVERIFIED.

**URL boundary.** The current contract explicitly describes HTTPS/`www` page targets; recognition of an HTTP-only target is UNVERIFIED. The documented domain + `ranked_serp_element.serp_item.relative_url` filter is an alternative, followed by strict full-URL validation. Never upgrade the rewrite URL, strip meaningful query parameters, or treat a missing/mismatched result as successful preservation. An explicit, valid `total_count=0`, `items_count=0` is a complete empty provider inventory; `result=null`, mismatched URLs or incomplete pagination are MISSING. [DF-26, DF-27]

**Price:** the Google Labs “All other endpoints” tariff is **$0.012/task + $0.00012/returned item**; clickstream doubles the request price. Each pagination request incurs its task charge. Use returned response `cost` for actuals; historical samples do not price a current run. Failed-call/refund/account-specific behavior remains UNVERIFIED. [DF-11]

## Pricing snapshot and cost provenance

Prices checked **2026-09-11**, USD, before account-specific arrangements. Published table values below are documentation evidence, not a paid-run quote. Recheck before implementation. [DF-09–DF-11]

| Call | Published base cost | Extra cost rules |
|---|---|---|
| Organic Live Advanced | $0.002 per initial 10-result SERP unit | Additional pages/options/operators alter cost; KB-12 and DF-09/DF-19 govern. |
| Content Parsing Live | $0.00015 per parsed page | JavaScript/rendering can add charges; unresolved option dependencies above |
| Instant Pages | $0.00015 per crawled page | Resources/JavaScript/rendering alter total |
| Keyword Overview | $0.012/task + $0.00012/returned item | Clickstream inclusion doubles the request price |
| Search Intent | $0.012/task + $0.00012/input keyword | **UNVERIFIED discrepancy:** explanatory prose says $0.0012/task, but table and example arithmetic say $0.012 |
| Related Keywords | $0.012/task + $0.00012/item | Returned-item billing; seed handling requires reconciliation |
| Keyword Suggestions | $0.012/task + $0.00012/item | Clickstream inclusion doubles the request price |
| Bulk Keyword Difficulty | $0.012/task + $0.00012/item | Confirm actual billed-item count from response |
| Ranked Keywords | $0.012/task + $0.00012/returned item | Each pagination task is charged; clickstream doubles request cost |

On-Page published totals: resources $0.00045/page; JavaScript $0.0015/page; full browser rendering $0.0051/page. Full rendering already includes resources and JavaScript: do not add those totals again. Parameter applicability remains endpoint-specific. [DF-10, DF-20]

Organic extras documented for Live include rectangles +$0.002, asynchronous AIO loading +$0.002 with refund conditions, and PAA expansion +$0.00015 per actual click. The API field is `load_async_ai_overview`; the pricing page shortens it to `load_async_overview`. Use the endpoint contract for names. Advanced search operators can multiply cost. [DF-01, DF-09]

**Internal accounting:** distinguish a code-calculated pre-run estimate from actual response `cost`. Historical documentation examples below retain their original costs; they must not seed current rate configuration. General On-Page prices do not establish every optional combination or failure/refund charge. Those details remain UNVERIFIED until confirmed. No concurrent spend reservation or approval workflow is proposed here.

## Search volume: origin, calculation and limitations

DataForSEO's base Labs Google keyword metrics use Google Ads data. The vendor describes volume as an approximate monthly metric with a past-year aggregate, notes that the aggregate may not reproduce the arithmetic mean of displayed months, and describes grouped variants/corrected spellings. Keyword Overview also documents periodic refreshes and historical revisions. [DF-04, DF-13]

Store the provided `search_volume` unchanged. Do not recompute it and present that as the vendor value. If displaying a calculated mean of returned months, label it separately, list those months, and require the derived-number policy in the completeness report. CPC, bid and competition fields concern ads, not organic ranking difficulty. Device-specific volume is not requested by these Labs contracts. [DF-04–DF-08]

**Limitations:** database coverage, aggregation, freshness, geographic granularity and variant grouping restrict interpretation. Search volume is not unique people, organic clicks, leads or revenue. Never sum grouped variants as proven independent demand. A provider estimate is still a raw provider value; calling it “raw” does not make it exact ground truth. Missing and zero must remain distinct. The vendor's claim of a fixed number of volume buckets relies on secondary references and is **UNVERIFIED** here; no recommendation uses it. [DF-13; Internal interpretation]

## Research addition — Google Ads sub-country search volume (outside the MVP)

**City: VERIFIED, T2.** `POST /v3/keywords_data/google_ads/search_volume/live` accepts a supported `location_name` or `location_code`; its example is `London,England,United Kingdom`. The free `GET /v3/keywords_data/google_ads/locations` catalogue supplies selectors. The provider explicitly describes city-level search volume. Unlike Labs, this Keywords Data endpoint can request a supported sub-country location. [DF-21, DF-22, DF-24]

**DMA: UNVERIFIED.** The published Keywords Data catalogue dated **2026-09-01** contains City records but no `DMA Region` records. A deterministic scan also found no standalone `DMA` token in any catalogue field. This establishes absence from that published file, not a tested rejection by the live endpoint. The catalogue page's broad statement about Google target types is insufficient to establish DMA availability: Google's own geo-target guidance discusses DMA regions, while the provider's specific catalogue omits them. Confirm an actual supported selector with DataForSEO before any later DMA implementation. Never invent a selector or equate DMA with a city. [DF-22, DF-23; DF-25, T1; catalogue comparison is an internal observation]

**Coordinate caveat:** this search-volume endpoint's `location_coordinate` accepts `latitude,longitude` but returns the **country's** data. It is not coordinate-, radius- or city-level volume. Omitted location requests worldwide data. The locations contract also warns that Postal Code tasks return no data. Granular targeting does not guarantee keyword availability or remove Google Ads grouping limitations. [DF-21, DF-22, DF-24]

**Catalogue audit:** UTF-8 CSV headers were `location_code,location_name,location_code_parent,country_iso_code,location_type`. The London row has code `1006886`, parent `20339`, country `GB`, type `City`; New York city has code `1023191`, parent `21167`, country `US`, type `City`. These are DOCUMENTATION examples, not production metrics. Download SHA-256: `0afa2016e348e8d801dd113c1fad3e6f0fbf71611fbed7c92b89d38f7428596c`. The test used case-insensitive whole-token matching for DMA across all CSV values and inspected the `location_type` values. [DF-23]

**MVP disposition:** documentation only. No Keywords Data volume endpoint is added to the call plan or cost model; use approved country-level Labs metrics.

## Keyword difficulty: documented calculation and limitations

The vendor describes using the first ten organic results and its backlink-based domain/page ranks, each on a 0–1,000 scale. For result i:

\[
r_i=\frac{0.1D_i+0.9P_i}{500},\qquad
z=\frac{\max(\operatorname{median}(r_i),\operatorname{mean}(r_i))-0.2}{0.8}.
\]

It describes scaling to an integer 0–100 and truncating values above 1. **UNVERIFIED:** the wording does not unambiguously specify whether that cap precedes scaling; lower clipping, integer rounding and handling fewer than ten valid ranks are not defined. Do not silently supply those rules or recreate the vendor score. Display the response field. [DF-14]

The metric is country-specific. It depends on the provider's stored SERPs/backlink index and proprietary ranks. It is neither Google PageRank nor a calibrated chance of success, and contains no client-specific GBP, proximity, content-quality or conversion assessment. Exact reproducibility from the public description alone is UNVERIFIED. Module A remains deferred. [DF-14; Internal interpretation]

## UNVERIFIED and contradiction register

| ID | Finding | Required treatment |
|---|---|---|
| U-01 | Instant Pages task-count statements conflict | Approved one-task/request subset with host serialization; batching remains UNVERIFIED |
| U-02 | Content Parsing rendering references absent `load_resources` request field | Confirm supported combination; do not guess |
| U-03 | `level` string/integer discrepancy | Keep raw type; contract fixture before normalizing |
| U-04 | Suggestions sample has two result objects but `result_count=1` | Preserve example literally; runtime contract UNVERIFIED; never assume `result[0].items` |
| U-05 | Search Intent pricing prose conflicts with table | Recheck vendor/account billing before price configuration |
| U-06 | KD final cap/rounding and upstream reproduction incomplete | Use returned score; do not reconstruct |
| U-07 | Full schema/video coverage absent from base parsing contract | MISSING unless an approved measured retrieval path succeeds |
| U-08 | Endpoint concurrency/account-specific limits not fully specified | Do not infer missing ceilings from another endpoint |
| U-09 | Real-page extraction quality and real response drift untested | Live adapter acceptance remains future work |
| U-10 | Raw-field-only numeric rule excludes requested derived analytics | RESOLVED by user: RAW / DERIVED / CONFIG / DOCUMENTATION; all calculations in code |
| U-11 | City/device scope does not carry into Labs metrics | RESOLVED by user: explicitly separate country-level Labs metrics |
| U-12 | Keywords Data DMA support is not established by its published catalogue | UNVERIFIED; do not substitute a city, Google Ads targeting ID or raw Nielsen code for a supported DMA selector |
| U-13 | Ranked Keywords HTTP-only URL targeting, snapshot stability and exhaustive real-world coverage | Exact returned-URL validation; paginate; report snapshot scope and incomplete preservation |

## Completeness checklist

- [x] All eight exact endpoint paths, request fields, response fields and documented limits recorded.
- [x] Organic location/device detail cross-referenced to parked KB-12.
- [x] Text/headings/schema boundaries and extraction failure handling documented.
- [x] Pricing dated, including variable charges and discrepancies.
- [x] Volume/KD origins and documented limitations recorded without invented precision.
- [x] One genuine documentation response projection per requested endpoint below.
- [ ] **UNVERIFIED:** ambiguous contracts, paid-response billing and representative extraction fixtures.
- [x] User approved Part 1 and supplied the scope/provenance decisions recorded above.
- [x] Research-only Google Ads sub-country volume item answered: city support verified; DMA support UNVERIFIED against the current published catalogue.
- [x] Approved Ranked Keywords contract, pagination, price and genuine documentation response projection added before MVP integration.

## Source register

All sources accessed **2026-09-11**. “Undated” means no reliable publication/update date was used; it is not an inferred date. All API/pricing/methodology sources in this file are **T2**, except the explicitly labeled Google source DF-25 (**T1**).

| ID | Source URL | Publication/update date used |
|---|---|---|
| DF-01 | [Organic Live Advanced](https://docs.dataforseo.com/v3/serp/google/organic/live/advanced/) | Undated; current contract snapshot |
| DF-02 | [Content Parsing Live](https://docs.dataforseo.com/v3/on_page-content_parsing-live/) | Undated |
| DF-03 | [Instant Pages](https://docs.dataforseo.com/v3/on_page-instant_pages/) | Undated |
| DF-04 | [Keyword Overview](https://docs.dataforseo.com/v3/dataforseo_labs-google-keyword_overview-live/) | Undated |
| DF-05 | [Search Intent](https://docs.dataforseo.com/v3/dataforseo_labs-google-search_intent-live/) | Undated |
| DF-06 | [Related Keywords](https://docs.dataforseo.com/v3/dataforseo_labs-google-related_keywords-live/) | Undated |
| DF-07 | [Keyword Suggestions](https://docs.dataforseo.com/v3/dataforseo_labs/google/keyword_suggestions/live/) | Undated |
| DF-08 | [Bulk Keyword Difficulty](https://docs.dataforseo.com/v3/dataforseo_labs-google-bulk_keyword_difficulty-live/) | Undated |
| DF-09 | [Organic pricing](https://dataforseo.com/pricing/serp/google-organic-serp-api) | Undated; checked 2026-09-11 |
| DF-10 | [On-Page pricing](https://dataforseo.com/pricing/on-page/onpage-api) | Undated; checked 2026-09-11 |
| DF-11 | [Labs pricing](https://dataforseo.com/pricing/dataforseo-labs/dataforseo-google-api) | Undated; checked 2026-09-11 |
| DF-12 | [Labs locations/languages](https://docs.dataforseo.com/v3/dataforseo_labs_locations_and_languages/) | Undated |
| DF-13 | [Search volume explanation](https://dataforseo.com/help-center/what-is-search-volume) | Updated 2025-05-08 |
| DF-14 | [Keyword difficulty calculation](https://dataforseo.com/help-center/what-is-keyword-difficulty-and-how-is-it-calculated) | Updated 2025-12-31 |
| DF-15 | [Primary versus secondary content](https://dataforseo.com/help-center/difference-between-primary-and-secondary-content) | Updated 2025-05-21 |
| DF-16 | [Table extraction](https://dataforseo.com/update/table-data-in-on-page-content-parsing-api) | 2024-05-16 |
| DF-17 | [Microdata retrieval](https://docs.dataforseo.com/v3/on_page-microdata/) | Undated |
| DF-18 | [Raw HTML retrieval](https://docs.dataforseo.com/v3/on_page-raw_html/) | Undated |
| DF-19 | [SERP optional costs](https://dataforseo.com/help-center/serp-api-cost-explained) | Rolling help article; checked 2026-09-11 |
| DF-20 | [On-Page optional costs](https://dataforseo.com/help-center/cost-of-onpage-api-parameters) | Rolling help article; checked 2026-09-11 |
| DF-21 | [Google Ads Search Volume Live](https://docs.dataforseo.com/v3/keywords_data-google_ads-search_volume-live/) | Undated; research-only endpoint |
| DF-22 | [Google Ads Keywords Data locations](https://docs.dataforseo.com/v3/keywords_data/google_ads/locations/) | Catalogue dated 2026-09-01 |
| DF-23 | [Published Keywords Data locations CSV](https://cdn.dataforseo.com/v3/locations/locations_kwrd_2026_09_01.csv) | 2026-09-01 filename and catalogue label; downloaded and inspected 2026-09-11 |
| DF-24 | [City/coordinate search-volume limits](https://dataforseo.com/help-center/sv-for-city-or-coordinates) | Page displays Updated 01.12.2021 |
| DF-25 | [Google Ads geo targets](https://developers.google.com/google-ads/api/data/geotargets) — **T1** | Current page checked 2026-09-11 |
| DF-26 | [Google Ranked Keywords Live](https://docs.dataforseo.com/v3/dataforseo_labs-google-ranked_keywords-live/) | Undated; current contract checked 2026-09-11 |
| DF-27 | [Domain/URL ranked keyword lookup](https://dataforseo.com/help-center/how-to-get-keywords-a-domain-url-ranks-for) | Current page checked 2026-09-11 |

## Documentation response samples

The following are **valid-JSON projections of the actual response examples published in DF-01–DF-08**. Fields and array elements are omitted for brevity; retained values are unchanged. These are vendor examples, not measured client data or new live calls. Historical costs and mixed illustrative SERP items remain historical. Projection locations are stated per example so omissions cannot be mistaken for complete responses.

### Sample 1: Organic Live Advanced [DF-01]

Original selection: `/tasks/0/result/0/items/6` (organic example; rank 26 retained).

```json
{
  "status_code": 20000,
  "tasks": [
    {
      "status_code": 20000,
      "cost": 0.003,
      "result": [
        {
          "items": [
            {
              "type": "organic",
              "rank_group": 26,
              "rank_absolute": 30,
              "url": "https://www.t-mobile.com/cell-phone/apple-iphone-12-pro"
            }
          ]
        }
      ]
    }
  ]
}
```

### Sample 2: Content Parsing Live [DF-02]

Original selection: `/tasks/0/result/0/items/0`; selected `main_topic/1`, then `primary_content/4`.

```json
{
  "status_code": 20000,
  "tasks": [
    {
      "status_code": 20000,
      "cost": 0.000125,
      "result": [
        {
          "crawl_progress": "finished",
          "items": [
            {
              "type": "content_parsing_element",
              "fetch_time": "2025-06-02 06:59:10 +00:00",
              "status_code": 200,
              "page_content": {
                "main_topic": [
                  {
                    "h_title": "What is DataForSEO Trends API and how does it work?",
                    "level": 3,
                    "primary_content": [
                      {
                        "text": "Search trends data across specific regions and subregions;",
                        "url": null,
                        "urls": null
                      }
                    ]
                  }
                ]
              }
            }
          ]
        }
      ]
    }
  ]
}
```

### Sample 3: Instant Pages [DF-03]

Original selection: `/tasks/0/result/0/items/0`.

```json
{
  "status_code": 20000,
  "tasks": [
    {
      "status_code": 20000,
      "cost": 0.00025,
      "result": [
        {
          "crawl_progress": "finished",
          "items": [
            {
              "resource_type": "html",
              "status_code": 200,
              "url": "https://dataforseo.com/blog",
              "meta": {
                "htags": {
                  "h1": [
                    "Blog"
                  ]
                },
                "images_count": 11,
                "content": {
                  "plain_text_word_count": 432
                }
              }
            }
          ]
        }
      ]
    }
  ]
}
```

### Sample 4: Keyword Overview [DF-04]

Original selection: `/tasks/0/result/0/items/0`.

```json
{
  "status_code": 20000,
  "tasks": [
    {
      "status_code": 20000,
      "cost": 0.0201,
      "result": [
        {
          "location_code": 2840,
          "language_code": "en",
          "items_count": 1,
          "items": [
            {
              "keyword": "iphone",
              "keyword_info": {
                "last_updated_time": "2025-03-06 03:08:24 +00:00",
                "search_volume": 1220000
              },
              "keyword_properties": {
                "keyword_difficulty": 89
              }
            }
          ]
        }
      ]
    }
  ]
}
```

### Sample 5: Search Intent [DF-05]

Original selection: `/tasks/0/result/0/items/0`.

```json
{
  "status_code": 20000,
  "tasks": [
    {
      "status_code": 20000,
      "cost": 0.0014,
      "result": [
        {
          "language_code": "en",
          "items": [
            {
              "keyword": "login page",
              "keyword_intent": {
                "label": "navigational",
                "probability": 0.9694191
              },
              "secondary_keyword_intents": null
            }
          ]
        }
      ]
    }
  ]
}
```

### Sample 6: Related Keywords [DF-06]

Original selection: `/tasks/0/result/0/items/0`.

```json
{
  "status_code": 20000,
  "tasks": [
    {
      "status_code": 20000,
      "cost": 0.0103,
      "result": [
        {
          "location_code": 2840,
          "language_code": "en",
          "items": [
            {
              "depth": 0,
              "keyword_data": {
                "keyword": "phone",
                "keyword_info": {
                  "search_volume": 368000
                }
              }
            }
          ]
        }
      ]
    }
  ]
}
```

### Sample 7: Keyword Suggestions [DF-07]

Original selection: `/tasks/0/result/0` and `/tasks/0/result/1/items/0`; two result objects retained.

```json
{
  "status_code": 20000,
  "tasks": [
    {
      "status_code": 20000,
      "cost": 0.0101,
      "result": [
        {
          "seed_keyword": "phone"
        },
        {
          "location_code": 2840,
          "language_code": "en",
          "items_count": 1,
          "items": [
            {
              "keyword": "boost cell phone",
              "keyword_info": {
                "search_volume": 1830000
              }
            }
          ]
        }
      ],
      "result_count": 1
    }
  ]
}
```

### Sample 8: Bulk Keyword Difficulty [DF-08]

Original selection: `/tasks/0/result/0/items/0`.

```json
{
  "status_code": 20000,
  "tasks": [
    {
      "status_code": 20000,
      "cost": 0.0103,
      "result": [
        {
          "location_code": 2840,
          "language_code": "en",
          "items": [
            {
              "keyword": "car dealer los angeles",
              "keyword_difficulty": 50
            }
          ]
        }
      ]
    }
  ]
}
```

**Example integrity note:** the Organic documentation combines illustrative features and unrelated query examples; its organic rank above is not a new top-ten observation. The Suggestions documentation is internally inconsistent about result structure. These samples establish published shapes only. Production fixtures must come from coherent, stored responses; neither anomaly is silently corrected.


### Sample 9: Ranked Keywords [DF-26]

Genuine documentation projection of `/tasks/0/result/0/items/0`; other fields/items omitted. Values, including the historical cost, are unchanged. This is not a current paid response.

```json
{
  "status_code": 20000,
  "tasks": [
    {
      "status_code": 20000,
      "cost": 0.011,
      "result": [
        {
          "target": "dataforseo.com",
          "location_code": 2840,
          "language_code": "en",
          "total_count": 3696,
          "items": [
            {
              "keyword_data": {
                "keyword": "1000 keywords"
              },
              "ranked_serp_element": {
                "serp_item": {
                  "type": "organic",
                  "url": "https://dataforseo.com/free-seo-stats/top-1000-keywords",
                  "relative_url": "/free-seo-stats/top-1000-keywords",
                  "rank_group": 1,
                  "rank_absolute": 1
                },
                "last_updated_time": "2025-05-19 22:51:01 +00:00"
              }
            }
          ]
        }
      ]
    }
  ]
}
```
