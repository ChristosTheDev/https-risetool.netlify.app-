# KB-02 — Google ranking systems and content guidance

Prepared and sources checked: **2026-09-11**. Version: **1.0, Part 1 review draft**. Owner: Rise Marketing HQ.

**T1:** Google official. **T2:** vendor/maintainer documentation. **T3:** academic. **T4:** industry study, correlation-only. **T5:** unconfirmed; never a recommendation. **Internal:** the agency's proposed product/editorial rule. Every factual assertion about Google below uses T1 evidence. Internal implications are explicitly separate. **UNVERIFIED** means the reviewed evidence does not establish the claim; it is not proof that the claim is false.

Module 0 and KB-12 remain parked. This document becomes the Core's ranking-policy reference; it does not activate local grids, city-page gates, or Modules A–E.

## Documented ranking systems — T1

Google's guide is a selection of notable systems, not an exhaustive specification. It describes page-level ranking with additional site-wide signals. A public system name does not disclose its feature weights or enable a third party to reproduce Google's ranking. [G-01, G-08]

| System in Google's guide | Documented role, abbreviated |
|---|---|
| BERT | Interprets meaning and intent from word combinations |
| Crisis information | Surfaces crisis assistance and alerts |
| Deduplication | Reduces repetitive result listings |
| Exact match domain | Limits excessive credit from query-matching domains |
| Freshness | Responds to queries needing timely information |
| Link analysis / PageRank | Uses relationships among linked pages |
| Local news | Surfaces relevant local reporting |
| MUM | Specific applications; not general Search ranking |
| Neural matching | Matches concepts in queries and pages |
| Original content | Supports prominence of original material |
| Removal-based demotion | Uses qualifying removal patterns |
| Passage ranking | Understands relevant sections within pages |
| RankBrain | Relates words to concepts |
| Reliable information | Supports reliable material and advisories |
| Reviews | Evaluates review content |
| Site diversity | Limits domination by one site, with exceptions |
| Spam detection / SpamBrain | Detects policy-violating behavior/content |

Source for the table: **G-01, T1**. Historical entries include Helpful Content (incorporated into core systems in March 2024), Hummingbird, Panda, and Penguin. Do not describe a separate current Helpful Content system based solely on its historical entry. [G-01]

**Internal implications:** the term table measures visible content, not these systems. It cannot isolate causality, infer secret weights, or explain a competitor's rank from copy alone. A single SERP is an observation with location/device/time parameters. KB-12 owns that context record. Backlinks/authority assessment remains Module A; content parity does not imply comparable authority.

## Helpful, reliable, people-first content — T1

Google's guidance asks creators to assess originality, usefulness, completeness for the topic, reliable sourcing, clear authorship, and whether readers can accomplish their goals. It warns against merely summarizing others without adding value, creating material primarily for search traffic, or changing dates to create an appearance of freshness. It encourages considering who created content, how it was made, and why. [G-02]

Google says E-E-A-T is not a single specific ranking factor. Trust is central; different content can demonstrate it through different combinations of experience, expertise and authority. Raters provide evaluation feedback; they do not directly assign search rankings. [G-02]

**Internal implications for briefs and drafts:**

- A competitor-derived outline is evidence of observed topics. A writer must still decide what serves this query's reader and the client's actual offer.
- Each draft section retains the user-required tag **SERP parity** or **NEEDS SME INPUT**. The AI writes parity sections only; SME sections contain a concrete placeholder describing the missing evidence.
- “SERP parity” permits an original explanation of a supported topic. It does not authorize copying a competitor's wording or adopting their experiences, credentials, prices, testimonials, warranties, service claims, or results as the client's.
- Record factual sources before asserting facts. Missing business evidence stays a placeholder. A fluent paragraph does not resolve MISSING data.
- The core can create an editable parity draft before Module B exists. It cannot claim the SME placeholders already deliver information gain or first-hand expertise.

These are the user's rules and proposed editorial controls, not Google-prescribed tags or an automated people-first score.

## E-E-A-T and Needs Met in the Search Quality Rater Guidelines — T1

Verified PDF edition: **General Guidelines, September 11, 2025**, 182 PDF pages; accessed 2026-09-11. Relevant page images were checked. Page numbers below are the printed numbers; the corresponding PDF page indexes are one lower. [G-03]

| Concept | Meaning in the guidelines |
|---|---|
| Experience | Relevant first-hand or life experience |
| Expertise | Necessary knowledge or skill |
| Authoritativeness | Recognition as a useful reference for the subject |
| Trust | Accuracy, honesty, safety and reliability; central to E-E-A-T |

See §3.4, printed pages 26–27. Appropriate evidence depends on purpose and topic. Absence of reputation information alone does not establish poor quality, including for small local businesses (§3.3.5, page 25). [G-03]

Needs Met considers how helpful a result is for a query, its plausible interpretations, and the user's context. Its scale (§13, page 113) comprises **Fully Meets**, **Highly Meets**, **Moderately Meets**, **Slightly Meets**, and **Fails to Meet**. Fully Meets is a special category for a clear intent seeking a specific result. Page Quality and Needs Met are related but different judgments (§14, page 142). Query needs include Know, Do, Website, and Visit-in-Person (§12.7). [G-03]

**Internal limits:** a four-label DataForSEO intent prediction is not Google's Needs Met scale. Neither term frequency nor an NER entity count determines E-E-A-T. Do not produce a numeric “Google E-E-A-T score” or automated rater verdict. Use the guidelines for human review, and keep measured text coverage separate from judgments about truth, experience and satisfaction.

## Spam policies relevant to the Core — T1

| Policy | Documented boundary | Internal consequence |
|---|---|---|
| Scaled content abuse | Large-scale content made primarily to manipulate rankings with little user value; applies regardless of production method | Never claim AI rewriting or combining competitor pages alone creates sufficient value |
| Keyword stuffing | Unnatural/out-of-context keywords or numbers used to manipulate rankings; includes repetitive phrases and location lists | Frequency ranges are observations, never instructions to force repetitions |
| Doorway abuse | Similar query-targeted intermediate pages that provide less usefulness than the final destination; geographic funnels are examples | Cross-reference KB-12; do not expand city targeting in this step |
| Scraping | Republishing or minimally transforming others' material without meaningful added value | Cite research; draft original explanations and request missing client evidence |

Source for policy boundaries: **G-04, T1**. Google's policy page also covers cloaking, expired-domain abuse, hacked content, hidden text/link abuse, link spam, malicious practices, misleading functionality, site reputation policy, sneaky redirects, thin affiliation, user-generated spam, and other prohibited behavior. This table focuses on the requested content workflow; it is not an exhaustive policy audit. [G-04]

**Doorway cross-reference:** see KB-12's T1-G3 and its Google source. Google does not supply a numeric similarity percentage that guarantees a city page is safe. Similarity and SME gates already specified in parked Module 0 are internal controls. This KB neither modifies nor executes them.

**Internal implication:** competitor prevalence is not permission to imitate spam. “Required” in the proposed term tiers means an agency threshold, never a Google requirement. A rare term is not proven differentiation; a common term is not proven a cause of ranking.

## Word count and TF-IDF: what is and is not established

| Claim | Status and evidence | Permitted use in this tool |
|---|---|---|
| Google has a preferred page word count | **Contradicted by T1:** Google explicitly disclaims a preferred count [G-02] | Describe observed competitor lengths and an editorial target with its basis |
| Word count alone establishes thin content | **Contradicted by T1:** Google's November 2022 office-hours answer says otherwise [G-07] | Judge whether content answers the need; never equate short with bad |
| A fixed minimum/maximum word count is needed to rank | **Unsupported:** the Starter Guide rejects a magical count [G-05] | No universal minimum, maximum, or rank guarantee |
| Google has publicly mentioned TF-IDF | **Verified, narrow scope:** Rules of Machine Learning, Rule 21, discusses TF-IDF in an illustrative search-ranking engineering example [G-06] | Cite as an ML method example only |
| That example documents current production Google Search TF-IDF weights | **UNVERIFIED:** the source does not establish that [G-06] | Never present a TF-IDF gap as a Google formula |
| Google officially prescribes matching competitor TF-IDF or density | **UNVERIFIED:** no such primary guidance confirmed in this review | TF-IDF remains an internal corpus-weighting method, documented in KB-03 |
| Google definitely never uses TF-IDF anywhere in Search | **UNVERIFIED:** absence of public implementation detail cannot establish this | Make neither an affirmative nor a negative production claim |

Research coverage for the last three rows: the current ranking guide, people-first and Starter guides, Google's ML guidance, and searches of Google Search Central materials for TF-IDF. No attributed social-media quote or third-party paraphrase is promoted to T1. Exact TF-IDF implementation in Google Search remains undisclosed in the reviewed sources.

**Internal interpretation of length:** a returned On-Page word count and a count from our cleaned text can differ because the definitions differ. Keep both named. A proposed target length is derived/editorial, not a raw vendor field or Google preference. Its approval/provenance issue is recorded in the completeness report.

## Schema, FAQs and third-party tool claims

Google's June 2026 documentation update records removal of FAQ rich-result documentation; its May entry states that FAQ rich results stopped appearing from **May 7, 2026**. This does not mean an on-page FAQ is unhelpful or that a fetched page cannot contain FAQ markup. It means the tool must not recommend FAQ schema as a current Google FAQ rich-result opportunity. [G-09]

The current third-party SEO guidance says third-party tools do not have access to Google's internal ranking data, Google does not evaluate/approve such services, and a tool cannot guarantee ranking success. [G-08]

**Internal measurement rules:** distinguish questions on a page, schema types observed in fetched markup, and features observed in the SERP. None proves the other. An absent schema retrieval is MISSING, not “no schema.” Schema and media measurement paths are detailed in KB-01 and await the Part 2 scope decision.

## Claim controls for later implementation

These controls are proposed design requirements, not implemented code or Part 2 architecture:

| Output class | Evidence needed | If missing |
|---|---|---|
| Claim about Google behavior/policy | Approved KB claim ID, T1 source URL, source date/access date, KB version | Exclude claim; record UNVERIFIED |
| Vendor metric/label | Stored response and exact field path | MISSING |
| Calculated text measurement | Formula/version and underlying source text, if user approves derived provenance | MISSING until computed; never LLM-filled |
| Business experience, pricing, credential or testimonial | Verified client/SME source; user-required SME workflow | NEEDS SME INPUT placeholder |
| Editorial target | Clearly labeled internal rule and measured rationale | Require writer decision; no invented SEO rule |

T4 correlations, if introduced in a later KB revision, must be labeled correlation-only. T5 claims never drive recommendations. A coverage-checker score would measure the adopted brief's constraints, not correctness, E-E-A-T, Google compliance or likelihood of ranking.

## Completeness checklist

- [x] Current public ranking-system guide and historical system distinctions.
- [x] Helpful, reliable, people-first guidance with internal implications separated.
- [x] E-E-A-T, Needs Met, PDF edition and section/page references.
- [x] Scaled content abuse, keyword stuffing, doorway and scraping boundaries.
- [x] Parked KB-12 doorway cross-reference without changes.
- [x] Official word-count guidance and a verified public TF-IDF mention, with scope limits.
- [x] Current FAQ feature status and no-ranking-guarantee guidance.
- [ ] **UNVERIFIED:** production Google TF-IDF details, ranking weights, causal term/length targets. These are not required to operate descriptive analysis and are barred from recommendations.
- [ ] Human approval of this KB and the completeness report before architecture.

## Source register

Every source below is **T1** and was accessed **2026-09-11**. “Undated here” means no reliable last-modified date was recorded for this review; the access date is the snapshot date.

| ID | Source URL | Source date / locator |
|---|---|---|
| G-01 | [Guide to Google Search ranking systems](https://developers.google.com/search/docs/appearance/ranking-systems-guide) | Updated 2025-12-10 |
| G-02 | [Helpful, reliable, people-first content](https://developers.google.com/search/docs/fundamentals/creating-helpful-content) | Rolling documentation; undated here |
| G-03 | [Search Quality Rater Guidelines PDF](https://guidelines.raterhub.com/searchqualityevaluatorguidelines.pdf) | Edition 2025-09-11; §§0.1, 3.3.5, 3.4, 12.7, 13, 14 |
| G-04 | [Spam policies](https://developers.google.com/search/docs/essentials/spam-policies) | Rolling documentation; undated here |
| G-05 | [SEO Starter Guide](https://developers.google.com/search/docs/fundamentals/seo-starter-guide) | Rolling documentation; undated here |
| G-06 | [Rules of Machine Learning](https://developers.google.com/machine-learning/guides/rules-of-ml) | Rule 21; rolling documentation, undated here |
| G-07 | [November 2022 Google SEO office hours](https://developers.google.com/search/blog/2022/11/november-office-hours) | November 2022; word-count/thin-content answer |
| G-08 | [Guidance on third-party SEO tools and advice](https://developers.google.com/search/docs/fundamentals/third-party-seo) | Updated 2026-06-05 |
| G-09 | [Search documentation updates](https://developers.google.com/search/updates) | FAQ entries 2026-05-08 and 2026-06-15; effective 2026-05-07 |

Internal provenance: the user's master-spec message and Part 1 instruction in this conversation. Internal rules have no external evidence tier and must not be passed off as Google findings.
