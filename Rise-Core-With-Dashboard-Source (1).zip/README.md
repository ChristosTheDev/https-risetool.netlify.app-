# Rise Core — foundation and dashboard

2026-09-12 · v0.3.0 · synthetic fixtures; no paid calls or deployment

The `web/` folder now starts with one target query, a page URL, or pasted content. It includes a Netlify gateway, authenticated Supabase storage, live SERP and exact-URL ranking lookup code, and connection diagnostics. The core extraction/analysis/brief/draft pipeline remains unfinished. Read **docs/SETUP.md** for deployment and required environment variables. Run **supabase/002_discovery.sql** for this discovery release; it is standalone and does not require the earlier design-only schema.

The source ZIP places this README and the `web/`, `engine/`, `supabase/`, `docs/`, `config/` and `kb/` directories at its root for upload to a Git repository. Connect the repository to the existing Netlify project and use `web` as its base directory. A static drag-and-drop upload alone does not deploy the supplied server function.

The deterministic foundation is implemented. It includes term counts/DF/tier floors/TF-IDF from supplied annotations; brief coverage; NEW/IMPROVE/REWRITE decisions and override events; Ranked Keywords contracts and complete-inventory preservation; entity-attribute counts; SME-only fact salvage; PAA/AIO collection; and a configurable writer protocol adapter.

Run from `engine/` using Python 3.12:

```bash
python3 -m unittest discover -s tests -v
python3 fixture_demo.py > ../fixtures/fixture_report.json
```

The first command runs the foundation tests. The second rebuilds the source-backed synthetic report. All test annotations and mocked provider values are explicitly fixture CONFIG, not real SEO observations. No dependency installation is needed for these commands.

| Path | Contents |
|---|---|
| `engine/rise_core/contracts.py` | Immutable page/token/evidence types, conservative URL identity, deterministic JSON |
| `engine/rise_core/terms.py`, `coverage.py` | Exact counts/rates and selected TF-IDF formula; supplied-brief checks |
| `engine/rise_core/page_modes.py`, `policies.py` | All four rewrite rules, visible measurements/config cutoffs, P25, similarity, override event |
| `engine/rise_core/ranked_keywords.py` | One-task request builder, response validation, pagination completeness, preserve items and domain warnings |
| `engine/rise_core/attributes.py`, `facts.py`, `questions.py`, `edits.py` | Matrix/source counts, unverified fact slots, observed questions/AIO refs, unscored or explicitly configured edit ordering |
| `engine/rise_core/generation.py` | Declarative HTTP-JSON request/response adapter and output guards; no HTTP transport yet |
| `config/` | Versioned thresholds, roofing ruler/attribute lists, lexical page profiles, fact/question rules, Render/Claude settings |
| `fixtures/` | Mocked Ranked Keywords response, manifest, regenerated report and validation result |
| `engine/tests/` | Hand-calculated fixture and boundary cases; source-pointer and provider-swap checks |
| `docs/`, `supabase/MVP_schema.sql`, `kb/` | Updated architecture/fixture, unapplied schema, core KB sources |
| `web/` | React/Vite/Tailwind dashboard source, tests and compiled static deployment |

The client role is excluded from competitor statistics. Rewrite classification uses a baseline brief; before/after uses the same enriched brief containing both preserve keywords. A complete zero-item inventory is valid. Failed, mismatched or incomplete inventories are MISSING and cannot authorize rewrite drafting. Overrides do not erase detected-mode evidence.

The test results are 60% for IMPROVE and 20% for the coverage-only REWRITE trigger. After adding preservation, the rewrite comparison is 2/7 before and 6/7 after; its length check still fails. The copied year statement stays in a NEEDS SME INPUT slot with “FOUND ON CURRENT PAGE — VERIFY.”

The matrix fixture measures same-sentence co-mentions, not whether a page substantively answers an attribute. Ruler/model sources stay separate. Statistical NER and real extraction accuracy are not tested by gold annotations.

B's prior unanswered-detection and priority formula were not recovered. Collection is enabled, while those labels/scores remain MISSING. The queue is explicitly unscored until the policy is supplied. A configured additive scorer is an interface, not an assumed substitute for that earlier formula.

Next in build order: implement the Supabase transactional claims/lease and Render/Netlify acquisition; integrate the pinned spaCy EntityRuler-before-NER pipeline and heading benchmarks; connect brief/edit/rewrite orchestration and Claude; then connect the dashboard to those live services. The current package is not a running end-to-end application. The writer's numeric-entity detector and source binding must be connected before live generation; the adapter alone does not prove factual support.

Render and Claude are configured as requested. The dashboard uses the approved React, Vite and Tailwind stack with React DOM as the browser renderer; exact versions and transitive dependencies are in `web/package-lock.json`. No backend package was added. Uvicorn appears in Render's FastAPI deployment example but is not on the approved dependency list; the ASGI runner remains unset pending permission. No Redis, Celery, HTTP client SDK, database driver or new NLP library was introduced. The schema is reviewable SQL and has not been applied. Module 0 and KB-12 were not changed.
